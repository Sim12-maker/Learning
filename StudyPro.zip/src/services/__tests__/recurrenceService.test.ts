import { describe, it, expect, vi } from 'vitest';
import { generateOccurrences } from '../recurrenceService';
import { TimetableEvent } from '../../types';

describe('recurrenceService', () => {
  describe('generateOccurrences', () => {
    const baseEvent: TimetableEvent = {
      id: '1',
      subject: 'Test Event',
      day: 'Monday',
      date: '2024-01-01', // A Monday
      start: 9,
      duration: 1,
      repeat: 'none',
      synced: 1
    };

    it('should generate a single occurrence for non-recurring events', async () => {
      const occurrences = await generateOccurrences(baseEvent);
      expect(occurrences).toHaveLength(1);
      expect(occurrences[0].date).toBe('2024-01-01');
    });

    it('should generate multiple occurrences for weekly events', async () => {
      const weeklyEvent = { ...baseEvent, repeat: 'weekly' as const };
      const occurrences = await generateOccurrences(weeklyEvent);
      // It generates for 1 year, so roughly 52-53 occurrences
      expect(occurrences.length).toBeGreaterThanOrEqual(52);
      expect(occurrences[1].date).toBe('2024-01-08');
    });

    it('should skip deleted occurrences', async () => {
      const weeklyEvent = { 
        ...baseEvent, 
        repeat: 'weekly' as const,
        deletedOccurrences: ['2024-01-08']
      };
      const occurrences = await generateOccurrences(weeklyEvent);
      expect(occurrences.find(o => o.date === '2024-01-08')).toBeUndefined();
      expect(occurrences[1].date).toBe('2024-01-15');
    });

    it('should generate daily occurrences', async () => {
      const dailyEvent = { ...baseEvent, repeat: 'daily' as const };
      const occurrences = await generateOccurrences(dailyEvent);
      expect(occurrences[1].date).toBe('2024-01-02');
      expect(occurrences[2].date).toBe('2024-01-03');
    });
  });
});
