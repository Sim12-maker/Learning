import { describe, it, expect } from 'vitest';
import { timetableService } from '../timetableService';
import { TimetableEvent } from '../../types';

describe('timetableService', () => {
  describe('checkConflict', () => {
    const baseEvent: TimetableEvent = {
      id: '1',
      subject: 'Physics',
      day: 'Monday',
      date: '2024-01-01',
      start: 9, // 9:00 AM
      duration: 1, // 1 hour
      synced: 1
    };

    const otherEvents: TimetableEvent[] = [
      {
        id: '2',
        subject: 'Math',
        day: 'Monday',
        date: '2024-01-01',
        start: 10, // 10:00 AM
        duration: 1,
        synced: 1
      },
      {
        id: '3',
        subject: 'Chemistry',
        day: 'Monday',
        date: '2024-01-01',
        start: 11, // 11:00 AM
        duration: 1,
        synced: 1
      }
    ];

    it('should return null if no conflict exists', () => {
      const conflict = timetableService.checkConflict(baseEvent, otherEvents);
      expect(conflict).toBeNull();
    });

    it('should detect an overlapping conflict (start time inside existing event)', () => {
      const conflictingEvent = { ...baseEvent, id: 'conflict', start: 9.5 }; // 9:30 AM
      const conflict = timetableService.checkConflict(conflictingEvent, [baseEvent]);
      expect(conflict?.id).toBe('1');
    });

    it('should detect an overlapping conflict (end time inside existing event)', () => {
      const conflictingEvent = { ...baseEvent, id: 'conflict', start: 8.5 }; // 8:30 AM
      const conflict = timetableService.checkConflict(conflictingEvent, [baseEvent]);
      expect(conflict?.id).toBe('1');
    });

    it('should detect an overlapping conflict (new event completely covers existing event)', () => {
      const conflictingEvent = { ...baseEvent, id: 'conflict', start: 8, duration: 3 }; // 8:00 AM to 11:00 AM
      const conflict = timetableService.checkConflict(conflictingEvent, [baseEvent]);
      expect(conflict?.id).toBe('1');
    });

    it('should not detect conflict if events are back-to-back', () => {
      const backToBackEvent = { ...baseEvent, start: 10 }; // Starts exactly when baseEvent ends
      const conflict = timetableService.checkConflict(backToBackEvent, [baseEvent]);
      expect(conflict).toBeNull();
    });
  });
});
