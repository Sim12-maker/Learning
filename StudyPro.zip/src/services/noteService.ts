import { db } from '../db';
import { Note } from '../types';

export const noteService = {
  async getAllNotes(): Promise<Note[]> {
    return await db.getAll('notes');
  },

  async saveNote(note: Note) {
    return await db.put('notesStore', { ...note, synced: 0 });
  },

  async deleteNote(id: string) {
    return await db.delete('notesStore', id);
  },

  async saveDraft(noteId: string, content: string) {
    return await db.put('draftNotes', {
      id: noteId, // using noteId as primary key for draft
      noteId,
      content,
      lastEdited: new Date().toISOString()
    });
  },

  async getDraft(noteId: string) {
    return await db.get('draftNotes', noteId);
  },

  async clearDraft(noteId: string) {
    return await db.delete('draftNotes', noteId);
  }
};
