import { db } from '../db';
import { TimetableEvent } from '../types';
import { updateRecurrenceCache } from './recurrenceService';

export const timetableService = {
  async getAllEvents(): Promise<TimetableEvent[]> {
    return await db.getAll('timetableStore');
  },

  async saveEvent(event: TimetableEvent) {
    const result = await db.put('timetableStore', { ...event, synced: 0 });
    const allEvents = await this.getAllEvents();
    await updateRecurrenceCache(allEvents);
    return result;
  },

  async deleteEvent(id: string) {
    const result = await db.delete('timetableStore', id);
    const allEvents = await this.getAllEvents();
    await updateRecurrenceCache(allEvents);
    return result;
  },

  async getCachedOccurrences() {
    return await db.getAll('recurrenceCache');
  },

  checkConflict(newEvent: TimetableEvent, allEvents: TimetableEvent[]): TimetableEvent | null {
    // Basic conflict detection for the same day and overlapping time
    // This is a simplified version. A robust one would check all recurring occurrences.
    for (const event of allEvents) {
      if (event.id === newEvent.id) continue;
      if (event.date === newEvent.date) {
        const newStart = newEvent.start * 60;
        const newEnd = newStart + (newEvent.duration * 60);
        const eventStart = event.start * 60;
        const eventEnd = eventStart + (event.duration * 60);

        if ((newStart >= eventStart && newStart < eventEnd) || 
            (newEnd > eventStart && newEnd <= eventEnd) ||
            (newStart <= eventStart && newEnd >= eventEnd)) {
          return event;
        }
      }
    }
    return null;
  }
};
