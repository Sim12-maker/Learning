import { addDays, addWeeks, addMonths, format, isBefore, isEqual, addYears } from 'date-fns';
import { TimetableEvent } from '../types';
import { db } from '../db';

export async function generateOccurrences(event: TimetableEvent) {
  const occurrences = [];
  let current = new Date(event.date);
  // Limit to 1 year from now for performance
  const limit = addYears(new Date(), 1);

  while (isBefore(current, limit) || isEqual(current, limit)) {
    const dateStr = format(current, 'yyyy-MM-dd');
    
    // Check if this occurrence was deleted
    if (!event.deletedOccurrences?.includes(dateStr)) {
      occurrences.push({
        eventId: event.id,
        date: dateStr
      });
    }

    if (event.repeat === 'daily') current = addDays(current, 1);
    else if (event.repeat === 'weekly') current = addWeeks(current, 1);
    else if (event.repeat === 'monthly') current = addMonths(current, 1);
    else break;
  }

  // We should probably clear old cache for this event first if we are updating
  // But for simplicity in this bulkPut, we'll handle it in the timetableService
  return occurrences;
}

export async function updateRecurrenceCache(events: TimetableEvent[]) {
  await db.clearStore('recurrenceCache');
  const allOccurrences: any[] = [];
  for (const event of events) {
    const occurrences = await generateOccurrences(event);
    allOccurrences.push(...occurrences);
  }
  await db.bulkPut('recurrenceCache', allOccurrences);
}
