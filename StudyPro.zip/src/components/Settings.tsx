import React, { useState } from 'react';
import { 
  Moon, Sun, Bell, Palette, Type, Clock, Database, Shield,
  ChevronRight, Download, Upload, Trash2, Check, Volume2,
  Vibrate, Target, Coffee, Zap, AlertTriangle, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db } from '../db';
import { useSettings } from '../hooks/useSettings';

export default function Settings() {
  const { settings, updateSettings } = useSettings();
  const [activeSection, setActiveSection] = useState<string>('appearance');
  const [showSuccess, setShowSuccess] = useState(false);
  // FIX: Replace confirm() with a custom modal
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const update = (patch: Record<string, any>) => {
    updateSettings(patch as any);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  const handleExportData = async () => {
    try {
      const resources = await db.getAll('resourcesStore');
      const notes = await db.getAll('notes');
      const tasks = await db.getAll('tasksStore');
      const data = { settings, resources, notes, tasks, exportDate: new Date().toISOString() };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `studypro-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Export failed', e);
    }
  };

  const handleClearData = async () => {
    await db.clearStore('resourcesStore');
    await db.clearStore('notes');
    await db.clearStore('tasksStore');
    localStorage.clear();
    setShowClearConfirm(false);
    window.location.reload();
  };

  const sections = [
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'study', label: 'Study Settings', icon: Clock },
    { id: 'data', label: 'Data & Storage', icon: Database },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-20 px-6 pt-4">
      <div className="flex items-end justify-between">
        <div className="space-y-1">
          <h2 className="text-3xl font-display font-bold tracking-tight">Settings</h2>
          <p className="text-slate-500 font-medium">Personalize your study experience</p>
        </div>
        <AnimatePresence>
          {showSuccess && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
              className="flex items-center gap-2 text-emerald-500 font-bold text-sm bg-emerald-50 dark:bg-emerald-900/20 px-4 py-2 rounded-xl"
            >
              <Check size={16} /> Settings Saved
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-4 space-y-2">
          {sections.map(section => (
            <button key={section.id} onClick={() => setActiveSection(section.id)}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${
                activeSection === section.id 
                  ? 'bg-brand-600 text-white shadow-xl shadow-brand-500/20' 
                  : 'bg-white dark:bg-slate-900 text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${activeSection === section.id ? 'bg-white/20' : 'bg-slate-100 dark:bg-slate-800'}`}>
                <section.icon size={20} />
              </div>
              <span className="font-bold">{section.label}</span>
              <ChevronRight size={18} className={`ml-auto transition-transform ${activeSection === section.id ? 'rotate-90' : ''}`} />
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 md:p-12 border border-slate-200 dark:border-slate-800 shadow-sm">
          <AnimatePresence mode="wait">
            {activeSection === 'appearance' && (
              <motion.div key="appearance" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
                <h3 className="text-xl font-bold flex items-center gap-3"><Sun size={24} className="text-brand-500" /> Theme & Style</h3>

                <div className="grid grid-cols-2 gap-4">
                  <button onClick={() => update({ darkMode: false })}
                    className={`p-6 rounded-3xl border-2 transition-all flex flex-col items-center gap-4 ${!settings.darkMode ? 'border-brand-500 bg-brand-50/50 dark:bg-brand-900/10' : 'border-slate-100 dark:border-slate-800'}`}>
                    <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center"><Sun size={24} /></div>
                    <span className="font-bold text-sm">Light Mode</span>
                  </button>
                  <button onClick={() => update({ darkMode: true })}
                    className={`p-6 rounded-3xl border-2 transition-all flex flex-col items-center gap-4 ${settings.darkMode ? 'border-brand-500 bg-brand-50/50 dark:bg-brand-900/10' : 'border-slate-100 dark:border-slate-800'}`}>
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 text-white flex items-center justify-center"><Moon size={24} /></div>
                    <span className="font-bold text-sm">Dark Mode</span>
                  </button>
                </div>

                <div className="space-y-4">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Type size={14} /> Font Size</label>
                  <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
                    {(['small', 'medium', 'large'] as const).map(size => (
                      <button key={size} onClick={() => update({ fontSize: size })}
                        className={`flex-1 py-3 rounded-xl font-bold text-sm capitalize transition-all ${settings.fontSize === size ? 'bg-white dark:bg-slate-700 text-brand-600 shadow-sm' : 'text-slate-500'}`}>
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Palette size={14} /> Accent Color</label>
                  <div className="flex flex-wrap gap-3">
                    {['#4A90E2', '#ec4899', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'].map(color => (
                      <button key={color} onClick={() => update({ accentColor: color })} style={{ backgroundColor: color }}
                        className={`w-10 h-10 rounded-full transition-all transform hover:scale-110 flex items-center justify-center text-white ${settings.accentColor === color ? 'ring-4 ring-offset-4 ring-slate-200 dark:ring-slate-700' : ''}`}>
                        {settings.accentColor === color && <Check size={18} />}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeSection === 'notifications' && (
              <motion.div key="notifications" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
                <h3 className="text-xl font-bold flex items-center gap-3"><Bell size={24} className="text-brand-500" /> Notification Preferences</h3>
                <div className="space-y-4">
                  {[
                    { key: 'notificationsEnabled', label: 'Enable Notifications', desc: 'Receive alerts and reminders', icon: Bell },
                    { key: 'studyReminders', label: 'Study Reminders', desc: "Get notified when it's time to study", icon: Target },
                    { key: 'soundEnabled', label: 'Sound Effects', desc: 'Play sounds for app interactions', icon: Volume2 },
                    { key: 'vibrationEnabled', label: 'Haptic Feedback', desc: 'Vibrate on important actions', icon: Vibrate },
                  ].map(item => (
                    <div key={item.key} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-800 flex items-center justify-center text-slate-400"><item.icon size={20} /></div>
                        <div><p className="font-bold text-sm">{item.label}</p><p className="text-xs text-slate-500">{item.desc}</p></div>
                      </div>
                      <button onClick={() => update({ [item.key]: !(settings as any)[item.key] })}
                        className={`w-12 h-6 rounded-full transition-all relative ${(settings as any)[item.key] ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-700'}`}>
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${(settings as any)[item.key] ? 'left-7' : 'left-1'}`} />
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeSection === 'study' && (
              <motion.div key="study" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
                <h3 className="text-xl font-bold flex items-center gap-3"><Clock size={24} className="text-brand-500" /> Focus & Productivity</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Zap size={14} /> Focus Duration (min)</label>
                    <input type="number" value={settings.focusDuration}
                      onChange={e => update({ focusDuration: parseInt(e.target.value) || 25 })}
                      className="w-full px-6 py-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl outline-none focus:ring-2 focus:ring-brand-500 font-bold" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Coffee size={14} /> Break Duration (min)</label>
                    <input type="number" value={settings.breakDuration}
                      onChange={e => update({ breakDuration: parseInt(e.target.value) || 5 })}
                      className="w-full px-6 py-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl outline-none focus:ring-2 focus:ring-brand-500 font-bold" />
                  </div>
                </div>
                <div className="flex items-center justify-between p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50">
                  <div><p className="font-bold text-sm">Auto-start Breaks</p><p className="text-xs text-slate-500">Start break timer automatically after focus session</p></div>
                  <button onClick={() => update({ autoStartBreak: !settings.autoStartBreak })}
                    className={`w-12 h-6 rounded-full transition-all relative ${settings.autoStartBreak ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-700'}`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.autoStartBreak ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>
                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Target size={14} /> Daily Study Goal (min)</label>
                  <div className="flex items-center gap-4">
                    <input type="range" min="30" max="480" step="30" value={settings.dailyGoal}
                      onChange={e => update({ dailyGoal: parseInt(e.target.value) })} className="flex-1 accent-brand-500" />
                    <span className="w-16 h-12 bg-brand-100 dark:bg-brand-900/30 text-brand-600 rounded-xl flex items-center justify-center font-bold text-sm">
                      {Math.round(settings.dailyGoal / 60 * 10) / 10}h
                    </span>
                  </div>
                </div>
              </motion.div>
            )}

            {activeSection === 'data' && (
              <motion.div key="data" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
                <h3 className="text-xl font-bold flex items-center gap-3"><Database size={24} className="text-brand-500" /> Data Management</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button onClick={handleExportData}
                    className="flex items-center gap-4 p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 hover:bg-brand-50 dark:hover:bg-brand-900/10 transition-all group">
                    <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 flex items-center justify-center text-brand-500 group-hover:scale-110 transition-transform"><Download size={24} /></div>
                    <div className="text-left"><p className="font-bold text-sm">Export Backup</p><p className="text-[10px] text-slate-500">Download all your data</p></div>
                  </button>
                  <button className="flex items-center gap-4 p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/50 opacity-50 cursor-not-allowed">
                    <div className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 flex items-center justify-center text-brand-500"><Upload size={24} /></div>
                    <div className="text-left"><p className="font-bold text-sm">Restore Backup</p><p className="text-[10px] text-slate-500">Import from JSON file</p></div>
                  </button>
                </div>
                <div className="p-8 rounded-[2rem] border-2 border-dashed border-rose-200 dark:border-rose-900/30 bg-rose-50/30 dark:bg-rose-900/5 space-y-4">
                  <div className="flex items-center gap-3 text-rose-600"><Shield size={20} /><h4 className="font-bold">Danger Zone</h4></div>
                  <p className="text-sm text-slate-500">Clearing your data will remove all documents, notes, and settings. This action is permanent and cannot be reversed.</p>
                  <button onClick={() => setShowClearConfirm(true)}
                    className="px-6 py-3 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 transition-all flex items-center gap-2">
                    <Trash2 size={18} /> Clear All Data
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Clear Data Confirmation Modal */}
      <AnimatePresence>
        {showClearConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowClearConfirm(false)} className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden p-8">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center text-red-600"><AlertTriangle size={28} /></div>
                <div>
                  <h2 className="text-xl font-display font-bold">Clear all data?</h2>
                  <p className="text-sm text-slate-400 mt-1">This will permanently delete all notes, tasks, resources, and settings. This cannot be undone.</p>
                </div>
                <div className="flex gap-3 w-full pt-2">
                  <button onClick={() => setShowClearConfirm(false)} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button">Cancel</button>
                  <button onClick={handleClearData} className="flex-1 py-4 bg-red-600 text-white font-bold rounded-2xl shadow-lg shadow-red-200 dark:shadow-none thumb-button">Clear Data</button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
