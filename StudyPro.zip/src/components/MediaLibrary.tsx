import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Play, 
  Music, 
  Video, 
  Clock, 
  Star, 
  MoreVertical, 
  Trash2, 
  Share2,
  FolderOpen,
  LayoutGrid,
  List as ListIcon,
  Plus,
  FileUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { v4 as uuidv4 } from 'uuid';
import { Resource } from '../types';
import { db } from '../db';
import MediaPlayer from './MediaPlayer';

interface MediaLibraryProps {
  resources: Resource[];
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
}

export default function MediaLibrary({ resources, onDelete, onToggleFavorite }: MediaLibraryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'video' | 'audio'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeMedia, setActiveMedia] = useState<{ src: string; type: 'video' | 'audio'; title: string } | null>(null);

  const mediaResources = useMemo(() => {
    return resources.filter(r => r.category === 'Music' || r.type === 'video' || r.type === 'mp3' || r.type === 'wav');
  }, [resources]);

  const filtered = useMemo(() => {
    return mediaResources.filter(r => {
      const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           r.subject.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === 'all' || 
                         (selectedType === 'video' && r.type === 'video') ||
                         (selectedType === 'audio' && (r.type === 'mp3' || r.type === 'wav' || r.category === 'Music'));
      return matchesSearch && matchesType;
    });
  }, [mediaResources, searchQuery, selectedType]);

  const handlePlay = (resource: Resource) => {
    let src = resource.url || '#';
    if (resource.fileData) {
      src = URL.createObjectURL(resource.fileData);
    }
    setActiveMedia({
      src,
      type: resource.type === 'video' ? 'video' : 'audio',
      title: resource.title
    });
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const extension = file.name.split('.').pop()?.toLowerCase() || '';
    let type: Resource['type'] = 'mp3';
    let category = 'Music';

    if (file.type.startsWith('video/')) {
      type = 'video';
      category = 'Video';
    } else if (file.type.startsWith('audio/')) {
      type = extension === 'wav' ? 'wav' : 'mp3';
      category = 'Music';
    }

    const newRes: Resource = {
      id: uuidv4(),
      title: file.name,
      type: type,
      category: category,
      fileData: file,
      fileName: file.name,
      fileSize: file.size,
      subject: 'Imported Media',
      isFavorite: false,
      addedAt: new Date().toISOString(),
      synced: 0
    };

    await db.put('resourcesStore', newRes);
    e.target.value = '';
    // The parent component (App.tsx) should ideally refresh resources, 
    // but since we're using a prop 'resources', we might need a way to notify the parent.
    // For now, we'll assume the parent handles the refresh if it's listening to DB changes or if we force a reload.
    window.location.reload(); 
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-1">
          <h2 className="text-3xl font-display font-bold tracking-tight">Media Library</h2>
          <p className="text-slate-500 font-medium">Manage your video lectures and audio notes</p>
        </div>
        
        <div className="flex items-center gap-3">
          <label className="w-12 h-12 rounded-2xl glass-card border border-white/10 flex items-center justify-center text-slate-500 cursor-pointer thumb-button hover:text-brand-600 transition-colors">
            <FileUp size={20} />
            <input 
              type="file" 
              className="hidden" 
              accept="video/*,audio/*"
              onChange={handleImport}
            />
          </label>
          <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-2xl">
            <button 
              onClick={() => setViewMode('grid')}
              className={`p-2.5 rounded-xl transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-slate-800 text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <LayoutGrid size={20} />
            </button>
            <button 
              onClick={() => setViewMode('list')}
              className={`p-2.5 rounded-xl transition-all ${viewMode === 'list' ? 'bg-white dark:bg-slate-800 text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <ListIcon size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-8 relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-500 transition-colors" size={20} />
          <input 
            type="text"
            placeholder="Search media..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[1.5rem] outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all font-medium"
          />
        </div>
        <div className="md:col-span-4 flex gap-2">
          <select 
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as any)}
            className="flex-1 px-4 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[1.5rem] outline-none focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 transition-all font-bold text-sm appearance-none cursor-pointer"
          >
            <option value="all">All Media</option>
            <option value="video">Videos Only</option>
            <option value="audio">Audio Only</option>
          </select>
        </div>
      </div>

      {/* Media Grid/List */}
      {filtered.length > 0 ? (
        <div className={viewMode === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" : "space-y-3"}>
          <AnimatePresence mode="popLayout">
            {filtered.map((resource) => (
              <motion.div
                key={resource.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className={`group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-all hover:shadow-2xl hover:shadow-brand-500/10 hover:-translate-y-1 ${
                  viewMode === 'grid' ? 'rounded-[2rem] overflow-hidden' : 'rounded-2xl p-4 flex items-center gap-4'
                }`}
              >
                {viewMode === 'grid' ? (
                  <>
                    <div className="aspect-video bg-slate-100 dark:bg-slate-800 relative overflow-hidden">
                      <div className="absolute inset-0 flex items-center justify-center text-slate-300 group-hover:scale-110 transition-transform duration-500">
                        {resource.type === 'video' ? <Video size={48} /> : <Music size={48} />}
                      </div>
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button 
                          onClick={() => handlePlay(resource)}
                          className="w-14 h-14 bg-brand-600 text-white rounded-full flex items-center justify-center shadow-xl transform translate-y-4 group-hover:translate-y-0 transition-all duration-300"
                        >
                          <Play size={24} fill="currentColor" className="ml-1" />
                        </button>
                      </div>
                      {resource.isFavorite && (
                        <div className="absolute top-4 right-4 w-8 h-8 bg-amber-500 text-white rounded-full flex items-center justify-center shadow-lg">
                          <Star size={14} fill="currentColor" />
                        </div>
                      )}
                    </div>
                    <div className="p-6 space-y-3">
                      <div className="flex justify-between items-start gap-2">
                        <div className="min-w-0">
                          <h3 className="font-bold text-slate-900 dark:text-white truncate group-hover:text-brand-600 transition-colors">
                            {resource.title}
                          </h3>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                            {resource.subject}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => onToggleFavorite(resource.id)}
                            className={`p-2 rounded-xl transition-all ${resource.isFavorite ? 'text-amber-500 bg-amber-50 dark:bg-amber-900/20' : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                          >
                            <Star size={16} fill={resource.isFavorite ? "currentColor" : "none"} />
                          </button>
                          <button 
                            onClick={() => onDelete(resource.id)}
                            className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-xl transition-all"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 shrink-0">
                      {resource.type === 'video' ? <Video size={20} /> : <Music size={20} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-sm truncate">{resource.title}</h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{resource.subject}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handlePlay(resource)}
                        className="p-2 text-brand-600 hover:bg-brand-50 dark:hover:bg-brand-900/20 rounded-xl transition-all"
                      >
                        <Play size={18} fill="currentColor" />
                      </button>
                      <button 
                        onClick={() => onToggleFavorite(resource.id)}
                        className={`p-2 rounded-xl transition-all ${resource.isFavorite ? 'text-amber-500 bg-amber-50 dark:bg-amber-900/20' : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                      >
                        <Star size={18} fill={resource.isFavorite ? "currentColor" : "none"} />
                      </button>
                      <button 
                        onClick={() => onDelete(resource.id)}
                        className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-xl transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-6 bg-slate-50 dark:bg-slate-900/50 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-800">
          <div className="w-24 h-24 bg-white dark:bg-slate-900 rounded-[2rem] flex items-center justify-center text-slate-200 shadow-sm">
            <Video size={48} />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-bold">No media found</h3>
            <p className="text-slate-500 max-w-xs mx-auto">Import video lectures or audio notes in the Library to see them here.</p>
          </div>
        </div>
      )}

      {/* Media Player Overlay */}
      <AnimatePresence>
        {activeMedia && (
          <MediaPlayer 
            {...activeMedia}
            onClose={() => setActiveMedia(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
