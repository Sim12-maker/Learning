import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  CheckCircle2, 
  Circle, 
  Calendar, 
  Repeat, 
  Trash2, 
  X, 
  ChevronRight,
  Clock,
  Check,
  Bell,
  AlignLeft,
  AlertCircle,
  AlertTriangle,
  Info,
  MoreVertical,
  CheckSquare,
  Square,
  FolderInput
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db';
import { Task, RepeatInterval } from '../types';
import EmptyState from './EmptyState';

export default function Tasks({ onNavigate }: { onNavigate?: (view: any, taskId?: string) => void }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<string | null>(null);
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');
  
  // Batch selection state
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>([]);
  const [isBatchMoveModalOpen, setIsBatchMoveModalOpen] = useState(false);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const t = await db.getAll('tasksStore');
    setTasks(t);
  };

  const handleAddTask = async (taskData: Partial<Task>) => {
    if (editingTask) {
      const updatedTask = { ...editingTask, ...taskData, synced: 0 };
      await db.put('tasksStore', updatedTask);
      setEditingTask(null);
    } else {
      const newTask: Task = {
        id: uuidv4(),
        title: taskData.title || 'Untitled Task',
        completed: false,
        repeat: taskData.repeat || 'none',
        dueDate: taskData.dueDate || new Date().toISOString(),
        subject: taskData.subject || 'General',
        priority: taskData.priority || 'low',
        notes: taskData.notes || '',
        reminderMin: taskData.reminderMin || '0',
        reminderTime: taskData.reminderTime || '09:00',
        notificationType: taskData.notificationType || 'in-app',
        synced: 0,
      };
      await db.put('tasksStore', newTask);
      setIsAddModalOpen(false);
    }
    fetchTasks();
  };

  const toggleTask = async (task: Task) => {
    if (!task.completed && task.repeat !== 'none') {
      // For repeating tasks: advance the due date rather than duplicating
      const nextDate = new Date(task.dueDate);
      if (task.repeat === 'daily') nextDate.setDate(nextDate.getDate() + 1);
      if (task.repeat === 'weekly') nextDate.setDate(nextDate.getDate() + 7);
      if (task.repeat === 'monthly') nextDate.setMonth(nextDate.getMonth() + 1);
      const updated: Task = { ...task, dueDate: nextDate.toISOString(), completed: false, synced: 0 };
      await db.put('tasksStore', updated);
    } else {
      const updatedTask = { ...task, completed: !task.completed };
      await db.put('tasksStore', updatedTask);
    }
    fetchTasks();
  };

  const deleteTask = async (id: string) => {
    await db.delete('tasksStore', id);
    setDeletingTaskId(null);
    fetchTasks();
  };

  const clearCompletedTasks = async () => {
    const completedTasks = tasks.filter(t => t.completed);
    if (completedTasks.length === 0) return;
    
    for (const task of completedTasks) {
      await db.delete('tasksStore', task.id);
    }
    setIsClearConfirmOpen(false);
    fetchTasks();
  };

  // Batch Actions
  const handleBatchDelete = async () => {
    if (confirm(`Delete ${selectedTaskIds.length} tasks?`)) {
      for (const id of selectedTaskIds) {
        await db.delete('tasksStore', id);
      }
      setSelectedTaskIds([]);
      fetchTasks();
    }
  };

  const handleBatchComplete = async () => {
    const selectedTasks = tasks.filter(t => selectedTaskIds.includes(t.id));
    for (const task of selectedTasks) {
      if (!task.completed) {
        await toggleTask(task);
      }
    }
    setSelectedTaskIds([]);
    fetchTasks();
  };

  const handleBatchMove = async (newSubject: string) => {
    const selectedTasks = tasks.filter(t => selectedTaskIds.includes(t.id));
    const updatedTasks = selectedTasks.map(t => ({ ...t, subject: newSubject, synced: 0 }));
    await db.bulkPut('tasksStore', updatedTasks);
    setSelectedTaskIds([]);
    setIsBatchMoveModalOpen(false);
    fetchTasks();
  };

  const toggleSelection = (id: string) => {
    setSelectedTaskIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const filteredTasks = tasks.filter(t => {
    if (filter === 'pending') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  }).sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

  return (
    <div className="px-6 pb-12 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-center pt-4">
        <div className="flex flex-col">
          <h1 className="text-3xl font-display font-bold tracking-tight">Tasks</h1>
          {selectedTaskIds.length > 0 && (
            <span className="text-[10px] font-bold text-brand-600 uppercase tracking-widest mt-1">
              {selectedTaskIds.length} Selected
            </span>
          )}
        </div>
        <div className="flex gap-2">
          {selectedTaskIds.length > 0 ? (
            <div className="flex gap-2 glass-morphism p-1 rounded-2xl border border-white/10">
              <button 
                onClick={handleBatchComplete}
                className="w-10 h-10 rounded-xl bg-white/10 text-emerald-500 flex items-center justify-center shadow-sm"
                title="Mark Selected as Completed"
              >
                <CheckCircle2 size={18} />
              </button>
              <button 
                onClick={() => setIsBatchMoveModalOpen(true)}
                className="w-10 h-10 rounded-xl bg-white/10 text-brand-500 flex items-center justify-center shadow-sm"
                title="Move to Subject"
              >
                <FolderInput size={18} />
              </button>
              <button 
                onClick={handleBatchDelete}
                className="w-10 h-10 rounded-xl bg-white/10 text-rose-500 flex items-center justify-center shadow-sm"
                title="Delete Selected"
              >
                <Trash2 size={18} />
              </button>
              <button 
                onClick={() => setSelectedTaskIds([])}
                className="w-10 h-10 rounded-xl bg-white/10 text-slate-400 flex items-center justify-center shadow-sm"
                title="Clear Selection"
              >
                <X size={18} />
              </button>
            </div>
          ) : (
            <>
              {tasks.some(t => t.completed) && (
                <button 
                  onClick={() => setIsClearConfirmOpen(true)}
                  className="w-12 h-12 rounded-2xl glass-card flex items-center justify-center text-slate-500 hover:text-rose-500 transition-colors thumb-button"
                  title="Clear Completed Tasks"
                >
                  <Trash2 size={20} />
                </button>
              )}
              <button 
                onClick={() => setIsAddModalOpen(true)}
                className="w-12 h-12 rounded-2xl bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
              >
                <Plus size={24} />
              </button>
            </>
          )}
        </div>
      </header>

      {/* Filter Tabs */}
      <div className="flex p-1 glass-morphism rounded-2xl border border-white/10">
        {(['pending', 'completed', 'all'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`flex-1 py-2 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all ${
              filter === f 
                ? 'bg-white/20 dark:bg-white/10 text-brand-600 dark:text-brand-400 shadow-sm' 
                : 'text-slate-400'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Tasks List */}
      <div className="space-y-3">
        {filteredTasks.length > 0 ? (
          <AnimatePresence mode="popLayout">
            {filteredTasks.map(task => (
                <motion.div 
                layout
                key={task.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`group relative glass-card p-5 rounded-[2rem] border-white/10 flex items-center gap-4 transition-all ${
                  task.completed ? 'opacity-60 grayscale-[0.5]' : ''
                } ${
                  !task.completed && task.priority === 'high' ? 'bg-rose-50/30 dark:bg-rose-900/10 border-rose-100 dark:border-rose-900/20' : 
                  !task.completed && task.priority === 'medium' ? 'bg-amber-50/30 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/20' : 
                  !task.completed && task.priority === 'low' ? 'bg-emerald-50/30 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900/20' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => toggleSelection(task.id)}
                    className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
                      selectedTaskIds.includes(task.id)
                        ? 'bg-brand-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-300 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {selectedTaskIds.includes(task.id) ? <CheckSquare size={14} /> : <Square size={14} />}
                  </button>

                  <button 
                    onClick={() => toggleTask(task)}
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all relative overflow-hidden ${
                      task.completed 
                        ? 'bg-emerald-500 text-white' 
                        : 'bg-slate-50 dark:bg-slate-950 text-slate-300 border border-slate-100 dark:border-slate-800'
                    }`}
                  >
                    {task.completed ? (
                      <motion.div
                        initial={{ scale: 0, rotate: -45 }}
                        animate={{ scale: 1, rotate: 0 }}
                        className="relative z-10"
                      >
                        <Check size={20} strokeWidth={3} />
                        {/* Flourish Animation */}
                        <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: [0, 1.5, 0] }}
                          transition={{ duration: 0.5 }}
                          className="absolute inset-0 bg-white/40 rounded-full -z-10"
                        />
                      </motion.div>
                    ) : (
                      <Circle size={20} />
                    )}
                  </button>
                </div>

                <div 
                  className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => setEditingTask(task)}
                >
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="px-1.5 py-0.5 bg-brand-50 dark:bg-brand-900/20 text-[7px] font-bold text-brand-600 dark:text-brand-400 uppercase tracking-widest rounded-md">
                      {task.subject}
                    </span>
                    {task.priority && (
                      <span className={`px-1.5 py-0.5 text-[7px] font-bold uppercase tracking-widest rounded-md flex items-center gap-1 ${
                        task.priority === 'high' 
                          ? 'bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400' 
                          : task.priority === 'medium'
                            ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400'
                            : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                      }`}>
                        {task.priority === 'high' && <AlertCircle size={8} />}
                        {task.priority === 'medium' && <AlertTriangle size={8} />}
                        {task.priority === 'low' && <Info size={8} />}
                        {task.priority}
                      </span>
                    )}
                    {task.repeat !== 'none' && (
                      <span className="flex items-center gap-0.5 text-[7px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">
                        <Repeat size={8} /> {task.repeat}
                      </span>
                    )}
                  </div>
                  <h4 className={`font-bold text-sm tracking-tight truncate flex items-center gap-2 ${task.completed ? 'line-through' : ''}`}>
                    {task.priority === 'high' && <AlertCircle size={16} className="text-rose-500 shrink-0" />}
                    {task.priority === 'medium' && <AlertTriangle size={16} className="text-amber-500 shrink-0" />}
                    {task.priority === 'low' && <Info size={16} className="text-emerald-500 shrink-0" />}
                    {task.title}
                  </h4>
                  <div className="flex items-center gap-3 mt-1 text-[10px] text-slate-400 font-medium">
                    <span className="flex items-center gap-1"><Calendar size={10} /> {new Date(task.dueDate).toLocaleDateString()}</span>
                    {task.reminderMin && task.reminderMin !== '0' && (
                      <span className="flex items-center gap-1 text-emerald-500"><Bell size={10} /> {task.reminderMin}m</span>
                    )}
                  </div>
                  {task.notes && (
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-1 italic">{task.notes}</p>
                  )}
                </div>

                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {!task.completed && onNavigate && (
                    <button 
                      onClick={() => onNavigate('timetable', task.id)}
                      className="p-3 text-slate-300 hover:text-brand-500 transition-colors"
                      title="Schedule Task"
                    >
                      <Calendar size={18} />
                    </button>
                  )}
                  <button 
                    onClick={() => setDeletingTaskId(task.id)}
                    className="p-3 text-slate-300 hover:text-rose-500 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        ) : (
          <EmptyState 
            icon={CheckCircle2}
            title={filter === 'completed' ? "No completed tasks" : "All caught up!"}
            message={filter === 'completed' ? "Finish some tasks to see them here." : "You've finished all your pending tasks. Take a break!"}
            action={filter !== 'completed' ? {
              label: "Add New Task",
              onClick: () => setIsAddModalOpen(true)
            } : undefined}
          />
        )}
      </div>

      {/* Add/Edit Task Modal */}
      <AnimatePresence>
        {(isAddModalOpen || editingTask) && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsAddModalOpen(false);
                setEditingTask(null);
              }}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 space-y-6">
                <header className="flex justify-between items-center">
                  <h2 className="text-xl font-display font-bold">{editingTask ? 'Edit Task' : 'New Task'}</h2>
                  <button onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingTask(null);
                  }} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                    <X size={20} />
                  </button>
                </header>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Task Title</label>
                    <input 
                      id="task-title" 
                      type="text" 
                      defaultValue={editingTask?.title || ''}
                      placeholder="e.g. Complete Lab Report" 
                      className="premium-input" 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Subject</label>
                      <input 
                        id="task-subject" 
                        type="text" 
                        defaultValue={editingTask?.subject || ''}
                        placeholder="e.g. Physics" 
                        className="premium-input" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Due Date</label>
                      <input 
                        id="task-date" 
                        type="date" 
                        defaultValue={editingTask ? new Date(editingTask.dueDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]} 
                        className="premium-input" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Reminder</label>
                      <select 
                        id="task-reminder" 
                        defaultValue={editingTask?.reminderMin || '0'}
                        className="premium-input appearance-none"
                      >
                        <option value="0">No Reminder</option>
                        <option value="5">5 mins before</option>
                        <option value="10">10 mins before</option>
                        <option value="15">15 mins before</option>
                        <option value="30">30 mins before</option>
                        <option value="60">1 hour before</option>
                        <option value="1440">1 day before</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Reminder Time</label>
                      <input 
                        id="task-reminder-time" 
                        type="time" 
                        defaultValue={editingTask?.reminderTime || '09:00'}
                        className="premium-input" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Notify Via</label>
                      <select 
                        id="task-notify-type" 
                        defaultValue={editingTask?.notificationType || 'in-app'}
                        className="premium-input appearance-none"
                      >
                        <option value="in-app">In-App Alert</option>
                        <option value="push">Push Notification</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Priority</label>
                      <select 
                        id="task-priority" 
                        defaultValue={editingTask?.priority || 'low'}
                        className="premium-input appearance-none"
                      >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                      </select>
                    </div>
                  </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Repeat</label>
                      <div className="flex gap-1">
                        {(['none', 'daily', 'weekly', 'monthly'] as RepeatInterval[]).map(r => (
                          <button
                            key={r}
                            type="button"
                            onClick={() => {
                              const btns = document.querySelectorAll('.repeat-btn');
                              btns.forEach(b => b.classList.remove('bg-brand-600', 'text-white'));
                              btns.forEach(b => b.classList.add('bg-slate-50', 'dark:bg-slate-950', 'text-slate-400'));
                              const btn = document.getElementById(`repeat-${r}`);
                              btn?.classList.remove('bg-slate-50', 'dark:bg-slate-950', 'text-slate-400');
                              btn?.classList.add('bg-brand-600', 'text-white');
                              (document.getElementById('task-repeat') as HTMLInputElement).value = r;
                            }}
                            id={`repeat-${r}`}
                            className={`repeat-btn flex-1 py-3 text-[7px] font-bold uppercase tracking-widest rounded-xl border border-slate-100 dark:border-slate-800 transition-all ${
                              (editingTask?.repeat || 'none') === r ? 'bg-brand-600 text-white' : 'bg-slate-50 dark:bg-slate-950 text-slate-400'
                            }`}
                          >
                            {r}
                          </button>
                        ))}
                        <input type="hidden" id="task-repeat" defaultValue={editingTask?.repeat || 'none'} />
                      </div>
                    </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Notes</label>
                    <textarea 
                      id="task-notes" 
                      defaultValue={editingTask?.notes || ''}
                      placeholder="Add details or context..." 
                      rows={3}
                      className="premium-input resize-none" 
                    />
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => {
                      setIsAddModalOpen(false);
                      setEditingTask(null);
                    }}
                    className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      const title = (document.getElementById('task-title') as HTMLInputElement).value;
                      const subject = (document.getElementById('task-subject') as HTMLInputElement).value;
                      const dueDate = (document.getElementById('task-date') as HTMLInputElement).value;
                      const repeat = (document.getElementById('task-repeat') as HTMLInputElement).value as RepeatInterval;
                      const priority = (document.getElementById('task-priority') as HTMLSelectElement).value as any;
                      const notes = (document.getElementById('task-notes') as HTMLTextAreaElement).value;
                      const reminderMin = (document.getElementById('task-reminder') as HTMLSelectElement).value;
                      const reminderTime = (document.getElementById('task-reminder-time') as HTMLInputElement).value;
                      const notificationType = (document.getElementById('task-notify-type') as HTMLSelectElement).value as any;
                      handleAddTask({ title, subject, dueDate: new Date(dueDate).toISOString(), repeat, priority, notes, reminderMin, reminderTime, notificationType });
                    }}
                    className="flex-1 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
                  >
                    {editingTask ? 'Update Task' : 'Create Task'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Batch Move Modal */}
      <AnimatePresence>
        {isBatchMoveModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsBatchMoveModalOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl p-8 space-y-6"
            >
              <div className="space-y-2 text-center">
                <h3 className="text-xl font-display font-bold">Move to Subject</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Select a subject for the {selectedTaskIds.length} selected tasks.</p>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Subject Name</label>
                <input 
                  id="batch-move-subject" 
                  type="text" 
                  placeholder="e.g. Mathematics" 
                  className="premium-input" 
                />
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setIsBatchMoveModalOpen(false)}
                  className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl thumb-button"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => {
                    const subject = (document.getElementById('batch-move-subject') as HTMLInputElement).value;
                    if (subject) handleBatchMove(subject);
                  }}
                  className="flex-1 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
                >
                  Move
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingTaskId && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeletingTaskId(null)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-sm bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl p-8 text-center space-y-6"
            >
              <div className="w-20 h-20 bg-rose-100 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-full flex items-center justify-center mx-auto">
                <Trash2 size={32} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-display font-bold">Delete Task?</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">This action cannot be undone. Are you sure you want to permanently remove this task?</p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setDeletingTaskId(null)}
                  className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl thumb-button"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => deleteTask(deletingTaskId)}
                  className="flex-1 py-4 bg-rose-600 text-white font-bold rounded-2xl shadow-lg shadow-rose-200 dark:shadow-none thumb-button"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Clear Completed Confirmation Modal */}
      <AnimatePresence>
        {isClearConfirmOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsClearConfirmOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl p-8 text-center space-y-6"
            >
              <div className="w-20 h-20 bg-rose-100 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-full flex items-center justify-center mx-auto">
                <Trash2 size={32} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-display font-bold">Clear Completed?</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">This will permanently remove all {tasks.filter(t => t.completed).length} completed tasks. Are you sure?</p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setIsClearConfirmOpen(false)}
                  className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl thumb-button"
                >
                  Cancel
                </button>
                <button 
                  onClick={clearCompletedTasks}
                  className="flex-1 py-4 bg-rose-600 text-white font-bold rounded-2xl shadow-lg shadow-rose-200 dark:shadow-none thumb-button"
                >
                  Clear All
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
