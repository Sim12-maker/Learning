import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  X,
  RotateCcw,
  RotateCw,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MediaPlayerProps {
  src: string;
  type: 'video' | 'audio';
  title: string;
  onClose: () => void;
}

export default function MediaPlayer({ src, type, title, onClose }: MediaPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [showSettings, setShowSettings] = useState(false);
  
  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const media = mediaRef.current;
    if (!media) return;

    const handleTimeUpdate = () => setCurrentTime(media.currentTime);
    const handleLoadedMetadata = () => setDuration(media.duration);
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    media.addEventListener('timeupdate', handleTimeUpdate);
    media.addEventListener('loadedmetadata', handleLoadedMetadata);
    media.addEventListener('play', handlePlay);
    media.addEventListener('pause', handlePause);

    return () => {
      media.removeEventListener('timeupdate', handleTimeUpdate);
      media.removeEventListener('loadedmetadata', handleLoadedMetadata);
      media.removeEventListener('play', handlePlay);
      media.removeEventListener('pause', handlePause);
    };
  }, []);

  const togglePlay = () => {
    if (mediaRef.current) {
      if (isPlaying) mediaRef.current.pause();
      else mediaRef.current.play();
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    if (mediaRef.current) {
      mediaRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    if (mediaRef.current) mediaRef.current.volume = val;
    if (val === 0) setIsMuted(true);
    else setIsMuted(false);
  };

  const toggleMute = () => {
    if (mediaRef.current) {
      mediaRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const skip = (seconds: number) => {
    if (mediaRef.current) {
      mediaRef.current.currentTime += seconds;
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;

    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const formatTime = (time: number) => {
    const h = Math.floor(time / 3600);
    const m = Math.floor((time % 3600) / 60);
    const s = Math.floor(time % 60);
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  return (
    <motion.div 
      ref={containerRef}
      layout
      initial={isMinimized ? { width: 200, height: 60, bottom: 24, right: 24 } : { opacity: 0 }}
      animate={isMinimized 
        ? { width: 300, height: 80, bottom: 24, right: 24, borderRadius: 24 } 
        : { opacity: 1, inset: 0, borderRadius: 0 }
      }
      className={`fixed z-[200] bg-black flex items-center justify-center overflow-hidden shadow-2xl ${
        isMinimized ? 'bottom-6 right-6' : 'inset-0'
      }`}
      onMouseMove={handleMouseMove}
    >
      <div className="absolute top-4 right-4 z-[210] flex items-center gap-2">
        <button 
          onClick={() => setIsMinimized(!isMinimized)}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/60 transition-all"
          title={isMinimized ? "Expand" : "Minimize"}
        >
          {isMinimized ? <Maximize size={18} /> : <Minimize size={18} />}
        </button>
        <button 
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/60 transition-all"
        >
          <X size={18} />
        </button>
      </div>

      {isMinimized ? (
        <div className="w-full h-full flex items-center gap-4 px-4 bg-slate-900/90 backdrop-blur-xl border border-white/10">
          <div className="w-12 h-12 rounded-xl bg-brand-600 flex items-center justify-center text-white shrink-0">
            {isPlaying ? <Pause size={20} fill="currentColor" onClick={togglePlay} className="cursor-pointer" /> : <Play size={20} fill="currentColor" onClick={togglePlay} className="cursor-pointer ml-0.5" />}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-white font-bold text-xs truncate">{title}</h3>
            <p className="text-slate-400 text-[10px] uppercase tracking-widest">{type}</p>
          </div>
          <div className="text-white/40 text-[10px] font-mono">
            {formatTime(currentTime)}
          </div>
        </div>
      ) : (
        <>
          {type === 'video' ? (
            <video 
              ref={mediaRef as React.RefObject<HTMLVideoElement>}
              src={src}
              className="w-full h-full object-contain"
              onClick={togglePlay}
              playsInline
              autoPlay
            />
          ) : (
            <div className="flex flex-col items-center gap-8">
              <div className="w-64 h-64 bg-slate-900 rounded-[3rem] flex items-center justify-center text-brand-500 shadow-2xl border border-white/10 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-brand-500/20 to-transparent opacity-50" />
                <motion.div
                  animate={isPlaying ? { scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] } : {}}
                  transition={{ repeat: Infinity, duration: 4 }}
                >
                  <Play size={120} fill="currentColor" />
                </motion.div>
              </div>
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-display font-bold text-white tracking-tight">{title}</h2>
                <p className="text-slate-400 font-medium uppercase tracking-widest text-xs">Audio Resource</p>
              </div>
              <audio 
                ref={mediaRef as React.RefObject<HTMLAudioElement>}
                src={src}
                autoPlay
              />
            </div>
          )}

          {/* Controls Overlay */}
          <AnimatePresence>
            {showControls && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-8 pt-20 space-y-6"
              >
                {/* Progress Bar */}
                <div className="group relative h-1.5 bg-white/20 rounded-full cursor-pointer">
                  <input 
                    type="range" 
                    min="0" 
                    max={duration || 0} 
                    value={currentTime} 
                    onChange={handleSeek}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div 
                    className="absolute inset-y-0 left-0 bg-brand-500 rounded-full"
                    style={{ width: `${(currentTime / duration) * 100}%` }}
                  />
                  <div 
                    className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-xl opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ left: `${(currentTime / duration) * 100}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-white">
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-4">
                      <button onClick={() => skip(-10)} className="hover:text-brand-400 transition-colors"><RotateCcw size={24} /></button>
                      <button 
                        onClick={togglePlay}
                        className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                      >
                        {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
                      </button>
                      <button onClick={() => skip(10)} className="hover:text-brand-400 transition-colors"><RotateCw size={24} /></button>
                    </div>

                    <div className="flex items-center gap-4 group">
                      <button onClick={toggleMute} className="hover:text-brand-400 transition-colors">
                        {isMuted || volume === 0 ? <VolumeX size={24} /> : <Volume2 size={24} />}
                      </button>
                      <div className="w-0 group-hover:w-24 overflow-hidden transition-all duration-300">
                        <input 
                          type="range" 
                          min="0" 
                          max="1" 
                          step="0.01" 
                          value={volume} 
                          onChange={handleVolumeChange}
                          className="w-24 accent-brand-500"
                        />
                      </div>
                    </div>

                    <div className="text-sm font-mono font-medium tracking-wider">
                      {formatTime(currentTime)} <span className="text-white/40">/</span> {formatTime(duration)}
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="relative">
                      <button 
                        onClick={() => setShowSettings(!showSettings)}
                        className={`hover:text-brand-400 transition-colors ${showSettings ? 'text-brand-400' : ''}`}
                      >
                        <Settings size={24} />
                      </button>
                      <AnimatePresence>
                        {showSettings && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.9, y: -10 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.9, y: -10 }}
                            className="absolute bottom-full right-0 mb-4 bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-2xl p-4 min-w-[160px] shadow-2xl"
                          >
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 px-2">Playback Speed</p>
                            <div className="space-y-1">
                              {[0.5, 0.75, 1, 1.25, 1.5, 2].map(speed => (
                                <button
                                  key={speed}
                                  onClick={() => {
                                    setPlaybackSpeed(speed);
                                    if (mediaRef.current) mediaRef.current.playbackRate = speed;
                                    setShowSettings(false);
                                  }}
                                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                                    playbackSpeed === speed ? 'bg-brand-600 text-white' : 'hover:bg-white/10 text-slate-300'
                                  }`}
                                >
                                  {speed}x {speed === 1 && '(Normal)'}
                                </button>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                    {type === 'video' && (
                      <button onClick={toggleFullscreen} className="hover:text-brand-400 transition-colors">
                        {isFullscreen ? <Minimize size={24} /> : <Maximize size={24} />}
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </motion.div>
  );
}
