import React, { useState, useEffect, useRef, useMemo, Suspense } from 'react';
import DOMPurify from 'dompurify';
import { 
  Plus, 
  Search, 
  Tag, 
  Calendar, 
  Share2, 
  Pencil, 
  Trash2, 
  X,
  NotebookPen,
  Image as ImageIcon,
  Clock,
  FileText,
  Code,
  Save,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db';
import { Note, TimetableEvent } from '../types';
import EmptyState from './EmptyState';
import { useNotes } from '../hooks/useNotes';
import { noteService } from '../services/noteService';

const ReactQuill = React.lazy(() => import('react-quill-new'));
import 'react-quill-new/dist/quill.snow.css';

export default function Notes({ initialEventId = 'All' }: { initialEventId?: string }) {
  const [searchQuery, setSearchQuery] = useState('');
  const { notes, filteredNotes, loading, saveNote, deleteNote, refresh } = useNotes(searchQuery);
  
  const [events, setEvents] = useState<TimetableEvent[]>([]);
  const [subjectColors, setSubjectColors] = useState<Record<string, string>>({});
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [selectedEventId, setSelectedEventId] = useState(initialEventId);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [editorContent, setEditorContent] = useState('');
  const [isHtmlMode, setIsHtmlMode] = useState(false);
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [hasDraft, setHasDraft] = useState(false);
  
  const quillRef = useRef<any>(null);

  useEffect(() => {
    fetchExtraData();
  }, []);

  useEffect(() => {
    setSelectedEventId(initialEventId);
  }, [initialEventId]);

  useEffect(() => {
    if (editingNote) {
      checkDraft(editingNote.id);
      setEditorContent(editingNote.content);
    } else {
      setEditorContent('');
      setHasDraft(false);
    }
  }, [editingNote]);

  // Auto-save logic
  useEffect(() => {
    if (!editingNote || !isModalOpen) return;
    
    const timer = setTimeout(async () => {
      setIsAutoSaving(true);
      await noteService.saveDraft(editingNote.id, editorContent);
      setIsAutoSaving(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, [editorContent, editingNote, isModalOpen]);

  const fetchExtraData = async () => {
    const e = await db.getAll('timetableStore');
    const sc = await db.getAll('subjectColorsStore');
    
    const colorsMap: Record<string, string> = {};
    sc.forEach(item => {
      colorsMap[item.id] = item.colorName;
    });

    setEvents(e);
    setSubjectColors(colorsMap);
  };

  const checkDraft = async (noteId: string) => {
    const draft = await noteService.getDraft(noteId);
    if (draft) setHasDraft(true);
  };

  const recoverDraft = async () => {
    if (!editingNote) return;
    const draft = await noteService.getDraft(editingNote.id);
    if (draft) {
      setEditorContent(draft.content);
      setHasDraft(false);
    }
  };

  const subjects = useMemo(() => ['All', ...new Set(notes.map(n => n.subject))], [notes]);

  const finalFilteredNotes = useMemo(() => {
    return filteredNotes.filter(n => {
      const matchesSubject = selectedSubject === 'All' || n.subject === selectedSubject;
      const matchesEvent = selectedEventId === 'All' || n.eventId === selectedEventId;
      return matchesSubject && matchesEvent;
    });
  }, [filteredNotes, selectedSubject, selectedEventId]);

  const handleSave = async (noteData: Partial<Note>) => {
    const newNote: Note = {
      id: editingNote?.id || uuidv4(),
      title: noteData.title || 'Untitled Note',
      content: noteData.content || '',
      subject: noteData.subject || 'General',
      tags: noteData.tags || [],
      eventId: noteData.eventId || '',
      updatedAt: new Date().toISOString(),
      synced: 0,
    };
    await saveNote(newNote);
    if (editingNote) {
      await noteService.clearDraft(editingNote.id);
    }
    setIsModalOpen(false);
    setEditingNote(null);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this note?')) {
      await deleteNote(id);
    }
  };

  const handleShare = async (note: Note) => {
    const text = `--- ${note.title} ---\nSubject: ${note.subject}\n\n${note.content.replace(/<[^>]*>/g, '')}\n\nShared from StudyPro`;
    try {
      await navigator.clipboard.writeText(text);
      alert('Note copied to clipboard!');
    } catch (err) {
      alert('Failed to copy note.');
    }
  };

  const getWordCount = (html: string) => {
    const text = html.replace(/<[^>]*>/g, ' ').trim();
    return text ? text.split(/\s+/).length : 0;
  };

  const getReadingTime = (html: string) => {
    const words = getWordCount(html);
    const mins = Math.ceil(words / 200);
    return mins;
  };

  const getSubjectColorClasses = (subject: string) => {
    const colorName = subjectColors[subject] || 'Brand';
    const colors: Record<string, any> = {
      'Brand': { bg: 'bg-brand-100 dark:bg-brand-900/30', text: 'text-brand-600 dark:text-brand-400' },
      'Rose': { bg: 'bg-rose-100 dark:bg-rose-900/30', text: 'text-rose-600 dark:text-rose-400' },
      'Amber': { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-600 dark:text-amber-400' },
      'Emerald': { bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-600 dark:text-emerald-400' },
      'Blue': { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400' },
      'Indigo': { bg: 'bg-indigo-100 dark:bg-indigo-900/30', text: 'text-indigo-600 dark:text-indigo-400' },
      'Violet': { bg: 'bg-violet-100 dark:bg-violet-900/30', text: 'text-violet-600 dark:text-violet-400' },
    };
    return colors[colorName] || colors['Brand'];
  };

  return (
    <div className="px-6 pb-12 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-center pt-4">
        <h1 className="text-3xl font-display font-bold tracking-tight">My Notes</h1>
        <button 
          onClick={() => { setEditingNote(null); setIsModalOpen(true); }}
          className="w-12 h-12 rounded-2xl bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
        >
          <Plus size={24} />
        </button>
      </header>

      {/* Search & Filter */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search notes (fuzzy search enabled)..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="premium-input pl-12"
          />
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {subjects.map(sub => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedSubject === sub 
                  ? 'bg-brand-600 text-white' 
                  : 'glass-card text-slate-600 dark:text-slate-400 border-white/10'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>

        {events.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            <button
              onClick={() => setSelectedEventId('All')}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedEventId === 'All' 
                  ? 'bg-emerald-600 text-white' 
                  : 'glass-card text-slate-600 dark:text-slate-400 border-white/10'
              }`}
            >
              All Events
            </button>
            {events.map(event => (
              <button
                key={event.id}
                onClick={() => setSelectedEventId(event.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedEventId === event.id 
                    ? 'bg-emerald-600 text-white' 
                    : 'glass-card text-slate-600 dark:text-slate-400 border-white/10'
                }`}
              >
                {event.subject}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {finalFilteredNotes.map(note => {
          const linkedEvent = events.find(e => e.id === note.eventId);
          return (
            <motion.div 
              layout
              key={note.id}
              className="glass-card p-6 rounded-[2rem] border-white/10 flex flex-col gap-4"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 ${getSubjectColorClasses(note.subject).bg} text-[8px] font-bold ${getSubjectColorClasses(note.subject).text} uppercase tracking-widest rounded-md`}>
                    {note.subject}
                  </span>
                  {note.synced === 0 && (
                    <span className="flex items-center gap-1 px-1.5 py-0.5 bg-amber-100 dark:bg-amber-900/30 text-[7px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest rounded-md">
                      <Clock size={8} /> Not synced
                    </span>
                  )}
                </div>
                <span className="text-[8px] text-slate-400 font-medium">
                  {new Date(note.updatedAt).toLocaleDateString()}
                </span>
              </div>
              
              <div>
                <h3 className="font-bold text-lg tracking-tight mb-1">{note.title}</h3>
                <div 
                  className="text-slate-500 text-sm line-clamp-3 prose prose-sm dark:prose-invert max-w-none"
                  dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(note.content) }}
                />
              </div>

              <div className="flex items-center gap-4 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                <span className="flex items-center gap-1"><FileText size={10} /> {getWordCount(note.content)} words</span>
                <span className="flex items-center gap-1"><Clock size={10} /> {getReadingTime(note.content)} min read</span>
              </div>

              {linkedEvent && (
                <div className="p-2 bg-brand-100 dark:bg-brand-900/20 rounded-xl border border-brand-100 dark:border-brand-800/50 flex items-center gap-2">
                  <Calendar size={14} className="text-brand-600 dark:text-brand-400" />
                  <span className="text-[10px] font-bold text-brand-700 dark:text-brand-300 truncate">
                    Linked: {linkedEvent.subject}
                  </span>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {note.tags.map(tag => (
                  <span key={tag} className="px-2 py-1 bg-slate-100 dark:bg-slate-800 text-slate-500 text-[9px] font-bold rounded-lg uppercase">
                    #{tag}
                  </span>
                ))}
              </div>

              <div className="mt-auto pt-4 flex justify-between items-center border-t border-slate-100 dark:border-slate-800">
                <div className="flex gap-4">
                  <button onClick={() => handleShare(note)} className="text-slate-400 hover:text-emerald-500 transition-colors">
                    <Share2 size={18} />
                  </button>
                  <button onClick={() => { setEditingNote(note); setIsModalOpen(true); }} className="text-slate-400 hover:text-brand-500 transition-colors">
                    <Pencil size={18} />
                  </button>
                </div>
                <button onClick={() => handleDelete(note.id)} className="text-slate-400 hover:text-rose-500 transition-colors">
                  <Trash2 size={18} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {finalFilteredNotes.length === 0 && (
        <EmptyState 
          icon={NotebookPen}
          title={searchQuery ? "No matching notes" : "Your notebook is empty"}
          message={searchQuery ? `We couldn't find any notes matching "${searchQuery}". Try a different search term.` : "Start capturing your thoughts, lecture notes, and study materials here."}
          action={!searchQuery ? {
            label: "Create First Note",
            onClick: () => { setEditingNote(null); setIsModalOpen(true); }
          } : undefined}
        />
      )}

      {/* Note Editor Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-4xl bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col h-full md:h-[90vh]"
            >
              <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-950">
                <div className="flex flex-col">
                  <h2 className="text-xl font-display font-bold">{editingNote ? 'Edit Note' : 'New Note'}</h2>
                  {isAutoSaving && <span className="text-[8px] font-bold text-emerald-500 uppercase tracking-widest">Auto-saving...</span>}
                </div>
                <div className="flex items-center gap-2">
                  {hasDraft && (
                    <button 
                      onClick={recoverDraft}
                      className="flex items-center gap-2 px-3 py-1.5 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 text-[10px] font-bold rounded-xl border border-amber-200 dark:border-amber-800"
                    >
                      <AlertCircle size={14} /> Recover Draft
                    </button>
                  )}
                  <button 
                    onClick={() => setIsHtmlMode(!isHtmlMode)}
                    className={`p-2 rounded-xl transition-colors ${isHtmlMode ? 'bg-brand-600 text-white' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400'}`}
                    title="Toggle HTML Mode"
                  >
                    <Code size={20} />
                  </button>
                  <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                    <X size={20} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Title</label>
                    <input 
                      id="edit-title"
                      type="text" 
                      defaultValue={editingNote?.title || ''}
                      placeholder="What's this about?"
                      className="premium-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Subject</label>
                    <input 
                      id="edit-subject"
                      type="text" 
                      defaultValue={editingNote?.subject || 'General'}
                      placeholder="e.g. Physics"
                      className="premium-input"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Link to Event</label>
                  <select 
                    id="edit-event"
                    defaultValue={editingNote?.eventId || ''}
                    className="premium-input appearance-none"
                  >
                    <option value="">No linked event</option>
                    {events.map(e => (
                      <option key={e.id} value={e.id}>{e.subject} ({e.day})</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2 flex-1 flex flex-col">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Content</label>
                    <div className="flex items-center gap-3 text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                      <span>{getWordCount(editorContent)} words</span>
                      <span>{getReadingTime(editorContent)} min read</span>
                    </div>
                  </div>
                  
                  <div className="flex-1 min-h-[400px] bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 overflow-hidden flex flex-col">
                    {isHtmlMode ? (
                      <textarea
                        value={editorContent}
                        onChange={(e) => setEditorContent(e.target.value)}
                        className="w-full h-full p-4 font-mono text-sm bg-slate-950 text-emerald-400 outline-none resize-none"
                        placeholder="Edit raw HTML..."
                      />
                    ) : (
                      <Suspense fallback={<div className="p-8 text-center text-slate-400">Loading editor...</div>}>
                        <ReactQuill 
                          ref={quillRef}
                          theme="snow"
                          value={editorContent}
                          onChange={setEditorContent}
                          placeholder="Start writing your notes..."
                          modules={{
                            toolbar: [
                              [{ 'header': [1, 2, 3, false] }],
                              ['bold', 'italic', 'underline', 'strike'],
                              [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                              ['link', 'image'],
                              ['clean']
                            ],
                          }}
                          className="h-full flex-1"
                        />
                      </Suspense>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Tags (comma separated)</label>
                  <input 
                    id="edit-tags"
                    type="text" 
                    defaultValue={editingNote?.tags.join(', ') || ''}
                    placeholder="physics, exam, chapter1"
                    className="premium-input"
                  />
                </div>
              </div>

              <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-950 flex gap-3">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => {
                    const title = (document.getElementById('edit-title') as HTMLInputElement).value;
                    const subject = (document.getElementById('edit-subject') as HTMLInputElement).value;
                    const eventId = (document.getElementById('edit-event') as HTMLSelectElement).value;
                    const content = editorContent;
                    const tags = (document.getElementById('edit-tags') as HTMLInputElement).value.split(',').map(t => t.trim()).filter(t => t);
                    handleSave({ title, subject, eventId, content, tags });
                  }}
                  className="flex-1 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button flex items-center justify-center gap-2"
                >
                  <Save size={20} />
                  {editingNote ? 'Update Note' : 'Create Note'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
