import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  Bell, 
  Download, 
  Trash2, 
  X,
  ChevronRight,
  NotebookPen,
  List,
  ChevronLeft,
  CalendarDays,
  Grid,
  AlertTriangle,
  GripVertical,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  format, 
  addDays, 
  addWeeks, 
  addMonths, 
  isSameDay, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  startOfWeek, 
  endOfWeek,
  parseISO,
  isAfter,
  isBefore,
  startOfDay,
  getDay,
  setHours,
  setMinutes,
  addMinutes
} from 'date-fns';
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db';
import { TimetableEvent, Day, Note, RepeatInterval, Task } from '../types';
import { useTimetable } from '../hooks/useTimetable';
import { timetableService } from '../services/timetableService';
import EmptyState from './EmptyState';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const DAYS: Day[] = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const EVENT_COLORS = [
  { name: 'Brand', bg: 'bg-brand-100 dark:bg-brand-900/30', text: 'text-brand-600 dark:text-brand-400', border: 'border-brand-100 dark:border-brand-800/50', hex: '#4f46e5' },
  { name: 'Rose', bg: 'bg-rose-100 dark:bg-rose-900/30', text: 'text-rose-600 dark:text-rose-400', border: 'border-rose-100 dark:border-rose-800/50', hex: '#e11d48' },
  { name: 'Amber', bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-600 dark:text-amber-400', border: 'border-amber-100 dark:border-amber-800/50', hex: '#d97706' },
  { name: 'Emerald', bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-600 dark:text-emerald-400', border: 'border-emerald-100 dark:border-emerald-800/50', hex: '#059669' },
  { name: 'Blue', bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400', border: 'border-blue-100 dark:border-blue-800/50', hex: '#2563eb' },
  { name: 'Indigo', bg: 'bg-indigo-100 dark:bg-indigo-900/30', text: 'text-indigo-600 dark:text-indigo-400', border: 'border-indigo-100 dark:border-indigo-800/50', hex: '#4f46e5' },
  { name: 'Violet', bg: 'bg-violet-100 dark:bg-violet-900/30', text: 'text-violet-600 dark:text-violet-400', border: 'border-violet-100 dark:border-violet-800/50', hex: '#7c3aed' },
];

export default function Timetable({ onNavigate, initialTaskId }: { onNavigate: (view: any, eventId?: string) => void, initialTaskId?: string | null }) {
  const { events, occurrences, loading, saveEvent, deleteEvent, refresh } = useTimetable();
  const [notes, setNotes] = useState<Note[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [subjectColors, setSubjectColors] = useState<Record<string, string>>({});
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<TimetableEvent | null>(null);
  const [selectedOccurrenceDate, setSelectedOccurrenceDate] = useState<string | null>(null);
  const [layout, setLayout] = useState<'list' | 'grid' | 'calendar'>(() => (localStorage.getItem('timetable_layout') as any) || 'list');
  const [timetableTheme, setTimetableTheme] = useState(() => localStorage.getItem('timetable_theme') || 'default');
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [conflict, setConflict] = useState<TimetableEvent | null>(null);

  useEffect(() => {
    if (initialTaskId) {
      setSelectedTaskId(initialTaskId);
      setIsAddModalOpen(true);
    }
  }, [initialTaskId]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    localStorage.setItem('timetable_layout', layout);
  }, [layout]);

  useEffect(() => {
    localStorage.setItem('timetable_theme', timetableTheme);
  }, [timetableTheme]);

  useEffect(() => {
    fetchExtraData();
  }, []);

  const fetchExtraData = async () => {
    const n = await db.getAll('notes');
    const t = await db.getAll('tasksStore');
    const sc = await db.getAll('subjectColorsStore');
    
    const colorsMap: Record<string, string> = {};
    sc.forEach(item => {
      colorsMap[item.id] = item.colorName;
    });
    
    setNotes(n);
    setTasks(t);
    setSubjectColors(colorsMap);
  };

  const allOccurrences = useMemo(() => {
    return occurrences.map(occ => {
      const event = events.find(e => e.id === occ.eventId);
      return event ? { event, date: parseISO(occ.date) } : null;
    }).filter(Boolean) as { event: TimetableEvent, date: Date }[];
  }, [events, occurrences]);

  const dayEvents = useMemo(() => {
    return allOccurrences
      .filter(o => isSameDay(o.date, selectedDate))
      .sort((a, b) => a.event.start - b.event.start);
  }, [allOccurrences, selectedDate]);

  const handleAddEvent = async (eventData: Partial<TimetableEvent>) => {
    const newEvent: TimetableEvent = {
      id: uuidv4(),
      subject: eventData.subject || 'Untitled Event',
      day: eventData.day || DAYS[getDay(selectedDate)],
      date: eventData.date || format(selectedDate, 'yyyy-MM-dd'),
      start: eventData.start || 9,
      duration: eventData.duration || 1,
      location: eventData.location || '',
      color: eventData.color || EVENT_COLORS[0].hex,
      priority: eventData.priority || 'low',
      repeat: eventData.repeat || 'none',
      notes: eventData.notes || '',
      reminderMin: eventData.reminderMin || '0',
      notificationType: eventData.notificationType || 'in-app',
      taskId: eventData.taskId,
      synced: 0,
    };

    const conflictEvent = timetableService.checkConflict(newEvent, events);
    if (conflictEvent) {
      if (!window.confirm(`Conflict detected with "${conflictEvent.subject}". Save anyway?`)) {
        return;
      }
    }

    await saveEvent(newEvent);
    setIsAddModalOpen(false);
  };

  const handleDeleteEvent = async (id: string, allFuture: boolean = false) => {
    const event = events.find(e => e.id === id);
    if (!event) return;

    if (allFuture) {
      if (window.confirm('Delete this and all future occurrences?')) {
        await deleteEvent(id);
        // Also delete any exceptions
        const exceptions = events.filter(e => e.parentId === id);
        for (const ex of exceptions) {
          await deleteEvent(ex.id);
        }
        setSelectedEvent(null);
      }
    } else {
      if (window.confirm('Delete only this occurrence?')) {
        if (event.repeat === 'none') {
          await deleteEvent(id);
        } else if (selectedOccurrenceDate) {
          const deleted = event.deletedOccurrences || [];
          await saveEvent({
            ...event,
            deletedOccurrences: [...deleted, selectedOccurrenceDate],
            synced: 0
          });
        }
        setSelectedEvent(null);
      }
    }
  };

  const handleEditEvent = async (eventData: Partial<TimetableEvent>, allFuture: boolean = false) => {
    if (!selectedEvent) return;

    if (allFuture) {
      const updated = { ...selectedEvent, ...eventData, synced: 0 };
      await saveEvent(updated);
    } else {
      // Create an exception
      if (selectedOccurrenceDate) {
        // 1. Mark this date as deleted in parent
        const deleted = selectedEvent.deletedOccurrences || [];
        await saveEvent({
          ...selectedEvent,
          deletedOccurrences: [...deleted, selectedOccurrenceDate],
          synced: 0
        });

        // 2. Create new one-off event
        const exception: TimetableEvent = {
          ...selectedEvent,
          ...eventData,
          id: uuidv4(),
          date: selectedOccurrenceDate,
          repeat: 'none',
          parentId: selectedEvent.id,
          synced: 0
        };
        await saveEvent(exception);
      }
    }
    setSelectedEvent(null);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    // Find the occurrence being dragged
    const activeOcc = dayEvents.find(o => `${o.event.id}-${format(o.date, 'yyyy-MM-dd')}` === activeId);
    const overOcc = dayEvents.find(o => `${o.event.id}-${format(o.date, 'yyyy-MM-dd')}` === overId);

    if (activeOcc && overOcc) {
      // Swap times
      const newStartTime = overOcc.event.start;
      const updatedEvent = { ...activeOcc.event, start: newStartTime, synced: 0 };
      
      // If it's a recurring event, we might want to ask if it's for all or just this one
      // For simplicity, we'll treat it as an exception if it's recurring
      if (activeOcc.event.repeat !== 'none') {
        const dateStr = format(activeOcc.date, 'yyyy-MM-dd');
        const deleted = activeOcc.event.deletedOccurrences || [];
        
        await saveEvent({
          ...activeOcc.event,
          deletedOccurrences: [...deleted, dateStr],
          synced: 0
        });

        const exception: TimetableEvent = {
          ...activeOcc.event,
          id: uuidv4(),
          date: dateStr,
          start: newStartTime,
          repeat: 'none',
          parentId: activeOcc.event.id,
          synced: 0
        };
        await saveEvent(exception);
      } else {
        await saveEvent(updatedEvent);
      }
    }
  };

  const formatTime = (time: number) => {
    const h = Math.floor(time);
    const m = time % 1 === 0 ? '00' : '30';
    return `${h.toString().padStart(2, '0')}:${m}`;
  };

  const getEventColor = (colorHex?: string, subject?: string) => {
    // Check if we have a saved subject color
    const savedColor = subject && subjectColors[subject];
    const hex = savedColor || colorHex || EVENT_COLORS[0].hex;
    
    // Find matching predefined color or return a custom object
    const predefined = EVENT_COLORS.find(c => c.hex.toLowerCase() === hex.toLowerCase());
    if (predefined) return predefined;

    return {
      name: 'Custom',
      bg: 'bg-slate-100 dark:bg-slate-800',
      text: 'text-slate-900 dark:text-slate-100',
      border: 'border-slate-200 dark:border-slate-700',
      hex: hex
    };
  };

  const fetchData = async () => {
    await refresh();
    await fetchExtraData();
  };

  const updateSubjectColor = async (subject: string, colorHex: string) => {
    await db.put('subjectColorsStore', { id: subject, colorName: colorHex, synced: 0 });
    fetchData();
  };

  const renderCalendar = () => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    const days = eachDayOfInterval({
      start: startOfWeek(start),
      end: endOfWeek(end)
    });

    return (
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xl">
        <header className="p-6 flex justify-between items-center border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-xl font-display font-bold">{format(currentMonth, 'MMMM yyyy')}</h2>
          <div className="flex gap-2">
            <button onClick={() => setCurrentMonth(addMonths(currentMonth, -1))} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
              <ChevronLeft size={20} />
            </button>
            <button onClick={() => setCurrentMonth(new Date())} className="px-4 py-2 text-xs font-bold bg-slate-100 dark:bg-slate-800 rounded-xl">Today</button>
            <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">
              <ChevronRight size={20} />
            </button>
          </div>
        </header>
        <div className="grid grid-cols-7 border-b border-slate-100 dark:border-slate-800">
          {DAYS.map(d => (
            <div key={d} className="py-3 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              {d.substring(0, 3)}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {days.map((day, i) => {
            const isCurrentMonth = day.getMonth() === currentMonth.getMonth();
            const isToday = isSameDay(day, new Date());
            const isSelected = isSameDay(day, selectedDate);
            const dayOccurrences = allOccurrences.filter(o => isSameDay(o.date, day));

            return (
              <button
                key={i}
                onClick={() => setSelectedDate(day)}
                className={`min-h-[100px] p-2 border-r border-b border-slate-100 dark:border-slate-800 text-left transition-all hover:bg-slate-50 dark:hover:bg-slate-800/50 relative ${
                  !isCurrentMonth ? 'opacity-30' : ''
                } ${isSelected ? 'bg-brand-50/50 dark:bg-brand-900/10' : ''}`}
              >
                <span className={`text-xs font-bold ${isToday ? 'w-6 h-6 bg-brand-600 text-white rounded-full flex items-center justify-center' : 'text-slate-600 dark:text-slate-400'}`}>
                  {format(day, 'd')}
                </span>
                <div className="mt-2 space-y-1">
                  {dayOccurrences.slice(0, 3).map((o, idx) => (
                    <div 
                      key={idx} 
                      className="text-[8px] font-bold truncate px-1.5 py-0.5 rounded-md border"
                      style={{ 
                        backgroundColor: getEventColor(o.event.color, o.event.subject).hex + '20',
                        color: getEventColor(o.event.color, o.event.subject).hex,
                        borderColor: getEventColor(o.event.color, o.event.subject).hex + '40'
                      }}
                    >
                      {o.event.subject}
                    </div>
                  ))}
                  {dayOccurrences.length > 3 && (
                    <div className="text-[8px] font-bold text-slate-400 pl-1">+{dayOccurrences.length - 3} more</div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="px-6 pb-12 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-center pt-4">
        <h1 className="text-3xl font-display font-bold tracking-tight">Schedule</h1>
        <div className="flex gap-2">
          <div className="flex p-1 glass-morphism rounded-2xl border border-white/10">
            <button 
              onClick={() => setLayout('list')}
              className={`p-2.5 rounded-xl transition-all ${layout === 'list' ? 'bg-white/20 dark:bg-white/10 text-brand-600 shadow-sm' : 'text-slate-400'}`}
              title="List View"
            >
              <List size={18} />
            </button>
            <button 
              onClick={() => setLayout('grid')}
              className={`p-2.5 rounded-xl transition-all ${layout === 'grid' ? 'bg-white/20 dark:bg-white/10 text-brand-600 shadow-sm' : 'text-slate-400'}`}
              title="Grid View"
            >
              <Grid size={18} />
            </button>
            <button 
              onClick={() => setLayout('calendar')}
              className={`p-2.5 rounded-xl transition-all ${layout === 'calendar' ? 'bg-white/20 dark:bg-white/10 text-brand-600 shadow-sm' : 'text-slate-400'}`}
              title="Calendar View"
            >
              <CalendarDays size={18} />
            </button>
          </div>
          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="w-12 h-12 rounded-2xl bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
          >
            <Plus size={24} />
          </button>
        </div>
      </header>

      {layout === 'calendar' ? (
        renderCalendar()
      ) : (
        <>
          {/* Day Selector */}
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {eachDayOfInterval({
              start: startOfWeek(selectedDate),
              end: endOfWeek(selectedDate)
            }).map(day => (
              <button
                key={day.toISOString()}
                onClick={() => setSelectedDate(day)}
                className={`px-5 py-3 rounded-2xl text-xs font-bold whitespace-nowrap transition-all flex flex-col items-center gap-1 min-w-[70px] ${
                  isSameDay(selectedDate, day) 
                    ? 'bg-brand-600 text-white shadow-lg shadow-brand-200 dark:shadow-none' 
                    : 'glass-card text-slate-600 dark:text-slate-400 border-white/10'
                }`}
              >
                <span className="opacity-60">{format(day, 'EEE')}</span>
                <span className="text-lg">{format(day, 'd')}</span>
                <div className={`w-1 h-1 rounded-full ${isSameDay(selectedDate, day) ? 'bg-slate-100' : 'bg-transparent'}`} />
              </button>
            ))}
          </div>

          {/* Events List */}
          <div className={layout === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : 'space-y-4'}>
            {dayEvents.length > 0 ? (
              <DndContext 
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext 
                  items={dayEvents.map(o => `${o.event.id}-${format(o.date, 'yyyy-MM-dd')}`)}
                  strategy={verticalListSortingStrategy}
                >
                  {dayEvents.map(({ event, date }) => (
                    <SortableEventItem 
                      key={`${event.id}-${format(date, 'yyyy-MM-dd')}`}
                      id={`${event.id}-${format(date, 'yyyy-MM-dd')}`}
                      event={event}
                      date={date}
                      layout={layout}
                      timetableTheme={timetableTheme}
                      getEventColor={getEventColor}
                      formatTime={formatTime}
                      onClick={() => {
                        setSelectedEvent(event);
                        setSelectedOccurrenceDate(format(date, 'yyyy-MM-dd'));
                      }}
                    />
                  ))}
                </SortableContext>
              </DndContext>
            ) : (
              <EmptyState 
                icon={CalendarIcon}
                title={`Your ${format(selectedDate, 'EEEE')} is wide open!`}
                message={`No classes or study sessions scheduled yet. It's the perfect time to plan your day or dive into some self-study.`}
                action={{
                  label: "Schedule an Event",
                  onClick: () => setIsAddModalOpen(true)
                }}
              />
            )}
          </div>
        </>
      )}

      {/* Event Detail Modal */}
      <AnimatePresence>
        {selectedEvent && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { setSelectedEvent(null); setSelectedOccurrenceDate(null); }}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 space-y-8 max-h-[90vh] overflow-y-auto no-scrollbar">
                <header className="flex justify-between items-start">
                  <div>
                    <h2 className="text-3xl font-display font-bold tracking-tight">{selectedEvent.subject}</h2>
                    <p className="text-slate-500 font-medium mt-1">{selectedOccurrenceDate ? format(parseISO(selectedOccurrenceDate), 'EEEE, MMMM do') : selectedEvent.day}</p>
                  </div>
                  <button onClick={() => { setSelectedEvent(null); setSelectedOccurrenceDate(null); }} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                    <X size={24} />
                  </button>
                </header>

                <div className="grid grid-cols-2 gap-4">
                  <DetailItem icon={Clock} label="Time" value={`${formatTime(selectedEvent.start)} (${selectedEvent.duration}h)`} />
                  <DetailItem icon={MapPin} label="Location" value={selectedEvent.location || 'Not specified'} />
                </div>

                {/* Color Customization */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center px-1">
                    <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Subject Color</h4>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <span className="text-[10px] font-bold text-brand-600 uppercase tracking-widest">Custom</span>
                      <input 
                        type="color" 
                        className="w-6 h-6 rounded-md border-none p-0 bg-transparent cursor-pointer"
                        value={subjectColors[selectedEvent.subject] || selectedEvent.color || EVENT_COLORS[0].hex}
                        onChange={(e) => updateSubjectColor(selectedEvent.subject, e.target.value)}
                      />
                    </label>
                  </div>
                  <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                    {EVENT_COLORS.map(c => (
                      <button
                        key={c.name}
                        onClick={() => updateSubjectColor(selectedEvent.subject, c.hex)}
                        className={`w-8 h-8 rounded-lg flex-shrink-0 transition-all border-2 ${
                          (subjectColors[selectedEvent.subject] || selectedEvent.color || EVENT_COLORS[0].hex).toLowerCase() === c.hex.toLowerCase()
                            ? 'ring-2 ring-offset-2 ring-brand-500 scale-110' 
                            : 'opacity-50 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: c.hex, borderColor: c.hex + '40' }}
                      />
                    ))}
                  </div>
                </div>

                {selectedEvent.notes && (
                  <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/50">
                    <div className="flex items-center gap-2 mb-2">
                      <NotebookPen size={14} className="text-slate-400" />
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Notes</span>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{selectedEvent.notes}</p>
                  </div>
                )}

                {/* Linked Task */}
                {selectedEvent.taskId && (
                  <div className="space-y-3">
                    <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Linked Task</h4>
                    {tasks.find(t => t.id === selectedEvent.taskId) ? (
                      <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CheckCircle2 size={18} className="text-emerald-600 dark:text-emerald-400" />
                          <div>
                            <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
                              {tasks.find(t => t.id === selectedEvent.taskId)?.title}
                            </p>
                            <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                              {tasks.find(t => t.id === selectedEvent.taskId)?.completed ? 'Completed' : 'Pending'}
                            </p>
                          </div>
                        </div>
                        <button 
                          onClick={() => onNavigate('tasks')}
                          className="p-2 hover:bg-emerald-100 dark:hover:bg-emerald-800 rounded-xl transition-colors text-emerald-600 dark:text-emerald-400"
                        >
                          <ChevronRight size={16} />
                        </button>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic px-1">Linked task not found.</p>
                    )}
                  </div>
                )}

                {/* Linked Notes */}
                <div className="space-y-3">
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Linked Notes</h4>
                  {notes.filter(n => n.eventId === selectedEvent.id).length > 0 ? (
                    <div className="space-y-2">
                      {notes.filter(n => n.eventId === selectedEvent.id).map(note => (
                        <button 
                          key={note.id}
                          onClick={() => { setSelectedEvent(null); onNavigate('notes', selectedEvent.id); }}
                          className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center justify-between group hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-all"
                        >
                          <div className="flex items-center gap-3">
                            <NotebookPen size={18} className="text-brand-600 dark:text-brand-400" />
                            <span className="text-sm font-bold">{note.title}</span>
                          </div>
                          <ChevronRight size={16} className="text-slate-300 group-hover:text-brand-400 transition-colors" />
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 italic px-1">No notes linked to this event.</p>
                  )}
                </div>

                <div className="space-y-3">
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Manage Event</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => handleDeleteEvent(selectedEvent.id, false)}
                      className="p-4 bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 font-bold rounded-2xl border border-rose-100 dark:border-rose-900/30 text-xs flex items-center justify-center gap-2"
                    >
                      <Trash2 size={16} /> Delete This
                    </button>
                    {selectedEvent.repeat !== 'none' && (
                      <button 
                        onClick={() => handleDeleteEvent(selectedEvent.id, true)}
                        className="p-4 bg-rose-600 text-white font-bold rounded-2xl shadow-lg shadow-rose-200 dark:shadow-none text-xs flex items-center justify-center gap-2"
                      >
                        <Trash2 size={16} /> Delete All
                      </button>
                    )}
                  </div>
                </div>

                <button 
                  onClick={() => { setSelectedEvent(null); setSelectedOccurrenceDate(null); }}
                  className="w-full py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Event Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 space-y-6 max-h-[90vh] overflow-y-auto no-scrollbar">
                <header className="flex justify-between items-center">
                  <h2 className="text-xl font-display font-bold">Add to Schedule</h2>
                  <button onClick={() => setIsAddModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                    <X size={20} />
                  </button>
                </header>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Subject</label>
                    <input id="add-subject" type="text" placeholder="e.g. Physics Lecture" className="premium-input" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Start Date</label>
                      <input id="add-date" type="date" defaultValue={format(selectedDate, 'yyyy-MM-dd')} className="premium-input" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Start Time</label>
                      <select id="add-start" className="premium-input appearance-none">
                        {Array.from({ length: 24 * 2 }, (_, i) => {
                          const time = 7 + i * 0.5;
                          if (time > 22) return null;
                          return <option key={time} value={time}>{formatTime(time)}</option>;
                        }).filter(Boolean)}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Duration (h)</label>
                      <input id="add-duration" type="number" step="0.5" defaultValue="1" className="premium-input" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Location</label>
                      <input id="add-location" type="text" placeholder="Room 101" className="premium-input" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Recurrence</label>
                      <select id="add-repeat" defaultValue="weekly" className="premium-input appearance-none">
                        <option value="none">None</option>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Priority</label>
                      <select id="add-priority" defaultValue="low" className="premium-input appearance-none">
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Link to Task (Optional)</label>
                    <select id="add-task" className="premium-input appearance-none" defaultValue={selectedTaskId || ""}>
                      <option value="">No Task Linked</option>
                      {tasks.filter(t => !t.completed || t.id === selectedTaskId).map(task => (
                        <option key={task.id} value={task.id}>{task.title} ({task.subject})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Notes</label>
                    <textarea id="add-notes" placeholder="e.g. Bring textbook" rows={2} className="premium-input resize-none" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Color Theme</label>
                      <input 
                        type="color" 
                        id="add-custom-color"
                        className="w-6 h-6 rounded-md border-none p-0 bg-transparent cursor-pointer"
                        defaultValue={EVENT_COLORS[0].hex}
                        onChange={(e) => {
                          (document.getElementById('add-color') as HTMLInputElement).value = e.target.value;
                          const btns = document.querySelectorAll('.color-btn');
                          btns.forEach(b => b.classList.remove('ring-2', 'ring-offset-2', 'ring-brand-500'));
                        }}
                      />
                    </div>
                    <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                      {EVENT_COLORS.map(c => (
                        <button
                          key={c.name}
                          onClick={() => {
                            const btns = document.querySelectorAll('.color-btn');
                            btns.forEach(b => b.classList.remove('ring-2', 'ring-offset-2', 'ring-brand-500'));
                            const btn = document.getElementById(`color-${c.name}`);
                            btn?.classList.add('ring-2', 'ring-offset-2', 'ring-brand-500');
                            (document.getElementById('add-color') as HTMLInputElement).value = c.hex;
                            (document.getElementById('add-custom-color') as HTMLInputElement).value = c.hex;
                          }}
                          id={`color-${c.name}`}
                          className={`color-btn w-10 h-10 rounded-xl flex-shrink-0 transition-all border-2 ${c.name === 'Brand' ? 'ring-2 ring-offset-2 ring-brand-500' : ''}`}
                          style={{ backgroundColor: c.hex, borderColor: c.hex + '40' }}
                          title={c.name}
                        />
                      ))}
                      <input type="hidden" id="add-color" defaultValue={EVENT_COLORS[0].hex} />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => {
                      setIsAddModalOpen(false);
                      setSelectedTaskId(null);
                    }}
                    className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      const subject = (document.getElementById('add-subject') as HTMLInputElement).value;
                      const date = (document.getElementById('add-date') as HTMLInputElement).value;
                      const start = parseFloat((document.getElementById('add-start') as HTMLSelectElement).value);
                      const duration = parseFloat((document.getElementById('add-duration') as HTMLInputElement).value);
                      const location = (document.getElementById('add-location') as HTMLInputElement).value;
                      const color = (document.getElementById('add-color') as HTMLInputElement).value;
                      const repeat = (document.getElementById('add-repeat') as HTMLSelectElement).value as any;
                      const priority = (document.getElementById('add-priority') as HTMLSelectElement).value as any;
                      const notes = (document.getElementById('add-notes') as HTMLTextAreaElement).value;
                      const taskId = (document.getElementById('add-task') as HTMLSelectElement).value || undefined;
                      
                      const day = DAYS[getDay(parseISO(date))];
                      handleAddEvent({ subject, date, day, start, duration, location, color, repeat, priority, notes, taskId });
                      setSelectedTaskId(null);
                    }}
                    className="flex-1 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
                  >
                    Save Event
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

const SortableEventItem = ({ id, event, date, layout, timetableTheme, getEventColor, formatTime, onClick }: any) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 10 : 1,
    opacity: isDragging ? 0.5 : 1,
  };

  const color = getEventColor(event.color, event.subject);
  const priorityColor = event.priority === 'high' ? 'bg-rose-500' : event.priority === 'medium' ? 'bg-amber-500' : 'bg-emerald-500';

  return (
    <div ref={setNodeRef} style={style} className="relative group">
      <motion.button 
        onClick={onClick}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        className={cn(
          "w-full glass-card p-6 rounded-[2rem] border-slate-200 dark:border-slate-800 flex items-center gap-6 thumb-button relative overflow-hidden",
          timetableTheme === 'vibrant' && "border-l-4"
        )}
        style={timetableTheme === 'vibrant' ? { borderLeftColor: color.hex } : {}}
      >
        <div 
          className="flex flex-col items-center justify-center w-16 h-16 rounded-2xl border shrink-0" 
          style={{ backgroundColor: color.hex + '15', color: color.hex, borderColor: color.hex + '30' }}
        >
          <span className="text-sm font-bold tracking-tight">{formatTime(event.start)}</span>
          <span className="text-[8px] font-bold uppercase opacity-60">Start</span>
        </div>
        
        <div className="flex-1 text-left">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-bold text-lg tracking-tight">{event.subject}</h3>
            {event.priority && (
              <span className={cn("px-1.5 py-0.5 text-white text-[8px] font-bold uppercase tracking-widest rounded-md", priorityColor)}>
                {event.priority}
              </span>
            )}
            {event.repeat && event.repeat !== 'none' && (
              <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-[8px] font-bold text-slate-400 uppercase tracking-widest rounded-md border border-slate-200 dark:border-slate-700">
                {event.repeat}
              </span>
            )}
            {event.synced === 0 && (
              <div className="w-1.5 h-1.5 rounded-full bg-brand-500 animate-pulse" title="Offline - Not Synced" />
            )}
          </div>
          <div className="flex items-center gap-3 mt-1 text-slate-500 text-xs font-medium">
            <span className="flex items-center gap-1"><Clock size={12} /> {event.duration}h</span>
            {event.location && <span className="flex items-center gap-1"><MapPin size={12} /> {event.location}</span>}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {layout === 'list' && <ChevronRight size={20} className="text-slate-300" />}
          <div 
            {...attributes} 
            {...listeners} 
            className="p-2 text-slate-300 hover:text-slate-500 cursor-grab active:cursor-grabbing"
            onClick={(e) => e.stopPropagation()}
          >
            <GripVertical size={20} />
          </div>
        </div>
      </motion.button>
    </div>
  );
};

const DetailItem = ({ icon: Icon, label, value }: { icon: any, label: string, value: string }) => (
  <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700/50">
    <div className="flex items-center gap-2 mb-1">
      <Icon size={14} className="text-slate-400" />
      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{label}</span>
    </div>
    <div className="text-sm font-bold tracking-tight">{value}</div>
  </div>
);
