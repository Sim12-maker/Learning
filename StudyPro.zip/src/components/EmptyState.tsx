import React from 'react';
import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  message: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export default function EmptyState({ icon: Icon, title, message, action }: EmptyStateProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="py-16 px-6 text-center glass-card rounded-[2.5rem] border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center"
    >
      <div className="w-20 h-20 rounded-full bg-slate-50 dark:bg-slate-900 flex items-center justify-center mb-6 relative">
        <Icon size={40} className="text-slate-300 dark:text-slate-700" />
        <div className="absolute -inset-2 bg-brand-500/5 blur-xl rounded-full -z-10"></div>
      </div>
      
      <h3 className="text-xl font-display font-bold tracking-tight mb-2">{title}</h3>
      <p className="text-slate-500 dark:text-slate-400 text-sm max-w-[240px] leading-relaxed mb-8">
        {message}
      </p>

      {action && (
        <button 
          onClick={action.onClick}
          className="px-6 py-3 bg-brand-600 text-white text-xs font-bold uppercase tracking-widest rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
        >
          {action.label}
        </button>
      )}
    </motion.div>
  );
}
