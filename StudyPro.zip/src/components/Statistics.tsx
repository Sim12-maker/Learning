import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  Flame, 
  Calendar,
  ChevronRight,
  Target,
  Zap
} from 'lucide-react';
import { db } from '../db';
import { Task, TimerSession } from '../types';

export default function Statistics() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [sessions, setSessions] = useState<TimerSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const t = await db.getAll('tasksStore');
    const s = await db.getAll('timerSessionsStore');
    setTasks(t);
    setSessions(s);
    setLoading(false);
  };

  // Process data for charts
  const completedTasks = tasks.filter(t => t.completed).length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const totalStudyMinutes = sessions.reduce((acc, s) => acc + s.duration, 0);
  const studyHours = (totalStudyMinutes / 60).toFixed(1);

  // Study time by day (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return d.toISOString().split('T')[0];
  }).reverse();

  const studyTimeByDay = last7Days.map(date => {
    const daySessions = sessions.filter(s => s.date.startsWith(date) && s.type === 'focus');
    const total = daySessions.reduce((acc, s) => acc + s.duration, 0);
    return {
      name: new Date(date).toLocaleDateString('en-US', { weekday: 'short' }),
      minutes: total
    };
  });

  // Tasks by subject
  const subjects = Array.from(new Set(tasks.map(t => t.subject)));
  const tasksBySubject = subjects.map(s => ({
    name: s,
    value: tasks.filter(t => t.subject === s).length
  })).sort((a, b) => b.value - a.value).slice(0, 5);

  // Study time by subject
  const sessionsBySubject = subjects.map(s => {
    const subjectSessions = sessions.filter(sess => sess.subject === s && sess.type === 'focus');
    const total = subjectSessions.reduce((acc, sess) => acc + sess.duration, 0);
    return {
      name: s,
      minutes: total
    };
  }).sort((a, b) => b.minutes - a.minutes).slice(0, 5);

  const COLORS = ['#4A90E2', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  if (loading) return <div className="p-10 text-center text-slate-400">Loading stats...</div>;

  return (
    <div className="px-6 pb-24 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="pt-4">
        <h1 className="text-3xl font-display font-bold tracking-tight">Study Analytics</h1>
        <p className="text-slate-500 font-medium mt-1">Deep dive into your learning habits.</p>
      </header>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard 
          icon={Clock} 
          label="Study Time" 
          value={`${studyHours}h`} 
          color="text-brand-600" 
          bg="bg-brand-50 dark:bg-brand-900/20" 
        />
        <StatCard 
          icon={CheckCircle2} 
          label="Tasks Done" 
          value={completedTasks.toString()} 
          color="text-emerald-600" 
          bg="bg-emerald-50 dark:bg-emerald-900/20" 
        />
        <StatCard 
          icon={Target} 
          label="Completion" 
          value={`${completionRate}%`} 
          color="text-amber-600" 
          bg="bg-amber-50 dark:bg-amber-900/20" 
        />
        <StatCard 
          icon={Flame} 
          label="Sessions" 
          value={sessions.length.toString()} 
          color="text-rose-600" 
          bg="bg-rose-50 dark:bg-rose-900/20" 
        />
      </div>

      {/* Main Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Activity Chart */}
        <div className="glass-card p-8 rounded-[2.5rem] space-y-6">
          <div className="flex justify-between items-center px-2">
            <div>
              <h3 className="font-bold text-lg tracking-tight">Weekly Activity</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Minutes focused per day</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-brand-500"></div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Minutes</span>
            </div>
          </div>
          
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={studyTimeByDay}>
                <defs>
                  <linearGradient id="colorMinutes" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4A90E2" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#4A90E2" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }} 
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                    fontSize: '12px',
                    fontWeight: 'bold'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="minutes" 
                  stroke="#4A90E2" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorMinutes)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Time by Subject Chart */}
        <div className="glass-card p-8 rounded-[2.5rem] space-y-6">
          <div className="flex justify-between items-center px-2">
            <div>
              <h3 className="font-bold text-lg tracking-tight">Time by Subject</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total minutes per subject</p>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400">
              <Zap size={18} />
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sessionsBySubject} layout="vertical">
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 700, fill: '#64748b' }}
                  width={80}
                />
                <Tooltip 
                  cursor={{ fill: 'transparent' }}
                  contentStyle={{ 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' 
                  }}
                />
                <Bar dataKey="minutes" radius={[0, 10, 10, 0]}>
                  {sessionsBySubject.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Focus Areas Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 glass-card p-8 rounded-[2.5rem] space-y-6">
          <h3 className="font-bold text-lg tracking-tight">Task Distribution</h3>
          <div className="h-48 w-full flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={tasksBySubject}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {tasksBySubject.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xl font-bold">{totalTasks}</span>
              <span className="text-[8px] font-bold text-slate-400 uppercase">Tasks</span>
            </div>
          </div>
          <div className="space-y-2">
            {tasksBySubject.map((s, i) => (
              <div key={s.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-[10px] font-bold text-slate-500">{s.name}</span>
                </div>
                <span className="text-[10px] font-bold">{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Sessions List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center px-2">
            <h3 className="font-bold text-lg tracking-tight">Recent Sessions</h3>
            <button className="text-[10px] font-bold text-brand-600 uppercase tracking-widest flex items-center gap-1">
              View All <ChevronRight size={12} />
            </button>
          </div>
          
          <div className="space-y-3">
            {sessions.slice(0, 4).map(session => (
              <div key={session.id} className="glass-card p-5 rounded-[2rem] flex items-center justify-between thumb-button">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${session.type === 'focus' ? 'bg-brand-50 text-brand-600' : 'bg-emerald-50 text-emerald-600'}`}>
                    <Zap size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm tracking-tight capitalize">{session.type} Session</h4>
                    <p className="text-[10px] text-slate-400 font-medium">{new Date(session.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} • {session.subject}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-sm tracking-tight">{session.duration}m</div>
                  <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Duration</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const StatCard = ({ icon: Icon, label, value, color, bg }: { icon: any, label: string, value: string, color: string, bg: string }) => (
  <div className="glass-card p-5 rounded-[2rem] border-slate-200 dark:border-slate-800 space-y-3">
    <div className={`w-10 h-10 rounded-2xl ${bg} ${color} flex items-center justify-center`}>
      <Icon size={20} />
    </div>
    <div>
      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{label}</div>
      <div className="text-xl font-bold tracking-tight">{value}</div>
    </div>
  </div>
);
