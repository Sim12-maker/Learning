import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen } from 'lucide-react';

interface WelcomeProps {
  onComplete: (username: string) => void;
}

export default function Welcome({ onComplete }: WelcomeProps) {
  const [username, setUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onComplete(username.trim());
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-[#1E2A38] flex flex-col items-center justify-center p-6 overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#1E2A38] to-[#141d26] opacity-100" />
      
      {/* Abstract Shapes for Depth */}
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-[#4A90E2]/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-[#4A90E2]/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10 w-full max-w-sm flex flex-col items-center"
      >
        {/* Logo */}
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
          className="w-24 h-24 bg-gradient-to-br from-[#1E2A38] to-[#141d26] rounded-[2rem] flex items-center justify-center shadow-2xl border border-white/10 mb-8"
        >
          <div className="relative">
            <BookOpen size={48} className="text-[#4A90E2]" />
            <div className="absolute inset-0 blur-lg bg-[#4A90E2]/30 -z-10" />
          </div>
        </motion.div>

        {/* Welcome Text */}
        <div className="text-center mb-10">
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="text-3xl font-display font-bold text-white tracking-tight mb-2"
          >
            Welcome StudyPro
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-slate-400 font-medium"
          >
            enter name
          </motion.p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="w-full space-y-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
          >
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username yako"
              className="w-full bg-white/5 border border-white/10 text-white placeholder:text-slate-500 rounded-2xl p-4 outline-none focus:border-[#4A90E2]/50 focus:bg-white/10 transition-all text-center text-lg font-medium"
              autoFocus
            />
          </motion.div>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.6 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={!username.trim()}
            className="w-full bg-[#4A90E2] text-white font-bold py-4 rounded-2xl shadow-xl shadow-[#4A90E2]/20 hover:bg-[#357ABD] transition-all disabled:opacity-50 disabled:cursor-not-allowed text-lg"
          >
            Continue
          </motion.button>
        </form>
      </motion.div>
      
      {/* Footer Branding */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-8 text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em]"
      >
        StudyPro Premium
      </motion.div>
    </div>
  );
}
