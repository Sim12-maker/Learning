import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings as SettingsIcon, 
  Bell, 
  Palette, 
  Clock, 
  Database, 
  Shield, 
  Info, 
  ChevronRight, 
  Moon, 
  Sun, 
  Volume2, 
  Vibrate, 
  Type, 
  Trash2, 
  Download, 
  Upload, 
  FileJson,
  Check,
  ArrowLeft
} from 'lucide-react';
import { useSettings } from '../../hooks/useSettings';
import { AppSettings } from '../../types';

type SettingsSection = 'main' | 'appearance' | 'notifications' | 'study' | 'data' | 'privacy' | 'about';

const Settings: React.FC = () => {
  const { settings, updateSettings } = useSettings();
  const [activeSection, setActiveSection] = useState<SettingsSection>('main');

  const renderMain = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <QuickControlCard 
          icon={<Moon size={20} />} 
          label="Dark Mode" 
          value={settings.darkMode} 
          onChange={(val) => updateSettings({ darkMode: val })} 
        />
        <QuickControlCard 
          icon={<Bell size={20} />} 
          label="Notifications" 
          value={settings.notificationsEnabled} 
          onChange={(val) => updateSettings({ notificationsEnabled: val })} 
        />
      </div>

      <div className="space-y-2">
        <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-4">Categories</h3>
        <div className="glass-card overflow-hidden">
          <SettingsMenuItem 
            icon={<Palette size={20} className="text-pink-500" />} 
            label="Appearance" 
            description="Theme, font size, and colors" 
            onClick={() => setActiveSection('appearance')} 
          />
          <SettingsMenuItem 
            icon={<Bell size={20} className="text-blue-500" />} 
            label="Notifications" 
            description="Reminders and alert sounds" 
            onClick={() => setActiveSection('notifications')} 
          />
          <SettingsMenuItem 
            icon={<Clock size={20} className="text-emerald-500" />} 
            label="Study Settings" 
            description="Focus timer and daily goals" 
            onClick={() => setActiveSection('study')} 
          />
          <SettingsMenuItem 
            icon={<Database size={20} className="text-amber-500" />} 
            label="Data & Storage" 
            description="Backup, restore, and cache" 
            onClick={() => setActiveSection('data')} 
          />
          <SettingsMenuItem 
            icon={<Shield size={20} className="text-purple-500" />} 
            label="Privacy & Security" 
            description="Permissions and data protection" 
            onClick={() => setActiveSection('privacy')} 
          />
          <SettingsMenuItem 
            icon={<Info size={20} className="text-slate-500" />} 
            label="About" 
            description="App version and info" 
            onClick={() => setActiveSection('about')} 
          />
        </div>
      </div>
    </div>
  );

  const renderAppearance = () => (
    <div className="space-y-6">
      <SectionHeader title="Appearance" onBack={() => setActiveSection('main')} />
      <div className="glass-card p-6 space-y-6">
        <div className="space-y-4">
          <label className="text-xs font-bold text-slate-400 uppercase">Font Size</label>
          <div className="flex gap-2">
            {(['small', 'medium', 'large'] as const).map((size) => (
              <button
                key={size}
                onClick={() => updateSettings({ fontSize: size })}
                className={`flex-1 py-3 rounded-xl border transition-all ${
                  settings.fontSize === size 
                    ? 'bg-brand-600 border-brand-600 text-white shadow-lg shadow-brand-200 dark:shadow-none' 
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span className="text-sm font-bold capitalize">{size}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <label className="text-xs font-bold text-slate-400 uppercase">Accent Color</label>
          <div className="flex flex-wrap gap-3">
            {['#4A90E2', '#E24A4A', '#4AE24A', '#E2A34A', '#A34AE2', '#4AE2D1'].map((color) => (
              <button
                key={color}
                onClick={() => updateSettings({ accentColor: color })}
                className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-900 shadow-sm relative transition-transform hover:scale-110"
                style={{ backgroundColor: color }}
              >
                {settings.accentColor === color && (
                  <div className="absolute inset-0 flex items-center justify-center text-white">
                    <Check size={16} />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderNotifications = () => (
    <div className="space-y-6">
      <SectionHeader title="Notifications" onBack={() => setActiveSection('main')} />
      <div className="glass-card overflow-hidden">
        <ToggleItem 
          icon={<Bell size={20} />} 
          label="Enable Notifications" 
          value={settings.notificationsEnabled} 
          onChange={(val) => updateSettings({ notificationsEnabled: val })} 
        />
        <ToggleItem 
          icon={<Clock size={20} />} 
          label="Study Reminders" 
          value={settings.studyReminders} 
          onChange={(val) => updateSettings({ studyReminders: val })} 
        />
        <ToggleItem 
          icon={<Volume2 size={20} />} 
          label="Sound" 
          value={settings.soundEnabled} 
          onChange={(val) => updateSettings({ soundEnabled: val })} 
        />
        <ToggleItem 
          icon={<Vibrate size={20} />} 
          label="Vibration" 
          value={settings.vibrationEnabled} 
          onChange={(val) => updateSettings({ vibrationEnabled: val })} 
        />
      </div>
    </div>
  );

  const renderStudy = () => (
    <div className="space-y-6">
      <SectionHeader title="Study Settings" onBack={() => setActiveSection('main')} />
      <div className="glass-card p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Focus Duration (min)</label>
            <input 
              type="number" 
              value={settings.focusDuration}
              onChange={(e) => updateSettings({ focusDuration: parseInt(e.target.value) })}
              className="premium-input"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Break Duration (min)</label>
            <input 
              type="number" 
              value={settings.breakDuration}
              onChange={(e) => updateSettings({ breakDuration: parseInt(e.target.value) })}
              className="premium-input"
            />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase">Daily Study Goal (min)</label>
          <input 
            type="number" 
            value={settings.dailyGoal}
            onChange={(e) => updateSettings({ dailyGoal: parseInt(e.target.value) })}
            className="premium-input"
          />
        </div>
        <ToggleItem 
          icon={<Clock size={20} />} 
          label="Auto Start Break" 
          value={settings.autoStartBreak} 
          onChange={(val) => updateSettings({ autoStartBreak: val })} 
          noBorder
        />
      </div>
    </div>
  );

  const renderData = () => (
    <div className="space-y-6">
      <SectionHeader title="Data & Storage" onBack={() => setActiveSection('main')} />
      <div className="glass-card overflow-hidden">
        <SettingsMenuItem 
          icon={<Upload size={20} className="text-blue-500" />} 
          label="Backup Data" 
          description="Save your data to a file" 
          onClick={() => {}} 
        />
        <SettingsMenuItem 
          icon={<Download size={20} className="text-emerald-500" />} 
          label="Restore Data" 
          description="Load data from a backup file" 
          onClick={() => {}} 
        />
        <SettingsMenuItem 
          icon={<FileJson size={20} className="text-amber-500" />} 
          label="Export as JSON" 
          description="Download all data in JSON format" 
          onClick={() => {}} 
        />
        <SettingsMenuItem 
          icon={<Trash2 size={20} className="text-red-500" />} 
          label="Clear Cache" 
          description="Remove temporary files" 
          onClick={() => {}} 
          noBorder
        />
      </div>
    </div>
  );

  const renderPrivacy = () => (
    <div className="space-y-6">
      <SectionHeader title="Privacy & Security" onBack={() => setActiveSection('main')} />
      <div className="glass-card overflow-hidden">
        <SettingsMenuItem 
          icon={<Shield size={20} className="text-blue-500" />} 
          label="App Permissions" 
          description="Manage camera and storage access" 
          onClick={() => {}} 
        />
        <SettingsMenuItem 
          icon={<Shield size={20} className="text-emerald-500" />} 
          label="Data Protection" 
          description="How we keep your data safe" 
          onClick={() => {}} 
          noBorder
        />
      </div>
    </div>
  );

  const renderAbout = () => (
    <div className="space-y-6">
      <SectionHeader title="About" onBack={() => setActiveSection('main')} />
      <div className="glass-card p-8 flex flex-col items-center text-center space-y-4">
        <div className="w-20 h-20 bg-brand-600 rounded-[2rem] flex items-center justify-center text-white shadow-xl shadow-brand-200 dark:shadow-none mb-2">
          <SettingsIcon size={40} />
        </div>
        <div>
          <h2 className="text-2xl font-display font-bold">StudyPro</h2>
          <p className="text-slate-400 text-sm">Version 2.1.0</p>
        </div>
        <p className="text-sm text-slate-500 max-w-xs">
          Your ultimate companion for focused studying and document management.
        </p>
        <div className="w-full pt-4 space-y-2">
          <button className="w-full py-3 text-sm font-bold text-brand-600 dark:text-brand-400 hover:bg-brand-50 dark:hover:bg-brand-900/20 rounded-xl transition-colors">
            Privacy Policy
          </button>
          <button className="w-full py-3 text-sm font-bold text-brand-600 dark:text-brand-400 hover:bg-brand-50 dark:hover:bg-brand-900/20 rounded-xl transition-colors">
            Terms of Service
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 pb-32 max-w-4xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl font-display font-bold tracking-tight">Settings</h1>
        <p className="text-slate-400">Customize your study experience</p>
      </header>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          {activeSection === 'main' && renderMain()}
          {activeSection === 'appearance' && renderAppearance()}
          {activeSection === 'notifications' && renderNotifications()}
          {activeSection === 'study' && renderStudy()}
          {activeSection === 'data' && renderData()}
          {activeSection === 'privacy' && renderPrivacy()}
          {activeSection === 'about' && renderAbout()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

const QuickControlCard: React.FC<{ icon: React.ReactNode, label: string, value: boolean, onChange: (val: boolean) => void }> = ({ icon, label, value, onChange }) => (
  <button 
    onClick={() => onChange(!value)}
    className={`p-6 rounded-[2rem] border transition-all flex items-center justify-between ${
      value 
        ? 'bg-white dark:bg-slate-900 border-brand-500/30 shadow-xl shadow-brand-500/5' 
        : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800'
    }`}
  >
    <div className="flex items-center gap-4">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${value ? 'bg-brand-600 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'}`}>
        {icon}
      </div>
      <span className="font-bold text-sm">{label}</span>
    </div>
    <div className={`w-12 h-6 rounded-full transition-all relative ${value ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-800'}`}>
      <motion.div 
        animate={{ x: value ? 24 : 4 }}
        className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
      />
    </div>
  </button>
);

const SettingsMenuItem: React.FC<{ icon: React.ReactNode, label: string, description: string, onClick: () => void, noBorder?: boolean }> = ({ icon, label, description, onClick, noBorder }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left ${!noBorder ? 'border-b border-slate-100 dark:border-slate-800' : ''}`}
  >
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-950 flex items-center justify-center">
        {icon}
      </div>
      <div>
        <h4 className="font-bold text-sm">{label}</h4>
        <p className="text-[10px] text-slate-400 uppercase tracking-widest font-medium">{description}</p>
      </div>
    </div>
    <ChevronRight size={18} className="text-slate-300" />
  </button>
);

const ToggleItem: React.FC<{ icon: React.ReactNode, label: string, value: boolean, onChange: (val: boolean) => void, noBorder?: boolean }> = ({ icon, label, value, onChange, noBorder }) => (
  <div className={`flex items-center justify-between p-4 ${!noBorder ? 'border-b border-slate-100 dark:border-slate-800' : ''}`}>
    <div className="flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-950 flex items-center justify-center text-slate-500">
        {icon}
      </div>
      <span className="font-bold text-sm">{label}</span>
    </div>
    <button 
      onClick={() => onChange(!value)}
      className={`w-12 h-6 rounded-full transition-all relative ${value ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-800'}`}
    >
      <motion.div 
        animate={{ x: value ? 24 : 4 }}
        className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
      />
    </button>
  </div>
);

const SectionHeader: React.FC<{ title: string, onBack: () => void }> = ({ title, onBack }) => (
  <div className="flex items-center gap-4 mb-2">
    <button 
      onClick={onBack}
      className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
    >
      <ArrowLeft size={20} />
    </button>
    <h2 className="text-xl font-display font-bold">{title}</h2>
  </div>
);

export default Settings;
