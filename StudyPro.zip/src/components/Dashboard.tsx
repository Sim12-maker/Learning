import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  Trophy, 
  Timer as TimerIcon, 
  Target, 
  Brain, 
  ChevronRight,
  Plus,
  User,
  CheckCircle2,
  Circle,
  Play,
  Pause,
  RotateCcw,
  Settings as SettingsIcon,
  RefreshCw,
  WifiOff,
  CloudCheck
} from 'lucide-react';
import { motion } from 'motion/react';
import { db } from '../db';
import { usePWA } from '../context/PWAContext';
import { useTimer } from '../context/TimerContext';
import { UserProfile, TimerSession, Note, Task } from '../types';

interface DashboardProps {
  onNavigate: (view: any) => void;
  onNewNote: () => void;
}

export default function Dashboard({ onNavigate, onNewNote }: DashboardProps) {
  const { 
    timeLeft, 
    isActive, 
    mode, 
    progress, 
    toggleTimer, 
    resetTimer, 
    formatTime 
  } = useTimer();
  
  const { isOffline, isSyncing, hasUnsyncedData, syncData } = usePWA();
  
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [sessions, setSessions] = useState<TimerSession[]>([]);
  const [recentNotes, setRecentNotes] = useState<Note[]>([]);
  const [pendingTasks, setPendingTasks] = useState<Task[]>([]);
  const [todayMins, setTodayMins] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const p = await db.get('userProfile', 1);
      const s = await db.getAll('timerSessionsStore');
      const n = await db.getAll('notes');
      const t = await db.getAll('tasksStore');
      
      setProfile(p);
      setSessions(s);
      
      const sortedNotes = [...n].sort((a, b) => 
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      ).slice(0, 3);
      setRecentNotes(sortedNotes);

      const pending = t.filter(task => !task.completed).slice(0, 3);
      setPendingTasks(pending);

      const today = new Date().toDateString();
      const todayStudy = s
        .filter(session => new Date(session.date).toDateString() === today)
        .reduce((acc, session) => acc + session.duration, 0);
      setTodayMins(todayStudy);
    };
    fetchData();
  }, []);

  const stats = [
    { label: 'Total Hours', val: (sessions.reduce((acc, s) => acc + s.duration, 0) / 60).toFixed(1), icon: TimerIcon, color: 'text-blue-500' },
    { label: 'Sessions', val: sessions.length, icon: Target, color: 'text-emerald-500' },
    { label: 'Focus Score', val: '88%', icon: Brain, color: 'text-purple-500' },
  ];

  return (
    <div className="px-6 pb-24 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <header className="flex justify-between items-center pt-4">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight text-slate-900 dark:text-white">
            Hi, {profile?.name || 'Student'}!
          </h1>
          <p className="text-slate-500 text-sm font-medium mt-1">
            {profile?.goal || 'Ready to crush your goals?'}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl glass-card flex items-center justify-center text-brand-600 dark:text-brand-400 border border-brand-200 dark:border-brand-800">
            <User size={24} />
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Focus Card & Timer */}
        <div className="lg:col-span-2 space-y-6">
          <motion.div 
            whileHover={{ scale: 1.005 }}
            className="relative overflow-hidden bg-brand-600 rounded-[2.5rem] p-8 text-white shadow-2xl shadow-brand-200 dark:shadow-none"
          >
            <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="flex-1">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-70">Daily Focus Time</span>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-6xl font-display font-bold tracking-tighter">{todayMins}</span>
                  <span className="text-xl font-medium opacity-60">mins</span>
                </div>
                
                <div className="mt-8 flex gap-3">
                  <div className="px-4 py-2 bg-brand-400/20 backdrop-blur-md rounded-xl border border-brand-400/30 flex items-center gap-2">
                    <Flame size={16} className="text-orange-300" />
                    <span className="text-xs font-bold">3 Day Streak</span>
                  </div>
                  <div className="px-4 py-2 bg-brand-400/20 backdrop-blur-md rounded-xl border border-brand-400/30 flex items-center gap-2">
                    <Trophy size={16} className="text-yellow-300" />
                    <span className="text-xs font-bold">Top Student</span>
                  </div>
                </div>
              </div>

              {/* Integrated Timer Widget - Persistent & Horizontal */}
              <div className="w-full md:w-auto glass-morphism p-6 rounded-[2rem] border-white/10 flex items-center gap-6">
                <div className="relative w-28 h-28 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90 transform">
                    <circle cx="56" cy="56" r="50" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-white/10" />
                    <motion.circle
                      cx="56"
                      cy="56"
                      r="50"
                      stroke="currentColor"
                      strokeWidth="6"
                      fill="transparent"
                      strokeDasharray={2 * Math.PI * 50}
                      animate={{ strokeDashoffset: 2 * Math.PI * 50 * (1 - progress) }}
                      className="text-white"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-xl font-display font-bold tracking-tighter">{formatTime(timeLeft)}</span>
                    <span className="text-[8px] font-bold uppercase tracking-widest opacity-60">{mode}</span>
                  </div>
                </div>
                
                <div className="flex flex-col gap-3">
                  <button 
                    onClick={toggleTimer}
                    className="w-10 h-10 bg-white text-brand-600 rounded-xl flex items-center justify-center shadow-xl hover:scale-105 active:scale-95 transition-all"
                  >
                    {isActive ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                  </button>
                  <button onClick={resetTimer} className="w-10 h-10 bg-white/10 text-white rounded-xl flex items-center justify-center hover:bg-white/20 active:scale-95 transition-all">
                    <RotateCcw size={18} />
                  </button>
                  <button onClick={() => onNavigate('timer')} className="w-10 h-10 bg-white/10 text-white rounded-xl flex items-center justify-center hover:bg-white/20 active:scale-95 transition-all">
                    <SettingsIcon size={18} />
                  </button>
                </div>
              </div>
            </div>
            
            {/* Abstract Background Shapes */}
            <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-slate-100/10 rounded-full blur-3xl"></div>
            <div className="absolute -left-12 -top-12 w-48 h-48 bg-brand-400/20 rounded-full blur-2xl"></div>
          </motion.div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={onNewNote}
              className="glass-card p-6 rounded-[2rem] flex flex-col items-center gap-3 thumb-button border-white/10"
            >
              <div className="w-12 h-12 rounded-2xl bg-brand-100 dark:bg-brand-900/30 flex items-center justify-center text-brand-600 dark:text-brand-400">
                <Plus size={24} />
              </div>
              <span className="text-xs font-bold uppercase tracking-widest">New Note</span>
            </button>
            <button 
              onClick={() => onNavigate('tasks')}
              className="glass-card p-6 rounded-[2rem] flex flex-col items-center gap-3 thumb-button border-white/10"
            >
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 size={24} />
              </div>
              <span className="text-xs font-bold uppercase tracking-widest">Tasks</span>
            </button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4">
            {stats.map((s, i) => (
              <div key={i} className="glass-card p-4 rounded-3xl text-center border-white/10">
                <s.icon size={20} className={`mx-auto mb-2 ${s.color}`} />
                <div className="text-lg font-bold tracking-tight">{s.val}</div>
                <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar content on desktop */}
        <div className="space-y-6">
          {/* Pending Tasks */}
          <section className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <h2 className="text-lg font-display font-bold tracking-tight">Pending Tasks</h2>
              <button onClick={() => onNavigate('tasks')} className="text-xs font-bold text-brand-600 dark:text-brand-400 flex items-center gap-1">
                View All <ChevronRight size={14} />
              </button>
            </div>
            
            <div className="space-y-3">
              {pendingTasks.length > 0 ? pendingTasks.map((task) => (
                <button 
                  key={task.id}
                  onClick={() => onNavigate('tasks')}
                  className="w-full glass-card p-5 rounded-[2rem] flex items-center gap-4 thumb-button border-white/10"
                >
                  <div className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 border border-slate-200 dark:border-slate-700">
                    <Circle size={20} />
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <h4 className="font-bold text-sm tracking-tight truncate">{task.title}</h4>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[8px] font-bold text-brand-600 dark:text-brand-400 uppercase tracking-widest">{task.subject}</span>
                    </div>
                  </div>
                </button>
              )) : (
                <div className="glass-card p-8 rounded-[2rem] text-center">
                  <p className="text-xs font-medium text-slate-400">No pending tasks</p>
                </div>
              )}
            </div>
          </section>

          {/* Recent Notes */}
          <section className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <h2 className="text-lg font-display font-bold tracking-tight">Recent Notes</h2>
              <button onClick={() => onNavigate('notes')} className="text-xs font-bold text-brand-600 dark:text-brand-400 flex items-center gap-1">
                View All <ChevronRight size={14} />
              </button>
            </div>
            
            <div className="space-y-3">
              {recentNotes.length > 0 ? recentNotes.map((note) => (
                <button 
                  key={note.id}
                  onClick={() => onNavigate('notes')}
                  className="w-full glass-card p-5 rounded-[2rem] flex flex-col items-start text-left thumb-button border-white/10"
                >
                  <div className="flex justify-between items-center w-full mb-2">
                    <span className="px-2 py-0.5 bg-brand-100 dark:bg-brand-900/30 text-[8px] font-bold text-brand-600 dark:text-brand-400 uppercase tracking-widest rounded-md">
                      {note.subject}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm tracking-tight">{note.title}</h4>
                </button>
              )) : (
                <div className="glass-card p-8 rounded-[2rem] text-center">
                  <p className="text-xs font-medium text-slate-400">No recent notes</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
