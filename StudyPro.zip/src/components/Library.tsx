import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  BookOpen, 
  Video, 
  FileText, 
  ExternalLink, 
  Trash2, 
  X,
  ChevronRight,
  Library as LibraryIcon,
  FileUp,
  FileCode,
  File as FileIcon,
  Download,
  Globe,
  ArrowUpDown,
  CheckSquare,
  Clock,
  Square,
  Eye,
  Tag,
  FolderInput,
  MoreVertical,
  WifiOff,
  Music,
  ListMusic,
  Play,
  Star,
  Share2,
  Filter,
  LayoutGrid,
  List as ListIcon,
  Folder,
  FileSpreadsheet,
  Presentation,
  Image as ImageIcon,
  Type as TypeIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db';
import { Resource } from '../types';
import { usePWA } from '../context/PWAContext';
import { LOFI_TRACKS } from '../constants';
import MediaPlayer from './MediaPlayer';
import DocumentViewer from './DocumentViewer';

type SortField = 'title' | 'addedAt' | 'type' | 'subject' | 'fileSize';
type SortOrder = 'asc' | 'desc';
type ViewMode = 'grid' | 'list';

interface LibraryProps {
  onPlayMedia: (media: { src: string, type: 'video' | 'audio', title: string }) => void;
}

const CATEGORIES = [
  { id: 'all', label: 'All', icon: <LibraryIcon size={14} /> },
  { id: 'favorites', label: 'Favorites', icon: <Star size={14} /> },
  { id: 'documents', label: 'Documents', icon: <FileText size={14} /> },
  { id: 'presentations', label: 'Presentations', icon: <Presentation size={14} /> },
  { id: 'images', label: 'Images', icon: <ImageIcon size={14} /> },
  { id: 'video', label: 'Videos', icon: <Video size={14} /> },
  { id: 'audio', label: 'Audio', icon: <Music size={14} /> },
  { id: 'playlists', label: 'Playlists', icon: <ListIcon size={14} /> },
  { id: 'other', label: 'Other', icon: <Folder size={14} /> },
];

export default function Library({ onPlayMedia }: LibraryProps) {
  const { isOffline } = usePWA();
  const [resources, setResources] = useState<Resource[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isCreatePlaylistModalOpen, setIsCreatePlaylistModalOpen] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [selectedForPlaylist, setSelectedForPlaylist] = useState<Set<string>>(new Set());
  const [downloadUrl, setDownloadUrl] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  
  // Sorting state
  const [sortBy, setSortBy] = useState<SortField>('addedAt');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  
  // Batch selection state
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  
  // Document Viewer state
  const [documentViewer, setDocumentViewer] = useState<Resource | null>(null);
  const [recentlyPlayed, setRecentlyPlayed] = useState<Resource[]>([]);
  const [playlists, setPlaylists] = useState<any[]>([]);

  useEffect(() => {
    fetchData();
    fetchExtras();
  }, []);

  const fetchData = async () => {
    const stored = await db.getAll('resourcesStore');
    setResources(stored);
  };

  const fetchExtras = async () => {
    try {
      const recent = await db.getAll('recentlyPlayedStore');
      const allResources = await db.getAll('resourcesStore');
      const recentResources = recent
        .sort((a, b) => new Date(b.playedAt).getTime() - new Date(a.playedAt).getTime())
        .slice(0, 10)
        .map(r => allResources.find(res => res.id === r.resourceId))
        .filter(Boolean) as Resource[];
      setRecentlyPlayed(recentResources);

      const pl = await db.getAll('playlistsStore');
      setPlaylists(pl);
    } catch (e) {
      console.error('Failed to fetch extras', e);
    }
  };

  const addToRecentlyPlayed = async (res: Resource) => {
    try {
      await db.put('recentlyPlayedStore', {
        id: uuidv4(),
        resourceId: res.id,
        playedAt: new Date().toISOString()
      });
      fetchExtras();
    } catch (e) {
      console.error('Failed to add to recently played', e);
    }
  };

  const getCategoryFromExtension = (ext: string): string => {
    const docs = ['pdf', 'doc', 'docx', 'txt', 'md', 'rtf'];
    const ppts = ['ppt', 'pptx'];
    const sheets = ['xls', 'xlsx', 'csv'];
    const imgs = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp'];
    const vids = ['mp4', 'mkv', 'avi', 'mov', 'webm'];
    const auds = ['mp3', 'wav', 'ogg', 'm4a'];
    
    if (docs.includes(ext)) return 'documents';
    if (ppts.includes(ext)) return 'presentations';
    if (sheets.includes(ext)) return 'spreadsheets';
    if (imgs.includes(ext)) return 'images';
    if (vids.includes(ext)) return 'video';
    if (auds.includes(ext)) return 'audio';
    return 'other';
  };

  const handleAdd = async (data: Partial<Resource>) => {
    const newRes: Resource = {
      id: uuidv4(),
      title: data.title || 'Untitled Resource',
      type: data.type || 'pdf',
      category: data.category || 'other',
      url: data.url || '#',
      subject: data.subject || 'General',
      isFavorite: false,
      addedAt: new Date().toISOString(),
      synced: 0
    };
    await db.put('resourcesStore', newRes);
    setIsAddModalOpen(false);
    fetchData();
  };

  const handleDownload = async () => {
    if (!downloadUrl) return;
    
    setIsDownloadModalOpen(false);
    const id = uuidv4();
    const ext = downloadUrl.split('.').pop()?.toLowerCase() || 'link';
    const category = getCategoryFromExtension(ext);

    const newResource: Resource = {
      id,
      title: downloadUrl.split('/').pop() || 'Downloaded Link',
      type: ext as any,
      category: category as any,
      subject: 'General',
      addedAt: new Date().toISOString(),
      isFavorite: false,
      url: downloadUrl,
      synced: 0
    };

    await db.put('resourcesStore', newResource);
    setDownloadUrl('');
    fetchData();
  };

  const handleCreatePlaylist = async () => {
    if (!newPlaylistName) return;
    
    const newPlaylist = {
      id: uuidv4(),
      name: newPlaylistName,
      resourceIds: Array.from(selectedForPlaylist),
      createdAt: new Date().toISOString()
    };

    await db.put('playlistsStore', newPlaylist);
    setNewPlaylistName('');
    setSelectedForPlaylist(new Set());
    setIsCreatePlaylistModalOpen(false);
    fetchExtras();
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const extension = file.name.split('.').pop()?.toLowerCase() || '';
    let type: Resource['type'] = 'pdf';
    
    const allowedTypes = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'txt', 'png', 'jpg', 'mp4', 'mkv', 'avi', 'mp3', 'wav', 'video'];
    if (allowedTypes.includes(extension)) {
      type = extension as any;
    } else if (file.type.startsWith('image/')) {
      type = 'png';
    } else if (file.type.startsWith('video/')) {
      type = 'video';
    } else if (file.type.startsWith('audio/')) {
      type = 'mp3';
    }

    const newRes: Resource = {
      id: uuidv4(),
      title: file.name,
      type: type,
      category: getCategoryFromExtension(extension),
      fileData: file,
      fileName: file.name,
      fileSize: file.size,
      subject: 'Imported',
      isFavorite: false,
      addedAt: new Date().toISOString(),
      synced: 0
    };

    await db.put('resourcesStore', newRes);
    fetchData();
    e.target.value = '';
  };

  const toggleFavorite = async (res: Resource) => {
    const updated = { ...res, isFavorite: !res.isFavorite };
    await db.put('resourcesStore', updated);
    fetchData();
  };

  const handleShare = async (res: Resource) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: res.title,
          text: `Check out this study resource: ${res.title}`,
          url: res.url && res.url !== '#' ? res.url : undefined,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      // Fallback: copy link to clipboard
      if (res.url && res.url !== '#') {
        navigator.clipboard.writeText(res.url);
        alert('Link copied to clipboard!');
      } else {
        alert('Sharing is not supported on this device for local files.');
      }
    }
  };

  const openResource = (res: Resource, mode: 'internal' | 'external' = 'internal') => {
    if (res.fileData) {
      const url = URL.createObjectURL(res.fileData);
      
      if (mode === 'external') {
        window.open(url, '_blank');
        return;
      }

      if (res.fileData.type.startsWith('video/') || res.type === 'video' || res.type === 'mp4' || res.type === 'mkv' || res.type === 'avi') {
        onPlayMedia({ src: url, type: 'video', title: res.title });
        addToRecentlyPlayed(res);
        return;
      }
      if (res.fileData.type.startsWith('audio/') || res.type === 'mp3' || res.type === 'wav') {
        onPlayMedia({ src: url, type: 'audio', title: res.title });
        addToRecentlyPlayed(res);
        return;
      }

      const type = res.fileData.type;
      const isViewable = type === 'application/pdf' || 
                        type === 'text/plain' || 
                        type === 'text/markdown' || 
                        type.startsWith('image/') || 
                        ['pdf', 'txt', 'md', 'png', 'jpg'].includes(res.type);

      if (isViewable) {
        setDocumentViewer(res);
        addToRecentlyPlayed(res);
        return;
      }

      window.open(url, '_blank');
    } else if (res.url && res.url !== '#') {
      if (res.category === 'video') {
        onPlayMedia({ src: res.url, type: 'video', title: res.title });
      } else if (res.category === 'audio') {
        onPlayMedia({ src: res.url, type: 'audio', title: res.title });
      } else {
        window.open(res.url, '_blank');
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this resource?')) {
      await db.delete('resourcesStore', id);
      fetchData();
    }
  };

  const filtered = useMemo(() => {
    return resources.filter(r => {
      const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           r.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           (r.tags && r.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())));
      
      let matchesCategory = true;
      if (selectedCategory === 'favorites') matchesCategory = r.isFavorite;
      else if (selectedCategory !== 'all') matchesCategory = r.category === selectedCategory;
      
      return matchesSearch && matchesCategory;
    }).sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'title') comparison = a.title.localeCompare(b.title);
      else if (sortBy === 'addedAt') comparison = new Date(a.addedAt).getTime() - new Date(b.addedAt).getTime();
      else if (sortBy === 'type') comparison = a.type.localeCompare(b.type);
      else if (sortBy === 'subject') comparison = a.subject.localeCompare(b.subject);
      else if (sortBy === 'fileSize') comparison = (a.fileSize || 0) - (b.fileSize || 0);
      
      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [resources, searchQuery, selectedCategory, sortBy, sortOrder]);

  const toggleSelection = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelectedIds(newSelected);
  };

  const handleBatchDelete = async () => {
    if (selectedIds.size === 0) return;
    if (confirm(`Delete ${selectedIds.size} resources?`)) {
      for (const id of selectedIds) {
        await db.delete('resourcesStore', id);
      }
      setSelectedIds(new Set());
      setIsSelectionMode(false);
      fetchData();
    }
  };

  const handleSelectAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map(r => r.id)));
    }
  };

  const formatSize = (bytes?: number) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const getTypeIcon = (res: Resource) => {
    if (res.fileData && res.fileData.type.startsWith('image/')) {
      return (
        <img 
          src={URL.createObjectURL(res.fileData)} 
          alt="preview" 
          className="w-full h-full object-cover rounded-2xl"
          referrerPolicy="no-referrer"
        />
      );
    }

    switch (res.type) {
      case 'pdf': return <FileText size={20} className="text-rose-500" />;
      case 'txt': return <TypeIcon size={20} className="text-slate-500" />;
      case 'docx': return <FileText size={20} className="text-blue-500" />;
      case 'ppt':
      case 'pptx': return <Presentation size={20} className="text-orange-500" />;
      case 'png':
      case 'jpg': return <ImageIcon size={20} className="text-emerald-500" />;
      case 'video':
      case 'mp4':
      case 'mkv':
      case 'avi': return <Video size={20} className="text-brand-500" />;
      case 'mp3':
      case 'wav': return <Music size={20} className="text-indigo-500" />;
      default: return <FileIcon size={20} />;
    }
  };

  return (
    <div className="px-6 pb-32 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-center pt-4">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight">Library</h1>
          <p className="text-xs text-slate-400 font-medium uppercase tracking-widest mt-1">
            {resources.length} Items • {formatSize(resources.reduce((acc, r) => acc + (r.fileSize || 0), 0))}
          </p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
            className="w-12 h-12 rounded-2xl glass-card border border-white/10 flex items-center justify-center text-slate-500 thumb-button"
          >
            {viewMode === 'grid' ? <ListIcon size={20} /> : <LayoutGrid size={20} />}
          </button>
          <button 
            onClick={() => {
              setIsSelectionMode(!isSelectionMode);
              setSelectedIds(new Set());
            }}
            className={`w-12 h-12 rounded-2xl border flex items-center justify-center transition-all thumb-button ${
              isSelectionMode 
                ? 'bg-brand-600 text-white border-brand-600' 
                : 'glass-card border-white/10 text-slate-500'
            }`}
          >
            <CheckSquare size={20} />
          </button>
          <button 
            onClick={() => setIsDownloadModalOpen(true)}
            className="w-12 h-12 rounded-2xl glass-card border border-white/10 flex items-center justify-center text-slate-500 thumb-button hover:text-brand-600 transition-colors"
            title="Download from Link"
          >
            <Download size={20} />
          </button>
          <label className="w-12 h-12 rounded-2xl glass-card border border-white/10 flex items-center justify-center text-slate-500 cursor-pointer thumb-button hover:text-brand-600 transition-colors">
            <FileUp size={20} />
            <input 
              type="file" 
              className="hidden" 
              accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.png,.jpg,.mp4,.mkv,.avi,.mp3,.wav,image/*,video/*,audio/*"
              onChange={handleImport}
            />
          </label>
          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="w-12 h-12 rounded-2xl bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
          >
            <Plus size={24} />
          </button>
        </div>
      </header>

      {/* Recently Played Section */}
      {recentlyPlayed.length > 0 && selectedCategory === 'all' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <Clock size={14} /> Recently Accessed
            </h3>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {recentlyPlayed.map(res => (
              <motion.div 
                key={`recent-${res.id}`}
                onClick={() => openResource(res, 'internal')}
                className="w-40 shrink-0 glass-card p-3 rounded-2xl border-white/10 cursor-pointer hover:border-brand-500/50 transition-all"
              >
                <div className="aspect-video bg-slate-100 dark:bg-slate-900 rounded-xl mb-2 flex items-center justify-center text-slate-300 overflow-hidden">
                  {getTypeIcon(res)}
                </div>
                <h4 className="text-[10px] font-bold truncate tracking-tight">{res.title}</h4>
                <p className="text-[8px] text-slate-400 uppercase font-bold mt-0.5">{res.subject}</p>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Playlists Section */}
      {selectedCategory === 'playlists' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <ListMusic size={14} /> Your Playlists
            </h3>
            <button 
              onClick={() => setIsCreatePlaylistModalOpen(true)}
              className="text-[10px] font-bold text-brand-600 uppercase tracking-widest flex items-center gap-1"
            >
              <Plus size={12} /> New Playlist
            </button>
          </div>
          {playlists.length === 0 ? (
            <div className="glass-card p-8 rounded-3xl border-white/10 text-center space-y-4">
              <div className="w-16 h-16 bg-slate-100 dark:bg-slate-900 rounded-2xl flex items-center justify-center text-slate-300 mx-auto">
                <ListMusic size={32} />
              </div>
              <p className="text-sm text-slate-500">No playlists created yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {playlists.map(pl => (
                <div key={pl.id} className="glass-card p-4 rounded-3xl border-white/10 space-y-3">
                  <div className="aspect-square bg-slate-100 dark:bg-slate-900 rounded-2xl flex items-center justify-center text-slate-300">
                    <ListMusic size={32} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{pl.name}</h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{pl.resourceIds.length} Items</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Batch Actions Bar */}
      <AnimatePresence>
        {isSelectionMode && (
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="bg-brand-600 text-white p-4 rounded-3xl flex items-center justify-between shadow-xl sticky top-4 z-50 border border-brand-500"
          >
            <div className="flex items-center gap-3">
              <button 
                onClick={handleSelectAll}
                className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
              >
                {selectedIds.size === filtered.length ? <CheckSquare size={16} /> : <Square size={16} />}
              </button>
              <span className="text-xs font-bold uppercase tracking-widest">{selectedIds.size} Selected</span>
            </div>
            <div className="flex gap-2">
              {selectedIds.size > 0 && (
                <button onClick={handleBatchDelete} className="p-2 bg-rose-500 hover:bg-rose-600 rounded-xl transition-colors flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider">
                  <Trash2 size={14} /> Delete
                </button>
              )}
              <button 
                onClick={() => {
                  setIsSelectionMode(false);
                  setSelectedIds(new Set());
                }}
                className="p-2 bg-slate-900/20 hover:bg-slate-900/30 rounded-xl transition-colors text-[10px] font-bold uppercase tracking-wider"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search & Filter */}
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search documents, videos, audio..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="premium-input pl-12"
            />
          </div>
          <button 
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="w-14 h-14 glass-card rounded-2xl border border-white/10 flex items-center justify-center text-slate-500 thumb-button"
          >
            <ArrowUpDown size={20} className={sortOrder === 'desc' ? 'rotate-180 transition-transform' : 'transition-transform'} />
          </button>
        </div>
        
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${
                selectedCategory === cat.id 
                  ? 'bg-brand-600 text-white' 
                  : 'glass-card text-slate-600 dark:text-slate-400 border-white/10'
              }`}
            >
              {cat.icon}
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          {(['addedAt', 'title', 'subject', 'fileSize'] as SortField[]).map(field => (
            <button
              key={field}
              onClick={() => setSortBy(field)}
              className={`flex-1 py-1.5 rounded-lg text-[8px] font-bold uppercase tracking-widest transition-all ${
                sortBy === field 
                  ? 'bg-slate-800 dark:bg-slate-100 text-white dark:text-slate-900' 
                  : 'glass-card text-slate-400 border-white/10'
              }`}
            >
              {field === 'addedAt' ? 'Date' : field === 'fileSize' ? 'Size' : field}
            </button>
          ))}
        </div>
      </div>

      {/* Resources List */}
      <div className={viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-2 gap-4" : "space-y-3"}>
        {filtered.length > 0 ? filtered.map(res => (
          <motion.div 
            layout
            key={res.id}
            onClick={() => isSelectionMode ? toggleSelection(res.id) : openResource(res, 'internal')}
            className={`glass-card p-4 rounded-[2rem] border-white/10 flex items-center gap-4 group transition-all ${
              isSelectionMode || !isSelectionMode ? 'cursor-pointer' : ''
            } ${selectedIds.has(res.id) ? 'ring-2 ring-brand-600 bg-brand-50/50 dark:bg-brand-900/10' : ''}`}
          >
            {isSelectionMode && (
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                selectedIds.has(res.id) ? 'bg-brand-600 border-brand-600 text-white' : 'border-slate-200 dark:border-slate-700'
              }`}>
                {selectedIds.has(res.id) && <CheckSquare size={12} />}
              </div>
            )}

            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border shrink-0 overflow-hidden bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800`}>
              {getTypeIcon(res)}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{res.subject}</span>
                <span className="text-[8px] font-bold text-slate-300 uppercase tracking-widest">•</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                  {formatSize(res.fileSize)}
                </span>
              </div>
              <h4 className="font-bold text-sm truncate pr-4 tracking-tight">{res.title}</h4>
              <div className="flex items-center gap-2 mt-1">
                <span className={`px-2 py-0.5 rounded-md text-[8px] font-bold uppercase tracking-wider ${
                  res.category === 'documents' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400' :
                  res.category === 'presentations' ? 'bg-orange-100 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400' :
                  res.category === 'video' ? 'bg-brand-100 text-brand-600 dark:bg-brand-900/20 dark:text-brand-400' :
                  res.category === 'audio' ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400' :
                  'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                }`}>
                  {res.category}
                </span>
                {res.isFavorite && <Star size={12} className="text-amber-500 fill-current" />}
              </div>
            </div>
            
            {!isSelectionMode && (
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={(e) => { e.stopPropagation(); toggleFavorite(res); }}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${res.isFavorite ? 'text-amber-500' : 'text-slate-400 hover:text-amber-500'}`}
                >
                  <Star size={16} fill={res.isFavorite ? 'currentColor' : 'none'} />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleShare(res); }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-brand-600 transition-colors"
                >
                  <Share2 size={16} />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); openResource(res, 'internal'); }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-brand-600 transition-colors"
                  title="Open Internally"
                >
                  <Eye size={16} />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); openResource(res, 'external'); }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-brand-600 transition-colors"
                  title="Open Externally"
                >
                  <ExternalLink size={16} />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleDelete(res.id); }}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-rose-500 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            )}
          </motion.div>
        )) : (
          <div className="py-20 text-center glass-card rounded-[2.5rem] border-dashed border-white/10">
            <LibraryIcon size={48} className="mx-auto text-slate-200 mb-4" />
            <p className="text-slate-400 font-medium italic">No items found in this category.</p>
          </div>
        )}
      </div>

      {/* Document Viewer Overlay */}
      <AnimatePresence>
        {documentViewer && (
          <DocumentViewer 
            resource={documentViewer}
            onClose={() => {
              setDocumentViewer(null);
              fetchData();
            }}
          />
        )}
      </AnimatePresence>

      {/* Download from Link Modal */}
      <AnimatePresence>
        {isDownloadModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDownloadModalOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-display font-bold">Download from Link</h2>
                  <button onClick={() => setIsDownloadModalOpen(false)} className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-500">
                    <X size={20} />
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Direct URL</label>
                  <div className="relative">
                    <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="url" 
                      placeholder="https://example.com/video.mp4" 
                      value={downloadUrl}
                      onChange={(e) => setDownloadUrl(e.target.value)}
                      className="premium-input pl-12"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 ml-1">Enter a direct link to a video, audio, or document file.</p>
                </div>

                <button 
                  onClick={handleDownload}
                  disabled={!downloadUrl}
                  className="w-full py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-xl shadow-brand-200 dark:shadow-none disabled:opacity-50 disabled:shadow-none transition-all"
                >
                  Add to Library
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Create Playlist Modal */}
      <AnimatePresence>
        {isCreatePlaylistModalOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCreatePlaylistModalOpen(false)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-8 space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-display font-bold">Create Playlist</h2>
                  <button onClick={() => setIsCreatePlaylistModalOpen(false)} className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-500">
                    <X size={20} />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Playlist Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Study Vibes, Math Videos..." 
                      value={newPlaylistName}
                      onChange={(e) => setNewPlaylistName(e.target.value)}
                      className="premium-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Select Media</label>
                    <div className="max-h-60 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                      {resources.filter(r => r.category === 'video' || r.category === 'audio').map(res => (
                        <div 
                          key={res.id}
                          onClick={() => {
                            const next = new Set(selectedForPlaylist);
                            if (next.has(res.id)) next.delete(res.id);
                            else next.add(res.id);
                            setSelectedForPlaylist(next);
                          }}
                          className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                            selectedForPlaylist.has(res.id) 
                              ? 'bg-brand-50 border-brand-200 dark:bg-brand-900/20 dark:border-brand-800' 
                              : 'bg-slate-50 border-slate-100 dark:bg-slate-800/50 dark:border-slate-800'
                          }`}
                        >
                          <div className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                            selectedForPlaylist.has(res.id) ? 'bg-brand-600 border-brand-600 text-white' : 'border-slate-300 dark:border-slate-600'
                          }`}>
                            {selectedForPlaylist.has(res.id) && <CheckSquare size={12} />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold truncate">{res.title}</p>
                            <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest">{res.category}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <button 
                  onClick={handleCreatePlaylist}
                  disabled={!newPlaylistName || selectedForPlaylist.size === 0}
                  className="w-full py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-xl shadow-brand-200 dark:shadow-none disabled:opacity-50 disabled:shadow-none transition-all"
                >
                  Create Playlist
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Resource Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-8 space-y-6">
                <header className="flex justify-between items-center">
                  <h2 className="text-xl font-display font-bold">Add Resource</h2>
                  <button onClick={() => setIsAddModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                    <X size={20} />
                  </button>
                </header>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Title</label>
                    <input id="res-title" type="text" placeholder="Resource Title" className="premium-input" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Type</label>
                      <select id="res-type" className="premium-input appearance-none">
                        <option value="pdf">PDF Document</option>
                        <option value="docx">Word Document</option>
                        <option value="ppt">Presentation</option>
                        <option value="txt">Text File</option>
                        <option value="png">Image (PNG/JPG)</option>
                        <option value="video">Video (MP4/MKV)</option>
                        <option value="mp3">Audio (MP3/WAV)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Subject</label>
                      <input id="res-subject" type="text" placeholder="e.g. Math" className="premium-input" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">URL (Optional)</label>
                    <input id="res-url" type="url" placeholder="https://example.com" className="premium-input" />
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={async () => {
                      const title = (document.getElementById('res-title') as HTMLInputElement).value;
                      const type = (document.getElementById('res-type') as HTMLSelectElement).value as any;
                      const subject = (document.getElementById('res-subject') as HTMLInputElement).value;
                      const url = (document.getElementById('res-url') as HTMLInputElement).value;
                      
                      handleAdd({ 
                        title, 
                        type, 
                        subject, 
                        url, 
                        category: getCategoryFromExtension(type) 
                      });
                    }}
                    className="flex-1 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
                  >
                    Add Resource
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
