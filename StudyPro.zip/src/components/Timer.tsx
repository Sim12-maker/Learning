import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Brain, 
  Coffee, 
  CheckCircle2,
  X,
  Settings as SettingsIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTimer } from '../context/TimerContext';

export default function Timer() {
  const { 
    timeLeft, 
    isActive, 
    mode, 
    progress, 
    focusTime, 
    shortBreakTime, 
    longBreakTime,
    selectedSubject,
    timerSound,
    toggleTimer, 
    resetTimer,
    setFocusTime,
    setShortBreakTime,
    setLongBreakTime,
    setSelectedSubject,
    setTimerSound,
    formatTime
  } = useTimer();

  const TIMER_SOUNDS = [
    { id: 'bell', label: 'Classic Bell' },
    { id: 'digital', label: 'Digital Beep' },
    { id: 'bird', label: 'Nature Bird' },
    { id: 'chime', label: 'Wind Chime' }
  ];
  
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('timer_sound_enabled') !== 'false');

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    localStorage.setItem('timer_sound_enabled', String(next));
  };

  const modeColors = {
    focus: 'text-brand-600 dark:text-brand-400',
    break: 'text-emerald-500 dark:text-emerald-400'
  };

  const modeBgColors = {
    focus: 'bg-brand-600 shadow-brand-200',
    break: 'bg-emerald-500 shadow-emerald-200'
  };

  return (
    <div className="px-6 pb-12 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 flex flex-col items-center">
      <header className="w-full flex justify-between items-center pt-4">
        <h1 className="text-3xl font-display font-bold tracking-tight">Focus Timer</h1>
        <div className="flex gap-2">
          <div className={`px-4 py-2 rounded-2xl border flex items-center gap-2 transition-all duration-500 ${
            mode === 'focus' 
              ? 'bg-brand-50 dark:bg-brand-900/20 border-brand-100 dark:border-brand-800 text-brand-600' 
              : 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800 text-emerald-600'
          }`}>
            {mode === 'focus' ? <Brain size={16} /> : <Coffee size={16} />}
            <span className="text-[10px] font-bold uppercase tracking-widest">
              {mode === 'focus' ? 'Focus Mode' : 'Break Mode'}
            </span>
          </div>
          <div className="px-4 py-2 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
              {isActive ? 'Active' : 'Idle'}
            </span>
          </div>
        </div>
      </header>

      {/* Main Timer Card */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="w-full max-w-2xl glass-card p-8 md:p-12 rounded-[3rem] border-white/10 flex flex-col md:flex-row items-center justify-between gap-12 relative overflow-hidden"
      >
        {/* Subtle background pulse when active */}
        <AnimatePresence>
          {isActive && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.05 }}
              exit={{ opacity: 0 }}
              className={`absolute inset-0 ${mode === 'focus' ? 'bg-brand-600' : 'bg-emerald-500'} pointer-events-none`}
            />
          )}
        </AnimatePresence>

        {/* Left Side: Circular Timer */}
        <div className="flex flex-col items-center gap-4 relative z-10">
          <div className="relative w-64 h-64 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90 transform">
              <circle
                cx="128"
                cy="128"
                r="118"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                className="text-slate-100 dark:text-slate-800"
              />
              <motion.circle
                cx="128"
                cy="128"
                r="118"
                stroke="currentColor"
                strokeWidth="10"
                fill="transparent"
                strokeDasharray={2 * Math.PI * 118}
                animate={{ strokeDashoffset: 2 * Math.PI * 118 * (1 - progress) }}
                transition={{ duration: 1, ease: "linear" }}
                className={mode === 'focus' ? 'text-brand-600 dark:text-brand-400' : 'text-emerald-500 dark:text-emerald-400'}
                strokeLinecap="round"
              />
            </svg>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <motion.span 
                key={timeLeft}
                initial={{ scale: 0.95, opacity: 0.8 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-6xl font-display font-bold tracking-tighter"
              >
                {formatTime(timeLeft)}
              </motion.span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">
                  {mode === 'focus' ? 'Focusing' : 'Resting'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Controls */}
        <div className="flex flex-col gap-4 w-full md:w-auto relative z-10">
          <button 
            onClick={toggleTimer}
            className={`w-full md:w-48 py-6 rounded-[2rem] flex items-center justify-center gap-3 text-white font-bold shadow-2xl transition-all active:scale-95 ${
              isActive 
                ? 'bg-slate-800 dark:bg-slate-700' 
                : (mode === 'focus' ? 'bg-brand-600 shadow-brand-200 dark:shadow-none' : 'bg-emerald-500 shadow-emerald-200 dark:shadow-none')
            }`}
          >
            {isActive ? (
              <>
                <Pause size={24} fill="currentColor" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play size={24} fill="currentColor" className="ml-1" />
                <span>Start</span>
              </>
            )}
          </button>
          
          <div className="flex gap-4">
            <button 
              onClick={resetTimer}
              className="flex-1 py-5 rounded-[2rem] bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-all active:scale-95"
              title="Reset Timer"
            >
              <RotateCcw size={20} />
              <span className="ml-2 text-xs font-bold uppercase tracking-widest">Reset</span>
            </button>
            
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="flex-1 py-5 rounded-[2rem] bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-all active:scale-95"
              title="Settings"
            >
              <SettingsIcon size={20} />
              <span className="ml-2 text-xs font-bold uppercase tracking-widest">Settings</span>
            </button>
          </div>
        </div>
      </motion.div>

      {/* Subject Selector */}
      <div className="w-full max-w-md space-y-3">
        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Current Subject</label>
        <div className="relative">
          <input 
            type="text" 
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            placeholder="What are you studying?"
            className="premium-input pr-12 font-bold text-sm"
          />
          <Brain className={`absolute right-5 top-1/2 -translate-y-1/2 transition-colors ${mode === 'focus' ? 'text-brand-500' : 'text-emerald-500'}`} size={18} />
        </div>
      </div>

      {/* Settings Modal */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSettingsOpen(false)}
              className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-sm bg-slate-50 dark:bg-slate-900 rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden p-8 space-y-6"
            >
              <header className="flex justify-between items-center">
                <h2 className="text-xl font-display font-bold">Timer Settings</h2>
                <button onClick={() => setIsSettingsOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </header>

              <div className="space-y-4 max-h-[60vh] overflow-y-auto no-scrollbar pr-1">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Focus Duration (minutes)</label>
                  <input 
                    type="number" 
                    value={focusTime / 60}
                    onChange={(e) => setFocusTime(Math.max(1, Number(e.target.value)) * 60)}
                    className="premium-input"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Short Break (min)</label>
                    <input 
                      type="number" 
                      value={shortBreakTime / 60}
                      onChange={(e) => setShortBreakTime(Math.max(1, Number(e.target.value)) * 60)}
                      className="premium-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Long Break (min)</label>
                    <input 
                      type="number" 
                      value={longBreakTime / 60}
                      onChange={(e) => setLongBreakTime(Math.max(1, Number(e.target.value)) * 60)}
                      className="premium-input"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Alert Sound</label>
                  <div className="grid grid-cols-2 gap-2">
                    {TIMER_SOUNDS.map(sound => (
                      <button
                        key={sound.id}
                        onClick={() => setTimerSound(sound.id)}
                        className={`py-3 px-4 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all border ${
                          timerSound === sound.id 
                            ? 'bg-brand-600 text-white border-brand-600' 
                            : 'bg-white dark:bg-slate-950 text-slate-500 border-slate-200 dark:border-slate-800 hover:border-brand-300'
                        }`}
                      >
                        {sound.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-100 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800">
                  <div className="space-y-0.5">
                    <p className="text-sm font-bold">Sound Notifications</p>
                    <p className="text-[10px] text-slate-400 uppercase tracking-widest">Play alert when timer ends</p>
                  </div>
                  <button 
                    onClick={handleToggleSound}
                    className={`w-12 h-6 rounded-full transition-all relative ${soundEnabled ? 'bg-brand-600' : 'bg-slate-300 dark:bg-slate-800'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${soundEnabled ? 'right-1' : 'left-1'}`} />
                  </button>
                </div>
              </div>

              <button 
                onClick={() => setIsSettingsOpen(false)}
                className="w-full py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button"
              >
                Save Settings
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
