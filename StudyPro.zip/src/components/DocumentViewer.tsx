import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Save, 
  FileText, 
  Download, 
  Maximize, 
  Minimize,
  Edit3,
  Eye,
  ArrowLeft,
  ExternalLink,
  Highlighter,
  MessageSquare,
  Trash2,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { Resource, Annotation } from '../types';
import { db } from '../db';
import { v4 as uuidv4 } from 'uuid';

interface DocumentViewerProps {
  resource: Resource;
  onClose: () => void;
}

export default function DocumentViewer({ resource, onClose }: DocumentViewerProps) {
  const [content, setContent] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [bookmarks, setBookmarks] = useState<number[]>(resource.bookmarks || []);
  const [annotations, setAnnotations] = useState<Annotation[]>(resource.annotations || []);
  const [activeTool, setActiveTool] = useState<'none' | 'highlight' | 'note'>('none');
  const [showAnnotations, setShowAnnotations] = useState(true);
  
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (resource.fileData) {
      const url = URL.createObjectURL(resource.fileData);
      setFileUrl(url);

      if (resource.type === 'txt' || resource.type === 'md') {
        const reader = new FileReader();
        reader.onload = (e) => {
          setContent(e.target?.result as string || '');
        };
        reader.readAsText(resource.fileData);
      }

      return () => URL.revokeObjectURL(url);
    } else if (resource.url && resource.url !== '#') {
      setFileUrl(resource.url);
    }
  }, [resource]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      let updatedResource: Resource = {
        ...resource,
        bookmarks,
        annotations,
        synced: 0
      };

      if (isEditable && resource.fileData) {
        const blob = new Blob([content], { type: resource.fileData.type });
        const updatedFile = new File([blob], resource.fileName || 'document', { type: resource.fileData.type });
        updatedResource.fileData = updatedFile;
      }
      
      await db.put('resourcesStore', updatedResource);
      setIsEditing(false);
    } catch (e) {
      console.error('Failed to save document', e);
    } finally {
      setIsSaving(false);
    }
  };

  const addAnnotation = (e: React.MouseEvent) => {
    if (activeTool === 'none') return;
    
    const rect = contentRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const newAnnotation: Annotation = {
      id: uuidv4(),
      type: activeTool === 'highlight' ? 'highlight' : 'note',
      content: activeTool === 'highlight' ? '' : 'New note...',
      position: { x, y },
      color: activeTool === 'highlight' ? '#fbbf24' : '#3b82f6',
      createdAt: new Date().toISOString()
    };

    setAnnotations([...annotations, newAnnotation]);
    if (activeTool === 'note') setActiveTool('none');
  };

  const deleteAnnotation = (id: string) => {
    setAnnotations(annotations.filter(a => a.id !== id));
  };

  const updateAnnotation = (id: string, content: string) => {
    setAnnotations(annotations.map(a => a.id === id ? { ...a, content } : a));
  };

  const toggleBookmark = () => {
    const newBookmarks = bookmarks.includes(1) 
      ? bookmarks.filter(b => b !== 1) 
      : [...bookmarks, 1];
    setBookmarks(newBookmarks);
  };

  const isEditable = resource.type === 'txt' || resource.type === 'md';

  const [showAnnotationPanel, setShowAnnotationPanel] = useState(false);

  return (
    <div className="fixed inset-0 z-[150] bg-white dark:bg-slate-950 flex flex-col animate-in fade-in duration-300">
      <header className="px-6 py-4 flex justify-between items-center bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border-b border-slate-200/50 dark:border-slate-800/50">
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-900 rounded-xl text-slate-500 hover:text-brand-600 transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-display font-bold text-lg tracking-tight truncate max-w-[200px] md:max-w-md">
              {resource.title}
            </h1>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              {resource.subject} • {resource.type.toUpperCase()}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Annotation Tools */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 rounded-xl p-1 mr-2">
            <button 
              onClick={() => setActiveTool(activeTool === 'highlight' ? 'none' : 'highlight')}
              className={`p-2 rounded-lg transition-all ${activeTool === 'highlight' ? 'bg-amber-500 text-white' : 'text-slate-500 hover:bg-white dark:hover:bg-slate-800'}`}
              title="Highlight Tool"
            >
              <Highlighter size={18} />
            </button>
            <button 
              onClick={() => setActiveTool(activeTool === 'note' ? 'none' : 'note')}
              className={`p-2 rounded-lg transition-all ${activeTool === 'note' ? 'bg-blue-500 text-white' : 'text-slate-500 hover:bg-white dark:hover:bg-slate-800'}`}
              title="Note Tool"
            >
              <MessageSquare size={18} />
            </button>
            <div className="w-px h-4 bg-slate-200 dark:border-slate-800 mx-1" />
            <button 
              onClick={() => setShowAnnotations(!showAnnotations)}
              className={`p-2 rounded-lg transition-all ${showAnnotations ? 'text-brand-600' : 'text-slate-400'}`}
              title="Toggle Annotations"
            >
              <Eye size={18} />
            </button>
            <button 
              onClick={() => setShowAnnotationPanel(!showAnnotationPanel)}
              className={`p-2 rounded-lg transition-all ${showAnnotationPanel ? 'text-brand-600' : 'text-slate-400'}`}
              title="Annotation List"
            >
              <FileText size={18} />
            </button>
          </div>

          <button 
            onClick={toggleBookmark}
            className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${
              bookmarks.length > 0 ? 'bg-amber-100 text-amber-600 dark:bg-amber-900/30' : 'bg-slate-100 dark:bg-slate-900 text-slate-500'
            }`}
            title="Bookmark"
          >
            <Bookmark size={18} className={bookmarks.length > 0 ? 'fill-current' : ''} />
          </button>

          <button 
            onClick={handleSave}
            disabled={isSaving}
            className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${
              isSaving ? 'opacity-50' : 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 hover:bg-emerald-200'
            }`}
            title="Save Changes"
          >
            <Save size={18} />
          </button>

          <button 
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-900 rounded-xl text-slate-500 hover:text-brand-600 transition-colors"
          >
            {isFullScreen ? <Minimize size={18} /> : <Maximize size={18} />}
          </button>

          <button 
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-900 rounded-xl text-slate-500 hover:text-rose-500 transition-colors"
          >
            <X size={20} />
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <main className={`flex-1 overflow-auto bg-slate-50 dark:bg-slate-900/50 transition-all ${isFullScreen ? 'p-0' : 'p-4 md:p-8'}`}>
          <div 
            ref={contentRef}
            onClick={addAnnotation}
            style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top center' }}
            className={`relative mx-auto min-h-full bg-white dark:bg-slate-900 shadow-sm border border-slate-200 dark:border-slate-800 transition-all ${
              isFullScreen ? 'max-w-none border-none p-4 md:p-8' : 'max-w-4xl p-8 md:p-12'
            } ${activeTool !== 'none' ? 'cursor-crosshair' : ''}`}
          >
            {/* Annotations Layer */}
            {showAnnotations && annotations.map(anno => (
              <div 
                key={anno.id}
                style={{ left: `${anno.position.x}%`, top: `${anno.position.y}%` }}
                className="absolute z-10 group"
              >
                {anno.type === 'highlight' ? (
                  <div 
                    className="w-12 h-6 -translate-x-1/2 -translate-y-1/2 opacity-30 rounded-sm"
                    style={{ backgroundColor: anno.color }}
                  />
                ) : (
                  <div className="relative">
                    <div 
                      className="w-6 h-6 -translate-x-1/2 -translate-y-1/2 rounded-full flex items-center justify-center text-white shadow-lg cursor-pointer hover:scale-110 transition-transform"
                      style={{ backgroundColor: anno.color }}
                    >
                      <MessageSquare size={12} />
                    </div>
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 opacity-0 group-hover:opacity-100 transition-all pointer-events-none group-hover:pointer-events-auto z-20 translate-y-2 group-hover:translate-y-0">
                      <textarea 
                        value={anno.content}
                        onChange={(e) => updateAnnotation(anno.id, e.target.value)}
                        className="w-full bg-transparent text-xs outline-none resize-none min-h-[80px] text-slate-700 dark:text-slate-200"
                        placeholder="Write a note..."
                      />
                      <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-100 dark:border-slate-700">
                        <span className="text-[8px] text-slate-400 uppercase font-bold tracking-widest">Annotation</span>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteAnnotation(anno.id);
                          }}
                          className="w-6 h-6 flex items-center justify-center text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {isEditing ? (
              <textarea 
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full h-full min-h-[70vh] bg-transparent outline-none font-mono text-sm leading-relaxed resize-none"
                placeholder="Start typing..."
                autoFocus
              />
            ) : (
              <div className="prose dark:prose-invert max-w-none">
                {resource.type === 'md' ? (
                  <div className="markdown-body">
                    <Markdown>{content}</Markdown>
                  </div>
                ) : resource.type === 'txt' ? (
                  <pre className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-slate-700 dark:text-slate-300">
                    {content}
                  </pre>
                ) : resource.type === 'pdf' && fileUrl ? (
                  <iframe 
                    src={fileUrl} 
                    className="w-full h-[80vh] rounded-xl border-none pointer-events-auto"
                    title="PDF Viewer"
                  />
                ) : (resource.fileData?.type.startsWith('image/') || ['png', 'jpg'].includes(resource.type)) && fileUrl ? (
                  <img 
                    src={fileUrl} 
                    alt={resource.title} 
                    className="max-w-full h-auto rounded-2xl shadow-xl mx-auto select-none"
                    referrerPolicy="no-referrer"
                    draggable={false}
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
                    <div className="w-24 h-24 bg-slate-100 dark:bg-slate-800 rounded-[2rem] flex items-center justify-center text-slate-300">
                      <FileText size={48} />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-xl font-bold">Preview not available</h3>
                      <p className="text-slate-500 max-w-xs mx-auto">This file type cannot be viewed directly. You can download it to view with external apps.</p>
                    </div>
                    <a 
                      href={fileUrl || '#'} 
                      download={resource.fileName}
                      className="px-8 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-xl shadow-brand-200 dark:shadow-none flex items-center gap-2"
                    >
                      <Download size={20} /> Download File
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>
        </main>

        <AnimatePresence>
          {showAnnotationPanel && (
            <motion.aside 
              initial={{ x: 300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 300, opacity: 0 }}
              className="w-80 bg-white dark:bg-slate-950 border-l border-slate-200 dark:border-slate-800 flex flex-col"
            >
              <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
                <h2 className="font-bold text-sm uppercase tracking-widest flex items-center gap-2">
                  <MessageSquare size={16} className="text-brand-600" /> Annotations
                </h2>
                <button onClick={() => setShowAnnotationPanel(false)} className="text-slate-400 hover:text-slate-600">
                  <X size={16} />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4 space-y-4">
                {annotations.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <div className="w-12 h-12 bg-slate-50 dark:bg-slate-900 rounded-xl flex items-center justify-center text-slate-300 mx-auto">
                      <Edit3 size={24} />
                    </div>
                    <p className="text-xs text-slate-500">No annotations yet. Use the tools above to add some.</p>
                  </div>
                ) : (
                  annotations.map(anno => (
                    <div key={anno.id} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className={`text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full ${
                          anno.type === 'highlight' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                          {anno.type}
                        </span>
                        <button 
                          onClick={() => deleteAnnotation(anno.id)}
                          className="text-slate-400 hover:text-rose-500 transition-colors"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                      {anno.type === 'note' && (
                        <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3">{anno.content}</p>
                      )}
                      <p className="text-[8px] text-slate-400 font-medium">
                        {new Date(anno.createdAt).toLocaleString()}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
