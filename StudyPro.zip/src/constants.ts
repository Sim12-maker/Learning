export const LOFI_TRACKS = [
  { id: 'lofi-1', title: 'Deep Focus', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', type: 'audio' as const },
  { id: 'lofi-2', title: 'Study Session', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', type: 'audio' as const },
  { id: 'lofi-3', title: 'Chill Beats', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', type: 'audio' as const },
  { id: 'lofi-4', title: 'Ambient Rain', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', type: 'audio' as const },
  { id: 'lofi-5', title: 'Midnight Jazz', src: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3', type: 'audio' as const },
];
