import Dexie, { Table } from "dexie";
import { 
  TimetableEvent, 
  Note, 
  Task, 
  TimerSession, 
  Resource, 
  UserProfile, 
  SubjectColor,
  AppSettings,
  Playlist
} from "./types";

export class StudyProDatabase extends Dexie {
  timetableEvents!: Table<TimetableEvent>;
  notes!: Table<Note>;
  recurrenceCache!: Table<any>;
  draftNotes!: Table<any>;
  tasksStore!: Table<Task>;
  timerSessionsStore!: Table<TimerSession>;
  resourcesStore!: Table<Resource>;
  userProfile!: Table<UserProfile>;
  subjectColorsStore!: Table<SubjectColor>;
  appSettings!: Table<AppSettings>;
  playlistsStore!: Table<Playlist>;
  recentlyPlayedStore!: Table<any>;

  constructor() {
    super("StudyProDB");
    this.version(4).stores({
      timetableEvents: "id, subject, date, startTime, synced",
      notes: "id, title, createdAt, synced",
      recurrenceCache: "++id, eventId, date",
      draftNotes: "noteId, lastEdited",
      tasksStore: "id, dueDate, synced",
      timerSessionsStore: "id, date, synced",
      resourcesStore: "id, type, subject, category, isFavorite, lastOpened, addedAt, synced",
      userProfile: "id, synced",
      subjectColorsStore: "id, synced",
      appSettings: "id",
      playlistsStore: "id, isFavorite, createdAt, synced",
      recentlyPlayedStore: "id, playedAt"
    });
  }
}

export const dbInstance = new StudyProDatabase();

// Mapping old store names to new ones if they changed
const storeMap: Record<string, string> = {
  'timetableStore': 'timetableEvents',
  'notesStore': 'notes',
  'recurrenceCache': 'recurrenceCache',
  'draftNotes': 'draftNotes',
  'tasksStore': 'tasksStore',
  'timerSessionsStore': 'timerSessionsStore',
  'resourcesStore': 'resourcesStore',
  'userProfile': 'userProfile',
  'subjectColorsStore': 'subjectColorsStore',
  'appSettings': 'appSettings',
  'playlistsStore': 'playlistsStore',
  'recentlyPlayedStore': 'recentlyPlayedStore'
};

export const db = {
  async open() {
    return await dbInstance.open();
  },

  async getAll(storeName: string): Promise<any[]> {
    const table = (dbInstance as any)[storeMap[storeName] || storeName];
    return await table.toArray();
  },

  async put(storeName: string, data: any) {
    const table = (dbInstance as any)[storeMap[storeName] || storeName];
    const result = await table.put(data);
    
    // Backup critical data to localStorage as requested
    if (['timetableStore', 'notesStore', 'tasksStore'].includes(storeName)) {
      this.backupToLocalStorage(storeName);
    }
    
    return result;
  },

  async bulkPut(storeName: string, dataArray: any[]) {
    const table = (dbInstance as any)[storeMap[storeName] || storeName];
    const result = await table.bulkPut(dataArray);
    
    if (['timetableStore', 'notesStore', 'tasksStore'].includes(storeName)) {
      this.backupToLocalStorage(storeName);
    }
    
    return result;
  },

  async delete(storeName: string, id: any) {
    const table = (dbInstance as any)[storeMap[storeName] || storeName];
    const result = await table.delete(id);
    
    if (['timetableStore', 'notesStore', 'tasksStore'].includes(storeName)) {
      this.backupToLocalStorage(storeName);
    }
    
    return result;
  },

  async clearStore(storeName: string) {
    const table = (dbInstance as any)[storeMap[storeName] || storeName];
    return await table.clear();
  },

  async get(storeName: string, id: any): Promise<any> {
    const table = (dbInstance as any)[storeMap[storeName] || storeName];
    return await table.get(id);
  },

  async getUnsynced(storeName: string): Promise<any[]> {
    const mappedName = storeMap[storeName] || storeName;
    const table = (dbInstance as any)[mappedName];
    if (!table) return [];
    try {
      return await table.where('synced').equals(0).toArray();
    } catch {
      return await table.toArray().then((all: any[]) => all.filter(i => i.synced === 0));
    }
  },

  async backupToLocalStorage(storeName: string) {
    try {
      const data = await this.getAll(storeName);
      localStorage.setItem(`last_${storeName}_backup`, JSON.stringify(data));
    } catch (e) {
      console.error(`Failed to backup ${storeName} to localStorage`, e);
    }
  }
};
