/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  House, Timer as TimerIcon, CalendarDays, NotebookPen, 
  Library as LibraryIcon, Settings, BookOpen, Moon, Sun,
  User as UserIcon, WifiOff, RefreshCw, Download, CheckCircle2,
  TrendingUp, Menu, LogOut, FileJson, X, AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db } from './db';
import { ViewType, UserProfile, Resource } from './types';
import { usePWA } from './context/PWAContext';
import { useSettings } from './context/SettingsContext';
import Dashboard from './components/Dashboard';
import Timetable from './components/Timetable';
import Notes from './components/Notes';
import Library from './components/Library';
import Tasks from './components/Tasks';
import Statistics from './components/Statistics';
import Welcome from './components/Welcome';
import MediaPlayer from './components/MediaPlayer';
import MediaLibrary from './components/MediaLibrary';
import SettingsView from './components/Settings';

export default function App() {
  const { settings, updateSettings } = useSettings();

  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [notesFilterEventId, setNotesFilterEventId] = useState<string | null>(null);
  const [initialTaskId, setInitialTaskId] = useState<string | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [resources, setResources] = useState<Resource[]>([]);
  const [showWelcome, setShowWelcome] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [activeMedia, setActiveMedia] = useState<{ src: string, type: 'video' | 'audio', title: string } | null>(null);

  // FIX #2: Controlled inputs for profile modal — no more DOM reads
  const [profileName, setProfileName] = useState('');
  const [profileGoal, setProfileGoal] = useState('');

  // FIX: Replace native confirm() with a custom modal
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const { isOffline, isOfflineReady, canInstall, installApp, isSyncing, lastSynced, hasUnsyncedData, syncData } = usePWA();
  const [showOfflineReady, setShowOfflineReady] = useState(false);
  const [showOfflineBanner, setShowOfflineBanner] = useState(false);

  useEffect(() => {
    if (isOffline) {
      setShowOfflineBanner(true);
      const t = setTimeout(() => setShowOfflineBanner(false), 5000);
      return () => clearTimeout(t);
    } else {
      setShowOfflineBanner(false);
    }
  }, [isOffline]);

  useEffect(() => {
    if (isOfflineReady) {
      setShowOfflineReady(true);
      const t = setTimeout(() => setShowOfflineReady(false), 5000);
      return () => clearTimeout(t);
    }
  }, [isOfflineReady]);

  useEffect(() => {
    const init = async () => {
      await db.open();
      const userProfile = await db.get('userProfile', 1);
      const allResources = await db.getAll('resourcesStore');
      setResources(allResources);
      if (!userProfile || userProfile.name === 'Student') {
        setShowWelcome(true);
        if (userProfile) setProfile(userProfile);
      } else {
        setProfile(userProfile);
      }
    };
    init();
  }, []);

  // FIX #1: Dark mode is now driven by SettingsContext — no polling interval needed

  const navItems = [
    { id: 'dashboard', icon: House, label: 'Home' },
    { id: 'timetable', icon: CalendarDays, label: 'Schedule' },
    { id: 'tasks', icon: CheckCircle2, label: 'Tasks' },
    { id: 'notes', icon: NotebookPen, label: 'Notes' },
    { id: 'library', icon: LibraryIcon, label: 'Library' },
    { id: 'statistics', icon: TrendingUp, label: 'Stats' },
  ];

  const renderView = () => {
    switch (activeView) {
      case 'dashboard': return <Dashboard onNavigate={setActiveView} onNewNote={() => { setNotesFilterEventId(null); setActiveView('notes'); }} />;
      case 'timetable': return <Timetable initialTaskId={initialTaskId} onNavigate={(view, eventId) => {
        if (view === 'notes' && eventId) setNotesFilterEventId(eventId);
        else setNotesFilterEventId(null);
        setInitialTaskId(null);
        setActiveView(view);
      }} />;
      case 'notes': return <Notes initialEventId={notesFilterEventId || 'All'} />;
      case 'statistics': return <Statistics />;
      case 'library': return <Library onPlayMedia={setActiveMedia} />;
      case 'tasks': return <Tasks onNavigate={(view, taskId) => {
        if (view === 'timetable' && taskId) setInitialTaskId(taskId);
        else setInitialTaskId(null);
        setActiveView(view);
      }} />;
      case 'media': return <MediaLibrary 
        resources={resources} 
        onDelete={async (id) => { await db.delete('resourcesStore', id); setResources(prev => prev.filter(r => r.id !== id)); }}
        onToggleFavorite={async (id) => {
          const r = resources.find(res => res.id === id);
          if (r) {
            const updated = { ...r, isFavorite: !r.isFavorite };
            await db.put('resourcesStore', updated);
            setResources(prev => prev.map(res => res.id === id ? updated : res));
          }
        }}
      />;
      case 'settings': return <SettingsView />;
      default: return <Dashboard onNavigate={setActiveView} onNewNote={() => { setNotesFilterEventId(null); setActiveView('notes'); }} />;
    }
  };

  const handleWelcomeComplete = async (username: string) => {
    const newProfile: UserProfile = { id: 1, name: username, goal: 'Master your studies', synced: 0 };
    await db.put('userProfile', newProfile);
    setProfile(newProfile);
    setShowWelcome(false);
  };

  const openProfileModal = () => {
    setProfileName(profile?.name ?? '');
    setProfileGoal(profile?.goal ?? '');
    setIsProfileModalOpen(true);
    setIsMenuOpen(false);
  };

  const handleUpdateProfile = async () => {
    const newProfile: UserProfile = { 
      id: 1, 
      name: profileName.trim() || 'Student', 
      goal: profileGoal.trim() || 'Master your studies', 
      synced: 0 
    };
    await db.put('userProfile', newProfile);
    setProfile(newProfile);
    setIsProfileModalOpen(false);
  };

  const handleLogout = async () => {
    await db.delete('userProfile', 1);
    setProfile(null);
    setShowWelcome(true);
    setIsMenuOpen(false);
    setShowLogoutConfirm(false);
  };

  const handleExportData = async () => {
    const data: any = {};
    // FIX #3: Use correct table names (notes, not notesStore)
    const stores = ['notes', 'tasksStore', 'timerSessionsStore', 'resourcesStore', 'userProfile'];
    for (const store of stores) {
      data[store] = await db.getAll(store as any);
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `studypro-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setIsMenuOpen(false);
  };

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-50 pb-24 md:pb-0 md:pl-20 transition-colors duration-300 font-size-${settings.fontSize}`}>
      <AnimatePresence>
        {showWelcome && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[200]">
            <Welcome onComplete={handleWelcomeComplete} />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showOfflineReady && (
          <motion.div initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -50, opacity: 0 }}
            className="fixed top-0 left-0 right-0 z-[100] bg-emerald-500 text-white py-2 px-4 flex items-center justify-center gap-2 text-xs font-bold shadow-lg">
            <CheckCircle2 size={14} /><span>App is ready to work offline!</span>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showOfflineBanner && (
          <motion.div initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -50, opacity: 0 }}
            className="fixed top-0 left-0 right-0 z-[100] bg-orange-500 text-white py-2 px-4 flex items-center justify-center gap-2 text-xs font-bold shadow-lg">
            <WifiOff size={14} /><span>You are currently offline. Changes will be saved locally.</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop Sidebar */}
      <nav className="hidden md:flex fixed left-0 top-0 bottom-0 w-20 flex-col items-center py-8 glass-card border-r border-white/10 z-50 transition-colors duration-300">
        <div className="mb-12">
          <div className="w-12 h-12 bg-[#1E2A38] rounded-2xl flex items-center justify-center text-white shadow-lg border border-white/10">
            <BookOpen size={24} className="text-[#4A90E2]" />
          </div>
        </div>
        <div className="flex-1 flex flex-col gap-6">
          {navItems.map((item) => (
            <button key={item.id} onClick={() => { setInitialTaskId(null); setActiveView(item.id as ViewType); }}
              className={`p-3 rounded-2xl transition-all duration-200 group relative ${activeView === item.id ? 'nav-item-active' : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}>
              <item.icon size={24} />
              <span className="absolute left-full ml-4 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50">{item.label}</span>
            </button>
          ))}
        </div>
        <div className="mt-auto flex flex-col gap-4">
          {hasUnsyncedData && !isOffline && (
            <button onClick={() => syncData()} disabled={isSyncing}
              className={`p-3 bg-amber-500 text-white rounded-2xl shadow-lg shadow-amber-200 dark:shadow-none hover:bg-amber-600 transition-all ${isSyncing ? 'animate-pulse' : ''}`} title="Sync Pending Changes">
              <RefreshCw size={24} className={isSyncing ? 'animate-spin' : ''} />
            </button>
          )}
          {canInstall && (
            <button onClick={installApp} className="p-3 bg-brand-600 text-white rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none hover:bg-brand-700 transition-all" title="Install App">
              <Download size={24} />
            </button>
          )}
          <button onClick={() => setActiveView('settings')}
            className={`p-3 rounded-2xl transition-all duration-200 group relative ${activeView === 'settings' ? 'nav-item-active' : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`} title="Settings">
            <Settings size={24} />
            <span className="absolute left-full ml-4 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50">Settings</span>
          </button>
          <button onClick={() => updateSettings({ darkMode: !settings.darkMode })}
            className="p-3 text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-2xl transition-all" title="Toggle Dark Mode">
            {settings.darkMode ? <Sun size={24} /> : <Moon size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50">
        <nav className="glass-morphism backdrop-blur-2xl border-t border-white/10 px-2 py-4 flex items-center justify-around shadow-[0_-10px_30px_-15px_rgba(0,0,0,0.1)]">
          {navItems.map((item) => (
            <button key={item.id} onClick={() => { setInitialTaskId(null); setActiveView(item.id as ViewType); }}
              className={`flex flex-col items-center justify-center transition-all duration-300 relative px-2 ${activeView === item.id ? 'text-brand-600 dark:text-brand-400 scale-110' : 'text-slate-400'}`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-1.5 transition-all ${activeView === item.id ? 'bg-brand-600 text-white shadow-lg shadow-brand-200 dark:shadow-none' : 'glass-card border-white/10'}`}>
                <item.icon size={24} strokeWidth={activeView === item.id ? 2.5 : 2} />
              </div>
              <span className={`text-[10px] font-extrabold uppercase tracking-tight transition-all ${activeView === item.id ? 'opacity-100 text-brand-600 dark:text-brand-400' : 'opacity-40 text-slate-500'}`}>{item.label}</span>
              {activeView === item.id && <motion.div layoutId="activeTabMobile" className="absolute -bottom-1 w-1.5 h-1.5 bg-brand-600 dark:bg-brand-400 rounded-full" />}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content Area */}
      <main className="max-w-screen-xl mx-auto">
        <header className="sticky top-0 left-0 right-0 z-40 px-6 py-4 flex justify-between items-center md:hidden bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border-b border-slate-200/50 dark:border-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#1E2A38] rounded-xl flex items-center justify-center text-white shadow-lg border border-white/10">
              <BookOpen size={20} className="text-[#4A90E2]" />
            </div>
            <h1 className="font-display font-bold text-xl tracking-tight">StudyPro</h1>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => updateSettings({ darkMode: !settings.darkMode })}
              className="w-10 h-10 flex items-center justify-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              {settings.darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="w-10 h-10 flex items-center justify-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>

          <AnimatePresence>
            {isMenuOpen && (
              <>
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  onClick={() => setIsMenuOpen(false)} className="fixed inset-0 bg-slate-950/20 backdrop-blur-sm z-40" />
                <motion.div initial={{ opacity: 0, scale: 0.95, y: -20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: -20 }}
                  className="absolute top-full right-6 mt-2 w-56 bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-2xl z-50 overflow-hidden">
                  <div className="p-2 space-y-1">
                    <button onClick={openProfileModal} className="w-full flex items-center gap-3 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition-colors text-left">
                      <UserIcon size={18} className="text-brand-500" />
                      <div className="flex flex-col"><span className="text-sm font-bold">Profile</span><span className="text-[10px] text-slate-400 font-medium">{profile?.name || 'Guest'}</span></div>
                    </button>
                    <button onClick={() => { setActiveView('settings'); setIsMenuOpen(false); }} className="w-full flex items-center gap-3 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition-colors text-left">
                      <Settings size={18} className="text-slate-400" /><span className="text-sm font-bold">Settings</span>
                    </button>
                    <button onClick={() => { syncData(); setIsMenuOpen(false); }} className="w-full flex items-center gap-3 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition-colors text-left">
                      <RefreshCw size={18} className="text-emerald-500" /><span className="text-sm font-bold">Sync Data</span>
                    </button>
                    <button onClick={handleExportData} className="w-full flex items-center gap-3 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition-colors text-left">
                      <FileJson size={18} className="text-amber-500" /><span className="text-sm font-bold">Export Data</span>
                    </button>
                    <button onClick={() => { setShowLogoutConfirm(true); setIsMenuOpen(false); }}
                      className="w-full flex items-center gap-3 p-4 hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600 rounded-2xl transition-colors text-left">
                      <LogOut size={18} /><span className="text-sm font-bold">Logout</span>
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </header>

        {/* Profile Modal — controlled inputs (Bug fix #2) */}
        <AnimatePresence>
          {isProfileModalOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={() => setIsProfileModalOpen(false)} className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" />
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden p-8">
                <div className="space-y-6">
                  <header className="flex justify-between items-center">
                    <h2 className="text-2xl font-display font-bold">Edit Profile</h2>
                    <button onClick={() => setIsProfileModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"><X size={20} /></button>
                  </header>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Your Name</label>
                      <input type="text" value={profileName} onChange={e => setProfileName(e.target.value)} className="premium-input" placeholder="Enter your name" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Study Goal</label>
                      <input type="text" value={profileGoal} onChange={e => setProfileGoal(e.target.value)} className="premium-input" placeholder="e.g. Master your studies" />
                    </div>
                  </div>
                  <div className="flex gap-3 pt-4">
                    <button onClick={() => setIsProfileModalOpen(false)} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button">Cancel</button>
                    <button onClick={handleUpdateProfile} className="flex-1 py-4 bg-brand-600 text-white font-bold rounded-2xl shadow-lg shadow-brand-200 dark:shadow-none thumb-button">Save Changes</button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Logout Confirmation Modal (replaces native confirm()) */}
        <AnimatePresence>
          {showLogoutConfirm && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={() => setShowLogoutConfirm(false)} className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" />
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
                className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden p-8">
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center text-red-600"><AlertTriangle size={28} /></div>
                  <div>
                    <h2 className="text-xl font-display font-bold">Log out?</h2>
                    <p className="text-sm text-slate-400 mt-1">This will clear your local profile. Your study data stays on this device.</p>
                  </div>
                  <div className="flex gap-3 w-full pt-2">
                    <button onClick={() => setShowLogoutConfirm(false)} className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 thumb-button">Cancel</button>
                    <button onClick={handleLogout} className="flex-1 py-4 bg-red-600 text-white font-bold rounded-2xl shadow-lg shadow-red-200 dark:shadow-none thumb-button">Log out</button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          <motion.div key={activeView} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
            {renderView()}
          </motion.div>
        </AnimatePresence>

        <AnimatePresence>
          {activeMedia && <MediaPlayer {...activeMedia} onClose={() => setActiveMedia(null)} />}
        </AnimatePresence>
      </main>
    </div>
  );
}
