export type ViewType = 'dashboard' | 'timetable' | 'notes' | 'library' | 'tasks' | 'statistics' | 'settings' | 'media';

export interface UserProfile {
  id: number;
  name: string;
  goal: string;
  avatar?: string;
  synced: number;
}

export interface AppSettings {
  id: string; // 'current'
  darkMode: boolean;
  notificationsEnabled: boolean;
  studyReminders: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  fontSize: 'small' | 'medium' | 'large';
  accentColor: string;
  focusDuration: number;
  breakDuration: number;
  longBreakDuration: number;
  autoStartBreak: boolean;
  dailyGoal: number; // in minutes
  lastBackup?: string;
}

export type RepeatInterval = 'none' | 'daily' | 'weekly' | 'monthly';

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  repeat: RepeatInterval;
  dueDate: string; // ISO string
  subject: string;
  priority?: 'low' | 'medium' | 'high';
  notes?: string;
  reminderMin?: string;
  reminderTime?: string; // HH:mm
  notificationType?: 'in-app' | 'push';
  synced: number;
}

export interface TimetableEvent {
  id: string;
  subject: string;
  day: Day;
  date: string; // ISO string for the start date of the event
  start: number;
  duration: number;
  location?: string;
  color?: string;
  priority?: 'low' | 'medium' | 'high';
  repeat?: RepeatInterval;
  notes?: string;
  reminderMin?: string;
  notificationType?: 'in-app' | 'push';
  synced: number;
  taskId?: string; // Linked task ID
  parentId?: string; // If this is an exception to a recurring event
  deletedOccurrences?: string[]; // Array of ISO date strings to skip for recurring events
}

export type Day = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';

export interface Note {
  id: string;
  title: string;
  content: string;
  subject: string;
  tags: string[];
  eventId?: string;
  updatedAt: string;
  synced: number;
}

export interface TimerSession {
  id: string;
  date: string;
  duration: number;
  subject: string;
  type: 'focus' | 'break';
  synced: number;
}

export interface Annotation {
  id: string;
  page?: number;
  type: 'highlight' | 'note';
  color: string;
  content?: string;
  position: { x: number, y: number, width?: number, height?: number };
  createdAt?: string;
}

export interface Resource {
  id: string;
  title: string;
  type: 'pdf' | 'doc' | 'docx' | 'ppt' | 'pptx' | 'txt' | 'png' | 'jpg' | 'md' | 'video' | 'mp3' | 'wav' | 'mp4' | 'mkv' | 'avi';
  category: string;
  url?: string;
  fileData?: Blob;
  fileName?: string;
  fileSize?: number;
  subject: string;
  tags?: string[];
  bookmarks?: number[];
  annotations?: Annotation[];
  isFavorite: boolean;
  lastOpened?: string;
  addedAt: string;
  synced: number;
  // Media specific
  duration?: number;
  thumbnail?: string;
  playbackPosition?: number;
}

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  resourceIds: string[]; // Can be any resource ID
  createdAt: string;
  isFavorite: boolean;
  synced: number;
}

export interface SubjectColor {
  id: string; // subject name
  colorName: string; // name from EVENT_COLORS
}
