import { useState, useEffect, useMemo } from 'react';
import { TimetableEvent } from '../types';
import { timetableService } from '../services/timetableService';

export function useTimetable() {
  const [events, setEvents] = useState<TimetableEvent[]>([]);
  const [occurrences, setOccurrences] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTimetable = async () => {
    setLoading(true);
    const evs = await timetableService.getAllEvents();
    const occs = await timetableService.getCachedOccurrences();
    setEvents(evs);
    setOccurrences(occs);
    setLoading(false);
  };

  useEffect(() => {
    fetchTimetable();
  }, []);

  const saveEvent = async (event: TimetableEvent) => {
    await timetableService.saveEvent(event);
    await fetchTimetable();
  };

  const deleteEvent = async (id: string) => {
    await timetableService.deleteEvent(id);
    await fetchTimetable();
  };

  return {
    events,
    occurrences,
    loading,
    saveEvent,
    deleteEvent,
    refresh: fetchTimetable
  };
}
