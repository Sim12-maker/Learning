// Re-export from central SettingsContext — single source of truth
export { useSettings } from '../context/SettingsContext';
