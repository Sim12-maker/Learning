import { useState, useEffect, useMemo } from 'react';
import { Note } from '../types';
import { noteService } from '../services/noteService';
import Fuse from 'fuse.js';

export function useNotes(search: string = '') {
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotes = async () => {
    setLoading(true);
    const n = await noteService.getAllNotes();
    setNotes(n);
    setLoading(false);
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  const filteredNotes = useMemo(() => {
    if (!search) return notes;
    const fuse = new Fuse(notes, {
      keys: ['title', 'content', 'subject'],
      threshold: 0.4
    });
    return fuse.search(search).map(res => res.item);
  }, [notes, search]);

  const saveNote = async (note: Note) => {
    await noteService.saveNote(note);
    await fetchNotes();
  };

  const deleteNote = async (id: string) => {
    await noteService.deleteNote(id);
    await fetchNotes();
  };

  return {
    notes,
    filteredNotes,
    loading,
    saveNote,
    deleteNote,
    refresh: fetchNotes
  };
}
