import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { PWAProvider } from './context/PWAContext';
import { TimerProvider } from './context/TimerContext';
import { SettingsProvider } from './context/SettingsContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <SettingsProvider>
      <PWAProvider>
        <TimerProvider>
          <App />
        </TimerProvider>
      </PWAProvider>
    </SettingsProvider>
  </StrictMode>,
);
