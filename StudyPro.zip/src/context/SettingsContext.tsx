import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { db } from '../db';
import { AppSettings } from '../types';

const DEFAULT_SETTINGS: AppSettings = {
  id: 'current',
  darkMode: true,
  notificationsEnabled: true,
  studyReminders: true,
  soundEnabled: true,
  vibrationEnabled: true,
  fontSize: 'medium',
  accentColor: '#4A90E2',
  focusDuration: 25,
  breakDuration: 5,
  longBreakDuration: 15,
  autoStartBreak: true,
  dailyGoal: 120,
};

interface SettingsContextType {
  settings: AppSettings;
  updateSettings: (patch: Partial<AppSettings>) => Promise<void>;
  isLoading: boolean;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const saved = await db.get('appSettings', 'current');
        if (saved) {
          setSettings(saved);
        } else {
          await db.put('appSettings', DEFAULT_SETTINGS);
        }
      } catch (e) {
        console.error('Failed to load settings', e);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, []);

  // Sync dark mode class to <html> whenever darkMode changes
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  const updateSettings = useCallback(async (patch: Partial<AppSettings>) => {
    const updated = { ...settings, ...patch };
    setSettings(updated);
    try {
      await db.put('appSettings', updated);
      // Keep localStorage copy for legacy reads (eliminated soon)
      localStorage.setItem('app_settings', JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  }, [settings]);

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, isLoading }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within a SettingsProvider');
  return ctx;
};
