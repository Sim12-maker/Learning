import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db';
import { TimerSession } from '../types';

interface TimerContextType {
  timeLeft: number;
  isActive: boolean;
  mode: 'focus' | 'break';
  progress: number;
  focusTime: number;
  shortBreakTime: number;
  longBreakTime: number;
  selectedSubject: string;
  timerSound: string;
  setTimerSound: (sound: string) => void;
  toggleTimer: () => void;
  resetTimer: () => void;
  setFocusTime: (time: number) => void;
  setShortBreakTime: (time: number) => void;
  setLongBreakTime: (time: number) => void;
  setSelectedSubject: (subject: string) => void;
  formatTime: (seconds: number) => string;
}

const DEFAULT_FOCUS_TIME = 25 * 60;
const DEFAULT_SHORT_BREAK_TIME = 5 * 60;
const DEFAULT_LONG_BREAK_TIME = 15 * 60;
const LONG_BREAK_INTERVAL = 4;

const TimerContext = createContext<TimerContextType | undefined>(undefined);

export const TimerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [focusTime, setFocusTimeState] = useState(() => Number(localStorage.getItem('timer_focus_time')) || DEFAULT_FOCUS_TIME);
  const [shortBreakTime, setShortBreakTimeState] = useState(() => Number(localStorage.getItem('timer_short_break_time')) || DEFAULT_SHORT_BREAK_TIME);
  const [longBreakTime, setLongBreakTimeState] = useState(() => Number(localStorage.getItem('timer_long_break_time')) || DEFAULT_LONG_BREAK_TIME);
  const [sessionsCompleted, setSessionsCompleted] = useState(() => Number(localStorage.getItem('timer_sessions_completed')) || 0);
  const [timeLeft, setTimeLeft] = useState(focusTime);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [selectedSubject, setSelectedSubject] = useState('General');
  const [timerSound, setTimerSoundState] = useState(() => localStorage.getItem('timer_sound') || 'bell');
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const SOUNDS: Record<string, string> = {
    bell: 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3',
    digital: 'https://assets.mixkit.co/active_storage/sfx/2190/2190-preview.mp3',
    bird: 'https://assets.mixkit.co/active_storage/sfx/2434/2434-preview.mp3',
    chime: 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3'
  };

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  const setTimerSound = (sound: string) => {
    setTimerSoundState(sound);
    localStorage.setItem('timer_sound', sound);
    // Cancel any currently-playing preview before starting a new one
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      previewAudioRef.current.src = '';
    }
    const audio = new Audio(SOUNDS[sound]);
    audio.volume = 0.5;
    previewAudioRef.current = audio;
    audio.play().catch(() => {});
  };

  // Persistence logic
  useEffect(() => {
    const focusEndTime = localStorage.getItem('timer_end_time');
    const isTimerActive = localStorage.getItem('timer_is_active') === 'true';
    const currentMode = (localStorage.getItem('timer_mode') as 'focus' | 'break') || 'focus';
    
    if (focusEndTime && isTimerActive) {
      const endTime = parseInt(focusEndTime, 10);
      const now = Date.now();
      const remaining = Math.max(0, Math.floor((endTime - now) / 1000));
      
      if (remaining > 0) {
        setTimeLeft(remaining);
        setIsActive(true);
        setMode(currentMode);
      } else {
        // Timer finished while app was closed
        handleTimerComplete(currentMode);
      }
    }
  }, []);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        const focusEndTime = localStorage.getItem('timer_end_time');
        if (focusEndTime) {
          const endTime = parseInt(focusEndTime, 10);
          const now = Date.now();
          const remaining = Math.max(0, Math.floor((endTime - now) / 1000));
          setTimeLeft(remaining);
          
          if (remaining === 0) {
            handleTimerComplete(mode);
          }
        } else {
          // Fallback if end time is missing
          setTimeLeft(prev => {
            if (prev <= 1) {
              handleTimerComplete(mode);
              return 0;
            }
            return prev - 1;
          });
        }
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isActive, timeLeft, mode]);

  const handleTimerComplete = async (completedMode: 'focus' | 'break') => {
    setIsActive(false);
    localStorage.removeItem('timer_end_time');
    localStorage.setItem('timer_is_active', 'false');
    
      if (completedMode === 'focus') {
      const newSessionsCompleted = sessionsCompleted + 1;
      setSessionsCompleted(newSessionsCompleted);
      localStorage.setItem('timer_sessions_completed', String(newSessionsCompleted));

      const session: TimerSession = {
        id: uuidv4(),
        subject: selectedSubject,
        duration: Math.floor(focusTime / 60),
        date: new Date().toISOString(),
        type: 'focus',
        synced: 0
      };
      await db.put('timerSessionsStore', session);
      
      // Notify user (optional, can be handled by UI listening to this state)
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Focus Session Completed!', {
          body: `Great job! You focused for ${Math.floor(focusTime / 60)} minutes.`,
          icon: '/icons/icon-192x192.png'
        });
      }
      
      setMode('break');
      const nextBreakTime = newSessionsCompleted % LONG_BREAK_INTERVAL === 0 ? longBreakTime : shortBreakTime;
      setTimeLeft(nextBreakTime);

      // Play sound
      if (localStorage.getItem('timer_sound_enabled') !== 'false') {
        const audio = new Audio(SOUNDS[timerSound]);
        audio.play().catch(e => console.error('Error playing sound:', e));
      }
    } else {
      setMode('focus');
      setTimeLeft(focusTime);

      // Play sound
      if (localStorage.getItem('timer_sound_enabled') !== 'false') {
        const audio = new Audio(SOUNDS[timerSound]);
        audio.play().catch(e => console.error('Error playing sound:', e));
      }
    }
  };

  const toggleTimer = () => {
    const nextActive = !isActive;
    setIsActive(nextActive);
    localStorage.setItem('timer_is_active', String(nextActive));
    
    if (nextActive) {
      const endTime = Date.now() + timeLeft * 1000;
      localStorage.setItem('timer_end_time', String(endTime));
      localStorage.setItem('timer_mode', mode);
    } else {
      localStorage.removeItem('timer_end_time');
    }
  };

  const resetTimer = () => {
    setIsActive(false);
    let initialTime = focusTime;
    if (mode === 'break') {
      initialTime = sessionsCompleted % LONG_BREAK_INTERVAL === 0 ? longBreakTime : shortBreakTime;
    }
    setTimeLeft(initialTime);
    localStorage.setItem('timer_is_active', 'false');
    localStorage.removeItem('timer_end_time');
  };

  const setFocusTime = (time: number) => {
    setFocusTimeState(time);
    localStorage.setItem('timer_focus_time', String(time));
    if (mode === 'focus' && !isActive) setTimeLeft(time);
  };

  const setShortBreakTime = (time: number) => {
    setShortBreakTimeState(time);
    localStorage.setItem('timer_short_break_time', String(time));
    if (mode === 'break' && !isActive && sessionsCompleted % LONG_BREAK_INTERVAL !== 0) setTimeLeft(time);
  };

  const setLongBreakTime = (time: number) => {
    setLongBreakTimeState(time);
    localStorage.setItem('timer_long_break_time', String(time));
    if (mode === 'break' && !isActive && sessionsCompleted % LONG_BREAK_INTERVAL === 0) setTimeLeft(time);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const progress = 1 - (timeLeft / (mode === 'focus' ? focusTime : (sessionsCompleted % LONG_BREAK_INTERVAL === 0 ? longBreakTime : shortBreakTime)));

  return (
    <TimerContext.Provider value={{ 
      timeLeft, 
      isActive, 
      mode, 
      progress, 
      focusTime, 
      shortBreakTime,
      longBreakTime,
      selectedSubject,
      timerSound,
      setTimerSound,
      toggleTimer, 
      resetTimer,
      setFocusTime,
      setShortBreakTime,
      setLongBreakTime,
      setSelectedSubject,
      formatTime
    }}>
      {children}
    </TimerContext.Provider>
  );
};

export const useTimer = () => {
  const context = useContext(TimerContext);
  if (context === undefined) {
    throw new Error('useTimer must be used within a TimerProvider');
  }
  return context;
};
