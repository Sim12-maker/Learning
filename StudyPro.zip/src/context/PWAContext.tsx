import React, { createContext, useContext, useState, useEffect } from 'react';
import { registerSW } from 'virtual:pwa-register';
import { db } from '../db';

interface PWAContextType {
  isOffline: boolean;
  isOfflineReady: boolean;
  canInstall: boolean;
  isSyncing: boolean;
  lastSynced: Date | null;
  hasUnsyncedData: boolean;
  installApp: () => void;
  syncData: () => Promise<void>;
}

const PWAContext = createContext<PWAContextType | undefined>(undefined);

export const PWAProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isOfflineReady, setIsOfflineReady] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [canInstall, setCanInstall] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [hasUnsyncedData, setHasUnsyncedData] = useState(false);
  const [lastSynced, setLastSynced] = useState<Date | null>(() => {
    const saved = localStorage.getItem('last_synced');
    return saved ? new Date(saved) : null;
  });

  const checkUnsynced = async () => {
    const stores = ['notesStore', 'timetableStore', 'timerSessionsStore', 'resourcesStore', 'tasksStore'];
    for (const storeName of stores) {
      const unsynced = await db.getUnsynced(storeName);
      if (unsynced.length > 0) {
        setHasUnsyncedData(true);
        return;
      }
    }
    setHasUnsyncedData(false);
  };

  useEffect(() => {
    checkUnsynced();
    const interval = setInterval(checkUnsynced, 5000); // Check every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const isOfflineRef = React.useRef(isOffline);
  const isSyncingRef = React.useRef(isSyncing);
  useEffect(() => { isOfflineRef.current = isOffline; }, [isOffline]);
  useEffect(() => { isSyncingRef.current = isSyncing; }, [isSyncing]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      // Use refs so the handler always sees current values (fixes stale-closure bug)
      if (!isOfflineRef.current && !isSyncingRef.current) {
        syncData();
      }
    };
    const handleOffline = () => setIsOffline(true);
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setCanInstall(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Register Service Worker using vite-plugin-pwa
    const updateSW = registerSW({
      onNeedRefresh() {
        if (confirm('New content available. Reload?')) {
          updateSW(true);
        }
      },
      onOfflineReady() {
        console.log('App ready to work offline');
        setIsOfflineReady(true);
      },
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const installApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setCanInstall(false);
    }
    setDeferredPrompt(null);
  };

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const syncData = async () => {
    if (isOffline || isSyncing) return;
    
    setIsSyncing(true);
    try {
      console.log('🔄 PWA: Starting data synchronization...');
      
      const stores = ['notesStore', 'timetableStore', 'timerSessionsStore', 'resourcesStore', 'tasksStore', 'userProfile', 'subjectColorsStore'];
      let totalSynced = 0;

      for (const storeName of stores) {
        const unsyncedItems = await db.getUnsynced(storeName);
        
        if (unsyncedItems.length > 0) {
          console.log(`📝 PWA: Found ${unsyncedItems.length} unsynced items in ${storeName}. Syncing to server...`);
          
          // Prepare items for sync (handle Blobs)
          const itemsToSync = [];
          for (const item of unsyncedItems) {
            const itemCopy = { ...item };
            if (itemCopy.fileData instanceof Blob) {
              itemCopy.fileData = await blobToBase64(itemCopy.fileData);
            }
            itemsToSync.push(itemCopy);
          }

          const response = await fetch(`/api/sync/${storeName}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(itemsToSync)
          });

          if (response.ok) {
            for (const item of unsyncedItems) {
              await db.put(storeName, { ...item, synced: 1 });
            }
            totalSynced += unsyncedItems.length;
            console.log(`✅ PWA: ${storeName} synced to server successfully.`);
          }
        }

        // Pull from server
        console.log(`📥 PWA: Pulling updates for ${storeName} from server...`);
        const pullResponse = await fetch(`/api/sync/${storeName}`);
        if (pullResponse.ok) {
          const serverItems = await pullResponse.json();
          for (const item of serverItems) {
            // Parse array fields
            const arrayFields = ['tags', 'deletedOccurrences'];
            for (const field of arrayFields) {
              if (typeof item[field] === 'string') {
                try {
                  item[field] = JSON.parse(item[field]);
                } catch (e) {
                  // Not a JSON string, keep as is
                }
              }
            }

            // Handle fileData (Buffer from JSON to Blob)
            if (item.fileData && typeof item.fileData === 'object' && item.fileData.type === 'Buffer') {
              item.fileData = new Blob([new Uint8Array(item.fileData.data)]);
            }

            await db.put(storeName, { ...item, synced: 1 });
          }
        }
      }
      
      if (totalSynced === 0) {
        console.log('✅ PWA: No unsynced data found.');
      } else {
        console.log(`✅ PWA: Total ${totalSynced} items synced across all stores.`);
      }
      
      const now = new Date();
      setLastSynced(now);
      localStorage.setItem('last_synced', now.toISOString());
      await checkUnsynced();
      
    } catch (error) {
      console.error('❌ PWA: Sync failed', error);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <PWAContext.Provider value={{ isOffline, isOfflineReady, canInstall, isSyncing, lastSynced, hasUnsyncedData, installApp, syncData }}>
      {children}
    </PWAContext.Provider>
  );
};

export const usePWA = () => {
  const context = useContext(PWAContext);
  if (context === undefined) {
    throw new Error('usePWA must be used within a PWAProvider');
  }
  return context;
};
