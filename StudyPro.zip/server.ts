import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("studypro.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS notes (
    id TEXT PRIMARY KEY,
    title TEXT,
    content TEXT,
    subject TEXT,
    tags TEXT,
    eventId TEXT,
    updatedAt TEXT
  );
  CREATE TABLE IF NOT EXISTS timetable (
    id TEXT PRIMARY KEY,
    subject TEXT,
    day TEXT,
    date TEXT,
    start REAL,
    duration REAL,
    location TEXT,
    color TEXT,
    priority TEXT,
    repeat TEXT,
    notes TEXT,
    reminderMin TEXT,
    notificationType TEXT,
    parentId TEXT,
    deletedOccurrences TEXT
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    title TEXT,
    completed INTEGER,
    repeat TEXT,
    dueDate TEXT,
    subject TEXT,
    priority TEXT,
    notes TEXT,
    reminderMin TEXT
  );
  CREATE TABLE IF NOT EXISTS timer_sessions (
    id TEXT PRIMARY KEY,
    date TEXT,
    duration REAL,
    subject TEXT,
    type TEXT
  );
  CREATE TABLE IF NOT EXISTS resources (
    id TEXT PRIMARY KEY,
    title TEXT,
    type TEXT,
    url TEXT,
    fileData BLOB,
    fileName TEXT,
    subject TEXT,
    tags TEXT,
    addedAt TEXT
  );
  CREATE TABLE IF NOT EXISTS user_profile (
    id INTEGER PRIMARY KEY,
    name TEXT,
    goal TEXT
  );
  CREATE TABLE IF NOT EXISTS subject_colors (
    id TEXT PRIMARY KEY,
    colorName TEXT
  );
`);

// Add missing columns if they don't exist (for existing databases)
const tables = {
  timetable: ['date', 'notificationType', 'parentId', 'deletedOccurrences'],
  resources: ['fileData', 'tags']
};

for (const [table, columns] of Object.entries(tables)) {
  const info = db.prepare(`PRAGMA table_info(${table})`).all() as any[];
  const existingColumns = info.map(c => c.name);
  for (const column of columns) {
    if (!existingColumns.includes(column)) {
      const type = column === 'fileData' ? 'BLOB' : 'TEXT';
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
    }
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // API Routes
  app.get("/api/sync/:store", (req, res) => {
    const { store } = req.params;
    const table = store.replace('Store', '').replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
    // Simple mapping for demo
    const tableName = store === 'notesStore' ? 'notes' : 
                     store === 'timetableStore' ? 'timetable' : 
                     store === 'tasksStore' ? 'tasks' : 
                     store === 'timerSessionsStore' ? 'timer_sessions' : 
                     store === 'resourcesStore' ? 'resources' : 
                     store === 'userProfile' ? 'user_profile' :
                     store === 'subjectColorsStore' ? 'subject_colors' : null;

    if (!tableName) return res.status(400).json({ error: "Invalid store" });

    const items = db.prepare(`SELECT * FROM ${tableName}`).all();
    res.json(items);
  });

  app.post("/api/sync/:store", (req, res) => {
    const { store } = req.params;
    const items = req.body;
    const tableName = store === 'notesStore' ? 'notes' : 
                     store === 'timetableStore' ? 'timetable' : 
                     store === 'tasksStore' ? 'tasks' : 
                     store === 'timerSessionsStore' ? 'timer_sessions' : 
                     store === 'resourcesStore' ? 'resources' : 
                     store === 'userProfile' ? 'user_profile' :
                     store === 'subjectColorsStore' ? 'subject_colors' : null;

    if (!tableName) return res.status(400).json({ error: "Invalid store" });

    const insert = db.transaction((items) => {
      for (const item of items) {
        const { synced, ...data } = item;
        const keys = Object.keys(data);
        const placeholders = keys.map(() => "?").join(",");
        const columns = keys.join(",");
        
        // Handle array fields
        const arrayFields = ['tags', 'deletedOccurrences'];
        for (const field of arrayFields) {
          if (data[field] && Array.isArray(data[field])) {
            data[field] = JSON.stringify(data[field]);
          }
        }

        // Handle fileData (base64 to Buffer)
        if (data.fileData && typeof data.fileData === 'string' && data.fileData.includes(';base64,')) {
          const base64Data = data.fileData.split(';base64,').pop();
          if (base64Data) {
            data.fileData = Buffer.from(base64Data, 'base64');
          }
        }

        db.prepare(`
          INSERT OR REPLACE INTO ${tableName} (${columns})
          VALUES (${placeholders})
        `).run(...Object.values(data));
      }
    });

    insert(items);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
